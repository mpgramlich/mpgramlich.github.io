var heap_8c =
[
    [ "_kmalloc", "heap_8c.html#a014b54e36b61f133f53dd509c461f35e", null ],
    [ "alloc", "heap_8c.html#a06dae34c7e7c73d518de00212a7c92da", null ],
    [ "kmalloc", "heap_8c.html#a15d6a52c5c080c8c7ffc73e336d8e574", null ],
    [ "make_heap", "heap_8c.html#a686135c02695aef4208f93d4549a15d0", null ],
    [ "__end", "heap_8c.html#a51f2442fadb8ffd3019f4aeb1b04c4d6", null ],
    [ "_end", "heap_8c.html#a850b19392dca6170001ce200467ab610", null ],
    [ "curr_heap", "heap_8c.html#afaac4d3fb801ecbd3c6fe3c995d5cf82", null ],
    [ "end", "heap_8c.html#a57dfa4d169c6b9c0b4e7352bc0c34366", null ],
    [ "kdir", "heap_8c.html#a61ce943ba80d9dfab89a826cae9ddc4a", null ],
    [ "kheap", "heap_8c.html#a61825456a33b09780a5493c95adcae8a", null ],
    [ "phys_alloc_addr", "heap_8c.html#a6dfa4ef84e115e891b3679e4932b5c49", null ]
];