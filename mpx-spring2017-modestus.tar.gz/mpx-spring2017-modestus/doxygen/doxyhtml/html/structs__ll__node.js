var structs__ll__node =
[
    [ "data", "structs__ll__node.html#a79ffbe9722e36b171fefc1bada4f2721", null ],
    [ "next", "structs__ll__node.html#a72e73da68eb603b175eb9caae6622804", null ],
    [ "prev", "structs__ll__node.html#a8a534a6c6749a5cdc02b3ab769626bda", null ]
];