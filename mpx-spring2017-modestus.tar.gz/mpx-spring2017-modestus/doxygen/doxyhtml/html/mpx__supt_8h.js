var mpx__supt_8h =
[
    [ "param", "structparam.html", "structparam" ],
    [ "EXIT", "mpx__supt_8h.html#ad111e603bbebe5d87f6bc39264ce4733", null ],
    [ "IDLE", "mpx__supt_8h.html#a9c21a7caee326d7803b94ae1952b27ca", null ],
    [ "MODULE_R1", "mpx__supt_8h.html#a9d88621bfb79cb860b9ea2b5abb1c7f0", null ],
    [ "MODULE_R2", "mpx__supt_8h.html#a177f46669733cd706e9476485dfd961b", null ],
    [ "MODULE_R3", "mpx__supt_8h.html#afe0ac8d1ebddd519bed41c8d8e79fad0", null ],
    [ "MODULE_R4", "mpx__supt_8h.html#a05541487bcf6e840b918f0a6ef097024", null ],
    [ "MODULE_R5", "mpx__supt_8h.html#a68745bb3b58fd02dcee2cad3b2331def", null ],
    [ "READ", "mpx__supt_8h.html#ada74e7db007a68e763f20c17f2985356", null ],
    [ "WRITE", "mpx__supt_8h.html#aa10f470e996d0f51210d24f442d25e1e", null ],
    [ "idle", "mpx__supt_8h.html#a83abbeda22fc5e6c2b35523b64199c1c", null ],
    [ "mpx_init", "mpx__supt_8h.html#a53332c6a3107a4feed6e2e79690a6ffa", null ],
    [ "sys_alloc_mem", "mpx__supt_8h.html#a61adad2abba0a3a225c2290b3de1fe93", null ],
    [ "sys_call", "mpx__supt_8h.html#ab1cfea851a3af0faa41b89a284ef65d4", null ],
    [ "sys_free_mem", "mpx__supt_8h.html#a950663d39dbb073c9dff9cf3b5d3392c", null ],
    [ "sys_req", "mpx__supt_8h.html#afb6ff5e2e9bdde9d8971a497b6fe38ae", null ],
    [ "sys_set_free", "mpx__supt_8h.html#a2463d934fa39601c275a3ade8afd18bc", null ],
    [ "sys_set_malloc", "mpx__supt_8h.html#a9ffbe4e6d16b71fd2acbfcb27947e784", null ],
    [ "__attribute__", "mpx__supt_8h.html#a7a359e6c13403fe9d41586c9b85d5a12", null ]
];