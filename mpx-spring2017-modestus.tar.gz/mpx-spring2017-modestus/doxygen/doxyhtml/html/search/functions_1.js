var searchData=
[
  ['alloc',['alloc',['../heap_8h.html#a2b1d5a9ba11695605f74fc10cd719af5',1,'alloc(u32int size, heap *hp, int align):&#160;heap.c'],['../heap_8c.html#a06dae34c7e7c73d518de00212a7c92da',1,'alloc(u32int size, heap *h, int align):&#160;heap.c']]],
  ['allocatememfromheap',['allocateMemFromHeap',['../mcb_8h.html#a412b26c7cd2c5efa5719033127a6739c',1,'allocateMemFromHeap(size_t requestedSize):&#160;mcb.c'],['../mcb_8c.html#a412b26c7cd2c5efa5719033127a6739c',1,'allocateMemFromHeap(size_t requestedSize):&#160;mcb.c']]],
  ['allocatepcb',['allocatePCB',['../pcb_8h.html#a5c2a9f7bca10a6d45287ce6834b7167c',1,'allocatePCB(void):&#160;pcb.c'],['../pcb_8c.html#a5c2a9f7bca10a6d45287ce6834b7167c',1,'allocatePCB(void):&#160;pcb.c']]],
  ['atoi',['atoi',['../string_8h.html#a30670a60464f77af17dfb353353d6df8',1,'atoi(const char *s):&#160;string.c'],['../string_8c.html#a30670a60464f77af17dfb353353d6df8',1,'atoi(const char *s):&#160;string.c']]]
];
