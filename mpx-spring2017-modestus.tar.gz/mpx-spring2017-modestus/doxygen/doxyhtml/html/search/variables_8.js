var searchData=
[
  ['head',['head',['../structs__ll.html#a4ceb08c280f2494dd51a6edebf99fbfa',1,'s_ll::head()'],['../structfooter.html#acae33dac61c9505ff5b850f88d32dd0b',1,'footer::head()']]],
  ['heaploc',['heapLoc',['../mcb_8c.html#aa5d00c7627e28a8de2f666cbb96a14e7',1,'mcb.c']]],
  ['hour',['hour',['../structdate__time.html#a4331b46df7b89763a85ea97a246c4ee2',1,'date_time']]]
];
