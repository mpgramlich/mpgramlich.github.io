var searchData=
[
  ['_5f_5fattribute_5f_5f',['__attribute__',['../mpx__supt_8h.html#a7a359e6c13403fe9d41586c9b85d5a12',1,'__attribute__():&#160;mpx_supt.h'],['../linked__list_8h.html#a85102f38d73fa37c0aecdc6857c88f68',1,'__attribute__():&#160;linked_list.h'],['../comm__list_8h.html#a7ec0161c488281f85601e9f92d9226bd',1,'__attribute__():&#160;comm_list.h'],['../mcb_8h.html#a9705dbfcb78676d62b805c25c6cc0661',1,'__attribute__((packed)):&#160;mcb.h'],['../tables_8h.html#ad1929ba5e546bde910d88a7c08dc507b',1,'__attribute__((packed)) idt_entry:&#160;tables.h'],['../system_8h.html#a44e10bbf52e8e7e9cdf9c2c5ff22f0b0',1,'__attribute__((packed)):&#160;system.h'],['../read_img_8c.html#a6200215bb39fc3897df6ac7df00be9de',1,'__attribute__((packed)):&#160;readImg.c']]],
  ['_5f_5fend',['__end',['../heap_8c.html#a51f2442fadb8ffd3019f4aeb1b04c4d6',1,'heap.c']]],
  ['_5fend',['_end',['../heap_8c.html#a850b19392dca6170001ce200467ab610',1,'heap.c']]],
  ['_5fkmalloc',['_kmalloc',['../heap_8h.html#a9bfb8053c2382598ef5b2175f475d49a',1,'_kmalloc(u32int size, int align, u32int *phys_addr):&#160;heap.c'],['../heap_8c.html#a014b54e36b61f133f53dd509c461f35e',1,'_kmalloc(u32int size, int page_align, u32int *phys_addr):&#160;heap.c']]]
];
