var searchData=
[
  ['changedirectory',['changeDirectory',['../read_img_8c.html#a5297bd807012cb030289d6c5c457375c',1,'readImg.c']]],
  ['changeprocesspriority',['changeProcessPriority',['../pcb_8h.html#a0f7e7192cbb11b1895d900faefac2472',1,'changeProcessPriority(const char *procName, processPriority_t newPriority):&#160;pcb.c'],['../pcb_8c.html#a0f7e7192cbb11b1895d900faefac2472',1,'changeProcessPriority(const char *procName, processPriority_t newPriority):&#160;pcb.c']]],
  ['changeprocessstate',['changeProcessState',['../group___r2.html#ga69ffbf50820bccd94857e1d25b68b2c3',1,'changeProcessState(const char *processName, e_PROCESS_STATE_t state):&#160;pcb.c'],['../group___r2.html#ga69ffbf50820bccd94857e1d25b68b2c3',1,'changeProcessState(const char *processName, e_PROCESS_STATE_t newState):&#160;pcb.c']]],
  ['changeprocesssuspensionstate',['changeProcessSuspensionState',['../pcb_8h.html#a6ab558a3fdd3e7d3e14064b1a9eee773',1,'changeProcessSuspensionState(const char *processName, e_PROCESS_SUSPENSION_STATE_t suspensionState):&#160;pcb.c'],['../pcb_8c.html#a6ab558a3fdd3e7d3e14064b1a9eee773',1,'changeProcessSuspensionState(const char *processName, e_PROCESS_SUSPENSION_STATE_t suspensionState):&#160;pcb.c']]],
  ['changeprompt',['changePrompt',['../comm__list_8c.html#a8475fe07d0fd653d02ba6fc52e5b6715',1,'changePrompt(char parameters[][MAX_LENGTH]):&#160;comm_list.c'],['../comm__list_8h.html#a8475fe07d0fd653d02ba6fc52e5b6715',1,'changePrompt(char parameters[][MAX_LENGTH]):&#160;comm_list.c']]],
  ['classtostring',['classToString',['../group___r2.html#gac38459f8731293f12b7fb0170c923471',1,'classToString(e_PROCESS_CLASS_t processClass):&#160;pcb.c'],['../group___r2.html#gac38459f8731293f12b7fb0170c923471',1,'classToString(e_PROCESS_CLASS_t processClass):&#160;pcb.c']]],
  ['clear_5fbit',['clear_bit',['../paging_8h.html#adcef508c82c20a032508f871e79e1b92',1,'clear_bit(u32int addr):&#160;paging.c'],['../paging_8c.html#adcef508c82c20a032508f871e79e1b92',1,'clear_bit(u32int addr):&#160;paging.c']]],
  ['clear_5fbuff',['clear_buff',['../serial_8c.html#a337da5154672f3b359cf70d7b78f0c0d',1,'serial.c']]],
  ['clear_5fscreen',['clear_screen',['../anim_8h.html#abc40cd622f423abf44084c8f8595f57f',1,'clear_screen(void):&#160;anim.c'],['../anim_8c.html#a4953d1edcbbfc7e420c423ded1d5621a',1,'clear_screen():&#160;anim.c']]],
  ['compfunction',['compFunction',['../linked__list_8c.html#aa034eb9ccc5e7790304204b1cb0ed60f',1,'linked_list.c']]],
  ['convertfatentry',['convertFatEntry',['../read_img_8c.html#a688478c0d61ecadd3676c583d05177b3',1,'readImg.c']]],
  ['coprocessor',['coprocessor',['../interrupts_8c.html#a5c538c7b7a55e3c981780b599fcb1de7',1,'interrupts.c']]],
  ['coprocessor_5fsegment',['coprocessor_segment',['../interrupts_8c.html#a1d688a0a370977c03fa98884a6e771e9',1,'interrupts.c']]],
  ['createpcb',['createPCB',['../comm__list_8c.html#af036a4bf4166ff125a281e01f6d2e84f',1,'createPCB(const char *pcbName, const char *pcbPriority, const char *pcbClass):&#160;comm_list.c'],['../comm__list_8h.html#af036a4bf4166ff125a281e01f6d2e84f',1,'createPCB(const char *pcbName, const char *pcbPriority, const char *pcbClass):&#160;comm_list.c']]]
];
