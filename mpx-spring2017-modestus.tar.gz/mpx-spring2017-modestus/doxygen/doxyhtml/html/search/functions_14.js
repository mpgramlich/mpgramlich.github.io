var searchData=
[
  ['version',['version',['../comm__list_8c.html#ab21bb30658e69c3d4906e435384fa5fd',1,'version(char parameters[][MAX_LENGTH]):&#160;comm_list.c'],['../comm__list_8h.html#ab21bb30658e69c3d4906e435384fa5fd',1,'version(char parameters[][MAX_LENGTH]):&#160;comm_list.c']]]
];
