var searchData=
[
  ['date_5ftime',['date_time',['../structdate__time.html',1,'']]]
];
