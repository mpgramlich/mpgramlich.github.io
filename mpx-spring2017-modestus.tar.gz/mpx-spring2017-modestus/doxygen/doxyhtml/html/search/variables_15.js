var searchData=
[
  ['writeable',['writeable',['../structpage__entry.html#a2ea8d7684fe45772b6acba70d46e41d9',1,'page_entry']]]
];
