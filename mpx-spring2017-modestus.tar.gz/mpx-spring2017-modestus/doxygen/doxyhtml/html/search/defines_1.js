var searchData=
[
  ['backspace',['BACKSPACE',['../input_8h.html#a629568514359445d2fbda71d70eeb1ce',1,'input.h']]],
  ['bg_5fblack',['BG_BLACK',['../input_8h.html#a0e5ebbe291d95cf1b8f1661252722fe0',1,'input.h']]],
  ['bg_5fblue',['BG_BLUE',['../input_8h.html#a9afd14c731aa8c62d9471913c1b23b9f',1,'input.h']]],
  ['bg_5fcyan',['BG_CYAN',['../input_8h.html#a21ef237e1c4d69656729da4b34c31d8b',1,'input.h']]],
  ['bg_5fdark_5fred',['BG_DARK_RED',['../input_8h.html#adad2b39a3d0903aa525ac599f90334aa',1,'input.h']]],
  ['bg_5fgreen',['BG_GREEN',['../input_8h.html#ac351fb4567ed6655a5b39769cc5dfd04',1,'input.h']]],
  ['bg_5fmagenta',['BG_MAGENTA',['../input_8h.html#ac08aa3f07e012f1b0edafa632d5300ba',1,'input.h']]],
  ['bg_5forange',['BG_ORANGE',['../input_8h.html#aec68a2f608e468df03fee718ffe70240',1,'input.h']]],
  ['bg_5fpink',['BG_PINK',['../input_8h.html#a7052a111f0f018278a20a4e0aba1b6eb',1,'input.h']]],
  ['bg_5fred',['BG_RED',['../input_8h.html#ac317d04c219b630f9c36b0241d9d4be7',1,'input.h']]],
  ['bg_5fyellow',['BG_YELLOW',['../input_8h.html#ab31fe3e74b1137650d30ede5c9b86218',1,'input.h']]]
];
