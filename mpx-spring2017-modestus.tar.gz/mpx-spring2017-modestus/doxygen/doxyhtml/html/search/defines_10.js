var searchData=
[
  ['table_5fsize',['TABLE_SIZE',['../heap_8h.html#a032503e76d6f69bc67e99e909c8125da',1,'heap.h']]]
];
