var searchData=
[
  ['readyqueue',['readyQueue',['../pcb_8h.html#a7b1bca867586a0a58222b805dbe3be28',1,'readyQueue():&#160;pcb.c'],['../pcb_8c.html#a7b1bca867586a0a58222b805dbe3be28',1,'readyQueue():&#160;pcb.c']]],
  ['representingnode',['representingNode',['../structs__cmcb.html#a3169e74e9e75bfc6b4333b4dd3fce5d2',1,'s_cmcb::representingNode()'],['../structs__pcb__stuct.html#abf7c3f3b733400d1c48509497e34a18f',1,'s_pcb_stuct::representingNode()'],['../mcb_8h.html#af9eab6ab47e06e8aff7d76ebe1cf3fd3',1,'representingNode():&#160;mcb.h']]],
  ['reserved',['reserved',['../structpage__entry.html#af6d963f09b01571b107e6f505050c0e5',1,'page_entry::reserved()'],['../structs___entry_info.html#a869e9df5b187ad26f669fe10cffec906',1,'s_EntryInfo::reserved()'],['../read_img_8c.html#a5a6ed8c04a3db86066924b1a1bf4dad3',1,'reserved():&#160;readImg.c']]]
];
