var searchData=
[
  ['op_5fcode',['op_code',['../structparam.html#a81c8b24055c2908ebe480598aba6044c',1,'param']]],
  ['outb',['outb',['../io_8h.html#a0e661d36f40638a36550a534076f155b',1,'io.h']]],
  ['outputfile',['outputFile',['../read_img_8c.html#a9eade3b952b424b6368a36c28d6e11a5',1,'readImg.c']]],
  ['overflow',['overflow',['../interrupts_8c.html#a810f078a27a6781a7406c74985ecb761',1,'interrupts.c']]]
];
