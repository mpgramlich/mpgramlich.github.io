var searchData=
[
  ['terminal',['TERMINAL',['../pcb_8h.html#a8461d6c03c00b03bad59b5a29d27b902a9b2989c4ac8a0f9a7f46528384eaa5c7',1,'pcb.h']]]
];
