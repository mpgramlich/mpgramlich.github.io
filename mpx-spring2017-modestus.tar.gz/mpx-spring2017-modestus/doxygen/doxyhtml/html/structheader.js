var structheader =
[
    [ "index_id", "structheader.html#aec42bcd6139d12f84d54b5e6a149b276", null ],
    [ "size", "structheader.html#af8cc659f702446226bc2ebabba437d5d", null ]
];