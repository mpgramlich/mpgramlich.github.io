var structs__lmcb =
[
    [ "blockStopAddress", "structs__lmcb.html#a6f9264550050e966b061f5359445554b", null ],
    [ "lmcbType", "structs__lmcb.html#a9b5a0e464ab200d438fd1b79657dd2f9", null ],
    [ "mcbBlockSize", "structs__lmcb.html#ac3f6b7138b69587a818861fae951363e", null ]
];