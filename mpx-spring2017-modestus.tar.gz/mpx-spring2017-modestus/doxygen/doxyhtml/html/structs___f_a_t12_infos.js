var structs___f_a_t12_infos =
[
    [ "boot_signature", "structs___f_a_t12_infos.html#a5c7e3f19076fbbcceb7fb891ee4632b6", null ],
    [ "bytes_per_sector", "structs___f_a_t12_infos.html#ac9900f24f81d18411c3999ea914b9126", null ],
    [ "fat_type", "structs___f_a_t12_infos.html#a77f0c020c8462eea6229f311d8912156", null ],
    [ "ignore", "structs___f_a_t12_infos.html#a2e5d9fd3e0520220b53df77c354b6559", null ],
    [ "ignore2", "structs___f_a_t12_infos.html#affae5fdab0c15720d45fcb173c3a591b", null ],
    [ "ignore3", "structs___f_a_t12_infos.html#a1a56300e4a583ffb0b6d299ceb93d247", null ],
    [ "ignore4", "structs___f_a_t12_infos.html#a1a46d815b0ed81bb863d1bd9b0288492", null ],
    [ "max_num_of_root_dir_entries", "structs___f_a_t12_infos.html#a14eaf7f28d8feb00337dc551e9dae47b", null ],
    [ "num_of_fat_copies", "structs___f_a_t12_infos.html#adab922bdfa62f89358e84e40033e592c", null ],
    [ "num_of_heads", "structs___f_a_t12_infos.html#a95fa6574fc5936cffd3eeb2259adaf20", null ],
    [ "num_of_reserved_sectors", "structs___f_a_t12_infos.html#a1d79801bfbd4576c08d4440f0ecfd7fa", null ],
    [ "num_of_sectors_per_fat", "structs___f_a_t12_infos.html#ac0b7767d3e11a9f12c0cfe76085baa6c", null ],
    [ "sectors_per_cluster", "structs___f_a_t12_infos.html#a168822672084d9facefa83a5667a5cb3", null ],
    [ "sectors_per_track", "structs___f_a_t12_infos.html#ad1d3084c8edcc120851b57215e87b97a", null ],
    [ "total_num_of_sectors_in_file_system", "structs___f_a_t12_infos.html#a275c49f5db74083992ea1111f9a8e1c1", null ],
    [ "total_sector_count_for_fat32", "structs___f_a_t12_infos.html#a8e149b45d2a3c06aec3113ac228038d7", null ],
    [ "volume_id", "structs___f_a_t12_infos.html#aebd86e32089df7736b5e22625a6efdaa", null ],
    [ "volume_label", "structs___f_a_t12_infos.html#a7f033f386d2141afa39d7a847728b834", null ]
];