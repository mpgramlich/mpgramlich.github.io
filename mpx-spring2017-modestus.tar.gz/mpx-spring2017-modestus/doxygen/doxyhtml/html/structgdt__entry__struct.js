var structgdt__entry__struct =
[
    [ "access", "structgdt__entry__struct.html#a7457cb21f29e919a8ea62fc0110ac238", null ],
    [ "base_high", "structgdt__entry__struct.html#aa03c14867c293012449a3b18a07f45f2", null ],
    [ "base_low", "structgdt__entry__struct.html#a90f05cd7f227a34e977a639843a23275", null ],
    [ "base_mid", "structgdt__entry__struct.html#a0369f1e190c433425c5b0f40c2070715", null ],
    [ "flags", "structgdt__entry__struct.html#afac75bdf53080168c8899c442862410a", null ],
    [ "limit_low", "structgdt__entry__struct.html#ada721fbdc3e8d3feae3b07d4b82a37bd", null ]
];