var tables_8h =
[
    [ "idt_entry_struct", "structidt__entry__struct.html", "structidt__entry__struct" ],
    [ "idt_struct", "structidt__struct.html", "structidt__struct" ],
    [ "gdt_descriptor_struct", "structgdt__descriptor__struct.html", "structgdt__descriptor__struct" ],
    [ "gdt_entry_struct", "structgdt__entry__struct.html", "structgdt__entry__struct" ],
    [ "__attribute__", "tables_8h.html#ad1929ba5e546bde910d88a7c08dc507b", null ],
    [ "gdt_init_entry", "tables_8h.html#a0b5aee548c88c40ecb07741be1be2e27", null ],
    [ "idt_set_gate", "tables_8h.html#a9eca3fe1465f8d7d383551d804853139", null ],
    [ "init_gdt", "tables_8h.html#a86bb50044169930202cc403376ef40c3", null ],
    [ "init_idt", "tables_8h.html#a35fe413107af682030ab7a4b6dff19b8", null ],
    [ "access", "tables_8h.html#a360a726ac0b61d9e4e1be3ad34f80244", null ],
    [ "base", "tables_8h.html#ab5763c2b18c825c8b8fba44b2e60ddc1", null ],
    [ "base_high", "tables_8h.html#a706c81b840522a69ab6e6e941630d5e4", null ],
    [ "base_low", "tables_8h.html#a0a776dced2c26f16298425cde39f8364", null ],
    [ "base_mid", "tables_8h.html#a35c709a004babd09046db9f667ba0646", null ],
    [ "flags", "tables_8h.html#a138dda98fcd4738346af61bcca8cf4b4", null ],
    [ "limit", "tables_8h.html#a68fd3b4f6c14a331ca9b226cbf122e13", null ],
    [ "limit_low", "tables_8h.html#af9013229edfb91d4820f66b8df890ce3", null ],
    [ "sselect", "tables_8h.html#ab3f34507900160b4a9b309b4ed039e07", null ],
    [ "zero", "tables_8h.html#a94515e42687e7508877c09da81f86860", null ]
];