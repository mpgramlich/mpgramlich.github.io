var dir_7b695e8c6afbe4143ba5c5394118c9fe =
[
    [ "heap.h", "heap_8h.html", "heap_8h" ],
    [ "paging.h", "paging_8h.html", "paging_8h" ]
];