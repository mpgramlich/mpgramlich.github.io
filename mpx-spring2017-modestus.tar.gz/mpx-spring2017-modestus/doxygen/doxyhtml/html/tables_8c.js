var tables_8c =
[
    [ "gdt_init_entry", "tables_8c.html#a0b5aee548c88c40ecb07741be1be2e27", null ],
    [ "idt_set_gate", "tables_8c.html#a9eca3fe1465f8d7d383551d804853139", null ],
    [ "init_gdt", "tables_8c.html#a86bb50044169930202cc403376ef40c3", null ],
    [ "init_idt", "tables_8c.html#a35fe413107af682030ab7a4b6dff19b8", null ],
    [ "write_gdt_ptr", "tables_8c.html#ab603373c64fb0a6d51482121d0800be4", null ],
    [ "write_idt_ptr", "tables_8c.html#a77fec66a455d3275b67be5c3d7868555", null ],
    [ "gdt_entries", "tables_8c.html#ac64ff6d00454e0b88d43b55536418288", null ],
    [ "gdt_ptr", "tables_8c.html#aedb4641b02b4a269294e53be7c9b280e", null ],
    [ "idt_entries", "tables_8c.html#a3c386c59636822ce451be20cc1433a55", null ],
    [ "idt_ptr", "tables_8c.html#a76f617adbc46449bbc39e7b46504b7c4", null ]
];