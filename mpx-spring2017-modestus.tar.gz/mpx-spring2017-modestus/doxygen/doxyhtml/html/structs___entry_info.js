var structs___entry_info =
[
    [ "attributes", "structs___entry_info.html#a61891a2a856250f9fd5733c394ef279f", null ],
    [ "creation_date", "structs___entry_info.html#a6815eccd8a32c0ec73240d44889c29cd", null ],
    [ "creation_time", "structs___entry_info.html#a38b11a7ade1a5e99fc912b14d87e8ec3", null ],
    [ "extension", "structs___entry_info.html#a4c172752e5a943fc1218cdb0ed863130", null ],
    [ "file_name", "structs___entry_info.html#a8953a44b4421cb06f524ff3fabc1d353", null ],
    [ "file_size", "structs___entry_info.html#a8f6a493e1369411f3062a95431e59f7c", null ],
    [ "first_logical_cluster", "structs___entry_info.html#aa0983a044be25786e994342b4074fb6a", null ],
    [ "ignore", "structs___entry_info.html#a9c19e8efb9c5304215e9a9bf2fc61343", null ],
    [ "last_access_date", "structs___entry_info.html#a8fadeb57ca55a0e884f3c75ed6812ec8", null ],
    [ "last_write_date", "structs___entry_info.html#a27a96e4b97cf8f125416217f3aaafa31", null ],
    [ "last_write_time", "structs___entry_info.html#adcbe0968531ae8425bc8b0462e49b7d9", null ],
    [ "reserved", "structs___entry_info.html#a869e9df5b187ad26f669fe10cffec906", null ]
];