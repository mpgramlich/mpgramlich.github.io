var anim_8c =
[
    [ "busy_wait", "anim_8c.html#a251b758efbc88876a3f556ccc47fe40f", null ],
    [ "clear_screen", "anim_8c.html#a4953d1edcbbfc7e420c423ded1d5621a", null ],
    [ "start_up_anim", "anim_8c.html#a07c0f5d662e90e4f24eda36ba3e46b16", null ]
];