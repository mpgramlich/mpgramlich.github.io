var structs__process_context =
[
    [ "cs", "structs__process_context.html#ab42059eb53c837f3ee13a84559ef3f21", null ],
    [ "ds", "structs__process_context.html#a8d90dc3b66ee9de90b9c602987422d9c", null ],
    [ "eax", "structs__process_context.html#adf82ad961d4a22ffb2ff1c3a4e61a8ba", null ],
    [ "ebp", "structs__process_context.html#a4fa649d175fbf274d2e11068ca804438", null ],
    [ "ebx", "structs__process_context.html#a570ba4fa7974dcae0bcd62a329e94631", null ],
    [ "ecx", "structs__process_context.html#abefe04adbd4089fbc7b7cf5587915f87", null ],
    [ "edi", "structs__process_context.html#a5d54b5bbf492d07a9769bdeb257573c0", null ],
    [ "edx", "structs__process_context.html#aca04dd2d91612ac32eccedfc5c2f022c", null ],
    [ "eflags", "structs__process_context.html#af0a5751eb8e933ddf7cae0a3e2277071", null ],
    [ "eip", "structs__process_context.html#aecef3dcf4a85bf18e0cb7f25be9f46ff", null ],
    [ "es", "structs__process_context.html#a837fee2b01aaa11114aebf56fccb69b5", null ],
    [ "esi", "structs__process_context.html#ad81bae3c34efc5513cdedc954b247893", null ],
    [ "esp", "structs__process_context.html#ad02b439e4ebfa6aaff45d6246da155bd", null ],
    [ "fs", "structs__process_context.html#adb54401e624822659c9125b599257aa9", null ],
    [ "gs", "structs__process_context.html#af3f45f9f5befaeb1ced50a6d7bf91935", null ]
];