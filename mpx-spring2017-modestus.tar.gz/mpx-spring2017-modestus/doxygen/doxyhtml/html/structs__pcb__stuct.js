var structs__pcb__stuct =
[
    [ "context", "structs__pcb__stuct.html#a37919a4fb1d70889bbe8ddcfe6ba6b17", null ],
    [ "dataSize", "structs__pcb__stuct.html#abaaa46716f0f2187620b0042c04e6958", null ],
    [ "dataStart", "structs__pcb__stuct.html#a8df76551e88a09dd66b98deb0f9ecbc4", null ],
    [ "name", "structs__pcb__stuct.html#adcb08963ff03878f5dd24129c9f99be7", null ],
    [ "PID", "structs__pcb__stuct.html#abb43cfbd0e96ecf02dad2ba433f56886", null ],
    [ "priority", "structs__pcb__stuct.html#a612f885834f0ac6dd2f928136212d84e", null ],
    [ "processClass", "structs__pcb__stuct.html#ad0d111d2998d9b0c21b8c87df874cbf9", null ],
    [ "processState", "structs__pcb__stuct.html#a3414d9e8c0846cb7bc40c1d8b150838d", null ],
    [ "processSuspensionState", "structs__pcb__stuct.html#aa00e5f40a5a58c30a8f05930a0e6be48", null ],
    [ "programSize", "structs__pcb__stuct.html#a54cc79a0ba481257faae94273acd2c3c", null ],
    [ "programStart", "structs__pcb__stuct.html#ad1efbb40c3e4e209c82f2e983743ab39", null ],
    [ "representingNode", "structs__pcb__stuct.html#abf7c3f3b733400d1c48509497e34a18f", null ],
    [ "stack", "structs__pcb__stuct.html#a3de14f25a2689f6b760f7fc36c09ff45", null ],
    [ "stackBase", "structs__pcb__stuct.html#ae0f0e7da704e3de9b8bde295b04c522b", null ],
    [ "stackTop", "structs__pcb__stuct.html#ab19f23bae6d9f5103a1856aeec1575e7", null ]
];