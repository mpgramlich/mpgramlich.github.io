var structs__cmcb =
[
    [ "associatedLMCB", "structs__cmcb.html#af1930e2a2a97c40d5857ca4106c3a487", null ],
    [ "blockStartAddress", "structs__cmcb.html#a10cf069ed44e11f2f21cd9c94b39af97", null ],
    [ "cmcbType", "structs__cmcb.html#aeb43422b1f89904063c261b8764b3d39", null ],
    [ "mcbBlockSize", "structs__cmcb.html#a424e91c2b9462b662ff6813cb5b44730", null ],
    [ "procName", "structs__cmcb.html#a1e677d4e9539c414bda6c91703b2f1cd", null ],
    [ "representingNode", "structs__cmcb.html#a3169e74e9e75bfc6b4333b4dd3fce5d2", null ]
];