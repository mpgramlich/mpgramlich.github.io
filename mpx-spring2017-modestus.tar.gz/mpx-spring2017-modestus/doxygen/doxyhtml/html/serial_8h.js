var serial_8h =
[
    [ "COM1", "serial_8h.html#a00dbb3ab1c59e14699be9393693e2248", null ],
    [ "COM2", "serial_8h.html#a435e02f194c24c9b0e00d7cd27a1704e", null ],
    [ "COM3", "serial_8h.html#abbed02672431595364c5dd35809303a6", null ],
    [ "COM4", "serial_8h.html#a595cabb01568ba641574d24546d99c6b", null ],
    [ "init_serial", "serial_8h.html#a7078c07ff8b2c48780558549a8f7cf90", null ],
    [ "serial_poll", "serial_8h.html#a4b7cdfe478986c0d41a54f2c4a683136", null ],
    [ "serial_print", "serial_8h.html#a995827efcd4dcfb780c9fbb9645410a4", null ],
    [ "serial_println", "serial_8h.html#a3514f7abff236a4e00a6c46021ce5e22", null ],
    [ "set_serial_in", "serial_8h.html#a3f4008da5feabfb7e086f6673a81104b", null ],
    [ "set_serial_out", "serial_8h.html#ae97b87ee1f57c687e7fca6f9958e03ef", null ]
];