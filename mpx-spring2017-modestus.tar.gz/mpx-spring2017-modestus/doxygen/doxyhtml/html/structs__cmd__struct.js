var structs__cmd__struct =
[
    [ "cmdFunc", "structs__cmd__struct.html#a12f0e24fc635611fb6dea941a5415014", null ],
    [ "cmdName", "structs__cmd__struct.html#a05785ef37725660426f6881972e22de0", null ]
];