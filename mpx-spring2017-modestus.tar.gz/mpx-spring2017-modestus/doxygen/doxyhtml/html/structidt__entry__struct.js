var structidt__entry__struct =
[
    [ "base_high", "structidt__entry__struct.html#a1c6a29cae5ea9a832cf4261aaa5b43d0", null ],
    [ "base_low", "structidt__entry__struct.html#aefa75d6bfe07f1f544393b4dbccb3e76", null ],
    [ "flags", "structidt__entry__struct.html#a46c92bd8f07d5ff4e379a07b293c46af", null ],
    [ "sselect", "structidt__entry__struct.html#a85254c7df6a612f4a4b3bb470ff3370c", null ],
    [ "zero", "structidt__entry__struct.html#a0d33c8509ae77d42e680d8d11b4c8035", null ]
];