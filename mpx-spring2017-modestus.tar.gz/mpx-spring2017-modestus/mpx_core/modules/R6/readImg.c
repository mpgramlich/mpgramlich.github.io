#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>


typedef struct s_FAT12Infos Fat12Info;
struct s_FAT12Infos {
   char ignore[11];
   unsigned short bytes_per_sector;
   uint8_t sectors_per_cluster;
   uint16_t num_of_reserved_sectors;
   uint8_t num_of_fat_copies;
   uint16_t max_num_of_root_dir_entries;
   uint16_t total_num_of_sectors_in_file_system;
   char ignore2[1];
   uint16_t num_of_sectors_per_fat;
   uint16_t sectors_per_track;
   uint16_t num_of_heads;
   char ignore3[4];
   uint32_t total_sector_count_for_fat32;
   char ignore4[2];
   uint8_t boot_signature;
   uint32_t volume_id;
   char volume_label[11];
   char fat_type[8];
} __attribute__((packed));


typedef struct s_EntryInfo EntryInfo;
struct s_EntryInfo {
   char file_name[8];
   char extension[3];
   uint8_t attributes;
   uint16_t reserved;
   uint16_t creation_time;
   uint16_t creation_date;
   uint16_t last_access_date;
   char ignore[2];
   uint16_t last_write_time;
   uint16_t last_write_date;
   uint16_t first_logical_cluster;
   uint32_t file_size;
} __attribute__((packed));

//typedef struct s_FatFileEntry FatFileEntry;
typedef uint8_t FatFileEntry;
/*struct s_FatFileEntry {
    uint8_t input;
} __attribute__((packed));*/

Fat12Info infoStruct; // Create infoStruct object
EntryInfo *entArr;
FatFileEntry *FATArr;

char currentDirectory[150];
uint16_t currentDirSector = 19;//default to root dir


//forward
int changeDirectory(char *cdPath, int cdToRoot, FILE* f);

uint8_t sectorBuf[512];

/**
 * Prints the boot sector information
 */
void printBootSectorInfo()
{

   printf("\n\n\n");
   printf("Bytes Per Sector: %u\r\n", infoStruct.bytes_per_sector);
   printf("Sectors Per Cluster: %u\r\n", infoStruct.sectors_per_cluster);
   printf("Number of Reserved Sectors: %u\r\n", infoStruct.num_of_reserved_sectors);
   printf("Number of Fat Sectors: %u\r\n", infoStruct.num_of_fat_copies);
   printf("Max Number of Root Directory Entries: %u\r\n", infoStruct.max_num_of_root_dir_entries);
   printf("Total Number of Sectors in File System: %u\r\n", infoStruct.total_num_of_sectors_in_file_system);
   printf("Number of Sectors Per Fat: %u\r\n", infoStruct.num_of_sectors_per_fat);
   printf("Sectors per Track: %u\r\n", infoStruct.sectors_per_track);
   printf("Num of Heads: %u\r\n", infoStruct.num_of_heads);
   printf("Total Sector Count for FAT32: %u\r\n", infoStruct.total_sector_count_for_fat32);
   printf("Boot Signature: %u\r\n", infoStruct.boot_signature);
   printf("Volume ID: %u\r\n", infoStruct.volume_id);
   printf("Volume Label: %.11s\r\n", infoStruct.volume_label);
   printf("Fat Type: %.8s\r\n", infoStruct.fat_type);
   printf("\n\n\n");

}

/**
 * Prints the directory information.
 */
void printEntry(EntryInfo rootDirInfoStruct) 
{
   printf("file name: %.8s\r\n", rootDirInfoStruct.file_name);  
   printf("file name: %.3s\r\n", rootDirInfoStruct.extension); 
   printf("Attributes: %u\r\n", rootDirInfoStruct.attributes); 
   printf("Reserved: %u\r\n", rootDirInfoStruct.reserved); 
   printf("Creation Time: %u\r\n", rootDirInfoStruct.creation_time); 
   printf("Creation Date: %u\r\n", rootDirInfoStruct.creation_date); 
   printf("Last Access Date: %u\r\n", rootDirInfoStruct.last_access_date); 
   printf("Last Write Time: %u\r\n", rootDirInfoStruct.last_write_time); 
   printf("Last Write Date: %u\r\n", rootDirInfoStruct.last_write_date); 
   printf("First Logical Cluster: %u\r\n", rootDirInfoStruct.first_logical_cluster); 
   printf("File Size: %u\r\n", rootDirInfoStruct.file_size); 

}

/**
 * @Param FILE pointer to the file/disk image
 * Automatically read in the boot sector information and read it in to the struct
 */
void fillBootSectorStruct(FILE *f)
{
    int i = 0;
    for (i; i < sizeof(Fat12Info); i++)
    {
        ((char*) &(infoStruct))[i] = fgetc(f);
    }
}

/**
 * @Param FILE fpointer to the fild/disk image
 * @Param EntryInfo entArr, pointer to the entry being passed over
 * Automatically read in the root directory after seeking to the proper location.  Read it in to the root
 * directory structure and add it to the array of root directory information.
 */
void fillRootDirArr(FILE *f, EntryInfo *entArr)
{
    fseek(f, (19*infoStruct.bytes_per_sector) + (sizeof(EntryInfo)), SEEK_SET);
    int numOfEntries = infoStruct.max_num_of_root_dir_entries / 16;
    int i = 0;
    for (i; i < numOfEntries; i++)
    {
        EntryInfo entry;
        int j = 0;
        for (j; j < sizeof(EntryInfo); j++)
        {
            ((char *) &(entry))[j] = fgetc(f);
        }
        entArr[i] = entry;
    } 
}

/**
 * @Param FILE pointer to the disk image
 * @Param numberOfEntries number of entries to traverse through
 * Read in the FAT entries from the table.  Seeks to the right sector and reads in all sectors in FAT 1.
 */
void readFAT(FILE *f, int numOfEntries)
{
    int sector_num = 1;
    fseek(f, sector_num*512, SEEK_SET);
    
    int amountToRead = (9-1)*512;
    int amountRead=0;
    
    while(amountToRead-amountRead)
    {
        amountRead+=fread(&(FATArr[amountRead]),1,amountToRead-amountRead,f);
    }
}


/**
 * @Param FILE . Takes in the file pointer to the file.
 * @Param filename . Takes in the file name to print contents of
 * @Param arr 
 * @Returns out a single byte of the file passed in.
 */
EntryInfo outputFile(FILE *f, char *filename, EntryInfo* arr)
{
    changeDirectory(filename,0,f);
    int fatEnt;
    int amountRead = 0;
    int amountToRead = 0;
    fseek(f,((currentDirSector==19)?19:currentDirSector+31)*infoStruct.bytes_per_sector,SEEK_SET);
    amountToRead = infoStruct.bytes_per_sector;
    amountRead=0;
    while(amountToRead-amountRead)
    {
        amountRead+=fread(&(sectorBuf[amountRead]),1,amountToRead-amountRead,f);
    }
    char* fileParse = strtok(filename, ".");
    int i = 0;
    for (i; i < infoStruct.max_num_of_root_dir_entries / 16; i++)
    {
        char * entryParse = strtok(arr[i].file_name, " ");
        if (strcasecmp(fileParse, arr[i].file_name) == 0)
        {
            return arr[i];
        }
    }
}

/**
 * @Param FATentry item
 * Takes the Fat entry and returns the next entry from the FAT table.
 */
uint16_t convertFatEntry(uint16_t fatEntry)
{
    uint8_t fVal = FATArr[3*fatEntry/2];
    uint8_t sVal = FATArr[1+3*fatEntry/2];
    uint16_t temp = (sVal<<8)|fVal;
    
    if (fatEntry % 2) //oddddd
    {
        return (temp >> 4) & 0x0fff;       	
    }
    else //evennnnn
    {
        return temp & 0x0fff;
    }
}

/**
 * Print the root directory structure
 */
void printRootDir()
{
    int i = 0;
    for (i; i < infoStruct.max_num_of_root_dir_entries / 16; i++)
    {
        if (entArr[i].file_name[0] != 0xFFFFFFE5 && entArr[i].file_name[0] != 0x00)
        {
            char *filename = strtok(entArr[i].file_name, " ");
            printf("%s.%s\t", filename, entArr[i].extension);
        }
    }
    printf("\n");
}

/**
* @Param array of EntryList
* @Param op character pointer being passed in 
* Lists the files in the current directory
* If a character parameter is passed it, then print all files with that name or type
*/
void list(EntryInfo* arr, char* op)
{
  /*  if (strlen(op))
    {
        op[5] = 0;
        if (op[0] == '*')
        {
            char ext[4];
            strncpy(ext, &op[2], 3);
            ext[3] = 0;
            int i = 0;
            for (i; i < infoStruct.max_num_of_root_dir_entries / 16; i++)
            {
                char* fExt = strtok(arr[i].extension, " ");
                if (!strcasecmp(fExt, ext))
                {
                    printf("%s.%s\t", strtok(entArr[i].file_name, " "), fExt);
                }
            }
        }
        else
        {
            
        }
    }
    else
    {*/
        int i = 1;
        for (i; i < infoStruct.max_num_of_root_dir_entries / 16; i++)
        {
            if ((arr[i].file_name[0]&0xff) != 0xE5 && arr[i].file_name[0] != 0x00)
            {
                char *filename = strtok(arr[i].file_name, " ");
                printf("%.8s.%.3s\t", filename, arr[i].extension);
            }
        } 
   // } 
    printf("\r\n"); 
}


/**
 * @Param FILE Takes in a pointer to the file
 * @Param filename Takes in the filename to get the contents of.
 * prints out the contents from the file passed in.
 */
void type(FILE *f, char *filename, EntryInfo* arr)
{
    EntryInfo entry = outputFile(f, filename, arr);

    char *ext = strtok(entry.extension, " ");

    if (!(strcasecmp(ext, "txt") && strcasecmp(ext, "c") && strcasecmp(ext, "bat")))
    { 
        
        int fatEnt = entry.first_logical_cluster;
        int amountWritten = 0;
        int totalAmountRead = 0;
        int amountRead = 0;
        int amountToRead = entry.file_size;
        uint8_t sectorBuf[infoStruct.bytes_per_sector];
        
        int contInt = 1;
        while (contInt)
        {  
            fseek(f,(fatEnt+31)*infoStruct.bytes_per_sector,SEEK_SET);
            amountToRead = ((entry.file_size-totalAmountRead)>512)?512:entry.file_size-totalAmountRead;
            amountRead=0;
            char cont[3];
            while(amountToRead-amountRead)
            {
                amountRead+=fread(&(sectorBuf[amountRead]),1,amountToRead-amountRead,f);
                totalAmountRead+=amountRead;
            }
            amountWritten=0;
            while(amountRead-amountWritten)
            {
                amountWritten+=fwrite(&(sectorBuf[amountWritten]),1,amountRead-amountWritten,stdout);
                printf("\n\nEnter 'yes' to continue or 'no' to quit:\n> ");
                scanf("%s", cont);
                if (!strcmp(cont, "no")) {contInt = 0;  break;}
            }
            if (contInt == 0) {break;} 
            if ((convertFatEntry(fatEnt) >= 4088 && convertFatEntry(fatEnt) <= 4095))
            { 
                break;
            }
            fatEnt = convertFatEntry(fatEnt);
         }
         printf("\n\n\nyes\n\n\n");
    }
    else
    {
        printf("That file is not supported by type.\r\n");
    }
}


int filerename(const char *__old, const char *__new)
{

}


char *trim(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)  // All spaces?
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator
  *(end+1) = 0;

  return str;
}


/*
 * @Param cdPath, pointer to the path to be changed to
 * @Param cdToRoot flag tells if paths are relative to root
 * @Param FILE pointer to the disk image
 * Changes the current directory
 */
int changeDirectory(char *cdPath, int cdToRoot, FILE* f)
{
    int fatEnt;
    int amountRead = 0;
    int amountToRead = 0;

    if(cdToRoot)
    {
        memset(currentDirectory,0,150);
        currentDirectory[0] = '/';
        currentDirSector = 19;
    }
    else
    {
        memset(sectorBuf,0,infoStruct.bytes_per_sector);
        
        //if first character, after trim, is /, we are working from root.
        //recurse to root
        if(cdPath[0]=='/')
        {
            changeDirectory(cdPath, 1, f);
        }

        fseek(f,((currentDirSector==19)?19:currentDirSector+31)*infoStruct.bytes_per_sector,SEEK_SET);
        amountToRead = infoStruct.bytes_per_sector;
        amountRead=0;
        while(amountToRead-amountRead)
        {
            amountRead+=fread(&(sectorBuf[amountRead]),1,amountToRead-amountRead,f);
        }

        //strtok input dir
        char *token = strtok(cdPath,"/");
        int i = 0, j = 0;
        for(i; token && i<16; i++)
        {
            for(j=0; j<8;j++)
            {
                if(((EntryInfo*)sectorBuf)[i].file_name[j]==' ')
                {
                    ((EntryInfo*)sectorBuf)[i].file_name[j]=0;
                }
            }

            if(((EntryInfo*)sectorBuf)[i].file_name[0]==0)
            {
                //all entries including and following are empty, exit
                break;
            }
            else if((!strncmp(token,((EntryInfo*)sectorBuf)[i].file_name,8)) && (((EntryInfo*)sectorBuf)[i].attributes)&0x18)
            {
                //printf("checking %.8s\r\n",((EntryInfo*)sectorBuf)[i].file_name);
                strcat(currentDirectory,((EntryInfo*)sectorBuf)[i].file_name);
                strcat(currentDirectory,"/");
                currentDirSector = ((EntryInfo*)sectorBuf)[i].first_logical_cluster;
                fseek(f,((currentDirSector==19)?19:currentDirSector+31)*infoStruct.bytes_per_sector,SEEK_SET);
                amountToRead = infoStruct.bytes_per_sector;
                amountRead=0;
                while(amountToRead-amountRead)
                {
                    amountRead+=fread(&(sectorBuf[amountRead]),1,amountToRead-amountRead,f);
                }
                token = strtok(0,"/");
            }

        }
    }
}


int main(int argc, char *argv[])
{
    if(argc == 1)
    {
        printf("Missing disk file!\r\n");
        printf("Usage: ./readImg <inputFile> [fileToDump]\r\n");
        return -1;
    }
    FILE *f = fopen(argv[1], "rb");
    if(!f)
    {
        printf("Could Not open input disk file: %s", argv[1]);
        return -1;
    }
    
    fillBootSectorStruct(f);
    
    entArr = malloc((infoStruct.max_num_of_root_dir_entries / 16) * sizeof(EntryInfo));
    
    fillRootDirArr(f, entArr);
    
    int numOfEntries = (infoStruct.num_of_sectors_per_fat * infoStruct.bytes_per_sector) * (8.0/12.0);
    
    FATArr = malloc(8*512); //change later
    readFAT(f, numOfEntries);

    memset(currentDirectory,0,150);
    changeDirectory(0,1,f);


    if (argc == 2)
    {
        
        char input[50];
        while(1)
        {
            printf("%s > ",&(currentDirectory[0]));
            size_t size = 50;
            fgets(input, size, stdin); 

            strcpy(input, strtok(input, "\n"));

            char par[25][25];
            memset(par, 0, 25*25);
            const char *tokens = " ";
            char *token = strtok(input, tokens);
            int i = 0;

            while (token != NULL) 
            {
                strcpy(par[i], token);
                token = strtok(NULL, tokens);
                i++;
            }
            
            if (!strcmp("ls", par[0]))
            {
                int fatEnt;
                int amountRead = 0;
                int amountToRead = 0;
                fseek(f,((currentDirSector==19)?19:currentDirSector+31)*infoStruct.bytes_per_sector,SEEK_SET);
                amountToRead = infoStruct.bytes_per_sector;
                amountRead=0;
                while(amountToRead-amountRead)
                {
                    amountRead+=fread(&(sectorBuf[amountRead]),1,amountToRead-amountRead,f);
                }
                list((EntryInfo*) &(sectorBuf[0]), par[1]);
            }
            else if(!strcmp("cd", par[0]))
            {
                //memcpy((par[1]),"SUBDIR",7);
                changeDirectory(par[1], 0, f);
            }
            else if(!strcmp("pbs", par[0]))
            {
                printBootSectorInfo();
            }
            else if(!strcmp("prd", par[0]))
            {
                printRootDir();
            }
            else if(!strcmp("type", par[0]))
            {
                int fatEnt;
                int amountRead = 0;
                int amountToRead = 0;
                fseek(f,((currentDirSector==19)?19:currentDirSector+31)*infoStruct.bytes_per_sector,SEEK_SET);
                amountToRead = infoStruct.bytes_per_sector;
                amountRead=0;
                while(amountToRead-amountRead)
                {
                    amountRead+=fread(&(sectorBuf[amountRead]),1,amountToRead-amountRead,f);
                }
                type(f, par[1],(EntryInfo*) &(sectorBuf[0]));
            }
            else if(!strcmp("quit", par[0]))
            {
                return 0;
            }
            else if(!strcmp("help", par[0]))
            {
                printf("Possible commands\n____________________\n"); 
                printf("    ls     |  list all directory files and \n\t\t subdirectories in the current directory\n");
                printf("    cd     |  change directory to a subdirectory \n\t\t of the current directory\n");
                printf("    pbs    |  print the boot sector information\n");
                printf("    prd    |  print the root directory\n");
                printf("    type   |  prints out the contents of the given \n\t\t file.  ex: type '1984.TXT'\n");
                printf("    quit   |  exits the file system\n");
            }
            else printf("Invalid command\n");
        }
    }
    else if (argc == 3)
    {
        //print out file it wants

        EntryInfo entry = outputFile(f, argv[2],(EntryInfo*)sectorBuf);

        int fatEnt = entry.first_logical_cluster;
        int amountWritten = 0;
        int totalAmountRead = 0;
        int amountRead = 0;
        int amountToRead = entry.file_size;
        uint8_t sectorBuf[infoStruct.bytes_per_sector];
        
        while (1)
        {  
            fseek(f,(fatEnt+31)*infoStruct.bytes_per_sector,SEEK_SET);
            amountToRead = ((entry.file_size-totalAmountRead)>512)?512:entry.file_size-totalAmountRead;
            amountRead=0;
            while(amountToRead-amountRead)
            {
                amountRead+=fread(&(sectorBuf[amountRead]),1,amountToRead-amountRead,f);
                totalAmountRead+=amountRead;
            }
            amountWritten=0;
            while(amountRead-amountWritten)
            {
                amountWritten+=fwrite(&(sectorBuf[amountWritten]),1,amountRead-amountWritten,stdout);
            }
            if ((convertFatEntry(fatEnt) >= 4088 && convertFatEntry(fatEnt) <= 4095))
            { 
                break;
            }
            fatEnt = convertFatEntry(fatEnt);
         }
    }
    
    else
    {
        printf("This input is not valid");
    }
    
}
