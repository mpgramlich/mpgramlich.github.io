#ifndef COMM_LIST_H
#define COMM_LIST_H

#include <core/mcb.h>
#include <input.h>

#define MAX_CMD_LIST_LENGTH 50

typedef struct s_cmd_struct cmd_struct_t;

struct s_cmd_struct
{
    const char* cmdName;
    int (*cmdFunc)(char [][MAX_LENGTH]);
};

extern cmd_struct_t cmdArray[MAX_CMD_LIST_LENGTH];

/**
 * @brief getNumDaysInMonth is a helper function to allow the easy retrieval
 * of days in a month based on the month input by the user.
 * @param month is an integer from 1-12
 * @param year is an integer representing the year to check if it's a leap year
 * @return the number of days in the corresponding month
 */
int getNumDaysInMonth(int month, int year);

int isEmpty(char parameters[][MAX_LENGTH]);

/**
 * @brief helpFunc calls the other help functions
 * @param parameters used to determine if just help or help set date was called
 * @return an integer.
 */
int helpFunc(char parameters[][MAX_LENGTH]);

/**
 * @brief help prints out a list of all possible commands and a brief description of what they do.
 */
void help();

/**
 * @brief helpGetVersion prints the help instructions for version. Tells the user what
 * the command and arguments for 'version' are.
 *
 * No parameters are needed to be passed in, as it just prints to the console.
 */
int helpGetVersion();

/**
 * @brief helpGetDate prints the help instructions for get date.  Tells
 * the user what the command and arguments for 'get date' are.
 *
 * No parameters are needed to be passed in, as it just prints to the console.
 */
void helpGetDate();

/**
 * @brief helpSetDate prints the help instructions for set date.  Tells the user what
 * the command and arguments for 'set date' are.
 *
 * No parameters are needed to be passed in, as it just prints to the console.
 */
void helpSetDate();

/**
 * @brief helpLoadR3 prints out the help commands for helpLoadR3
 * Loads all of the processes from procsr3
 */
void helpLoadR3();

/**
 * @brief helpGetTime prints the help instructions for get time.  Tells the user what the
 * commands and arguments for 'get time' are.
 *
 * No parameters are needed to be passed in, as it just prints to the console.
 */
void helpGetTime();

/**
 * @brief helpSetTime prints the help instructions for set time.  Tells the user what
 * the command and arguments for 'set time' are.
 *
 * No parameters are needed to be passed in, as it just prints to the console.
 */
void helpSetTime();

/**
 * @brief helpShutdown prints the help instructions for set date.  Tells the user what
 * the command and arguments for 'set date' are.
 *
 * No parameters are needed to be passed in, as it just prints to the console.
 */
void helpShutdown();

/**
 * @brief helpVersion prints the help instructions for using the version command.
 * No arguments are required.
 */
void helpVersion();

/**
 * @brief helpDate prints out the help information for date, for date --set and date --get
 * @param parameters takes in a char array
 *
 * [0] can be --set or --get or empty
 * --set tells the parameters and usage for setting the date
 * --get tells the parameters and usage for getting the date
 */
void helpDate(char parameters[][MAX_LENGTH]);

/**
 * @brief helpTime prints out the help information for time, for time --set and time --get
 * @param parameters takes in a char array
 *
 * [0] can be --set or --get or empty
 * --set tells the parameters and usage for setting the time
 * --get tells the parameters and usage for getting the time
 */
void helpTime(char parameters[][MAX_LENGTH]);

/**
 * @brief helpPcb takes in the command to print the help information for.  Calls the proper function to print the help information for the selected command.
 * @param parameters takes in a character array
 *
 */
void helpPcb(char parameters[][MAX_LENGTH]);

/**
 * @brief helpPcbPrint prints out the commands for PCBs.
 */
void helpPcbPrint();



/**
 * @brief helpSuspendPCB prints the help instructions for the suspendPCB command.
 */
void helpSuspendPCB();

/**
 * @brief helpResumePCB prints out the parameters and usage of the resume pcb command.
 */
void helpResumePCB();

/**
 * @brief helpResumeAll prints out the parameters and usage of the resume all command.
 */
void helpResumeAll();

/**
 * @brief helpSetPriority prints out to console the parameters and usage for --setpriority.
 */
void helpSetPriority();

void helpShowPCB();

/**
 * @brief helpShowAllProcesses shows all processes in the system.
 * Takes in no parameters and prints out to the console.
 */
void helpShowAllProcesses();

/**
 * @brief helpShowReadyProcesses shows the parameters and usage for showing ready PCBs.
 */
void helpShowReadyProcesses();

/**
 * @brief helpShowBlockedProcesses shows the parameters and usage for showing the blocked PCBs.
 */
void helpShowBlockedProcesses();

/**
 * @brief helpCreatePCB prints out the parameters and usage for createPCB.
 */
void helpCreatePCB();

/**
 * @brief helpDeletePCB prints out the parameters and usage for deleting a PCB.
 */
void helpDeletePCB();

/**
 * @brief helpBlockPCB prints out the parameters and usage for blocking a PCB.
 */
void helpBlockPCB();

/**
 * @brief helpUnblockPCB prints out the parameters and usage for unblocking a PCB.
 */
void helpUnblockPCB();


/* _______________________________________________ */

/**
 * @brief version prints out the current version of the operating system.
 * It will print out R1, R2, R3, ... depending on the current module.
 *
 * No parameters are required.
 */
int version(char parameters[][MAX_LENGTH]);

int date(char parameters[][MAX_LENGTH]);

/**
 * @brief getDate Get the current date from the system.
 *
 * No parameters required, prints out a date.
 */
void getDate();

/**
 * @brief setDate sets the system date using the input from the user.
 * @param parameters take the unconsumed parameters from commhandler from the command prompt.
 *
 * Checks if the parameters exist, otherwise will return improper command.
 * If paramters exist, will check to make sure the parameters are correct, such that the days and months
 * are valid.
 *
 * Calls set_date from rtc to set the current date.
 * After setting the date, will print the current date.
 *
 * Ex. Command is "date --set '03/12/2017', 03, 12 , 2017 are passed over.
 * parameters[0] is the day
 * parameters[1] is the month
 * parameters[2] is the year
 */
void setDate(char parameters[][MAX_LENGTH]);

int time(char parameters[][MAX_LENGTH]);

/**
 * @brief getTime this function has the side-effect of printing the current time to the terminal.
 *
 * No parameters are required.
 */
void getTime();

/**
 * @brief setTime sets the current system time from the users input.
 * @param parameters take the unconsumed parameters from commhandler from the command prompt.
 *
 * Calls set_time from rtc to set the sytem time.
 * Then prints out the current time.
 *
 * Ex. Command is "time --set '14:20.55', 14, 20 , 55 are passed over.
 * parameters[1] is the hour (24 hour)
 * parameters[2] is the minute
 * parameters[3] is the second
 */
void setTime(char parameters[][MAX_LENGTH]);

/**
 * @brief shutdownFunc shuts down the OS.
 * @param parameters the input from the user
 * @return an integer, if the user confirms to shutdown will return 9, otherwise will return 0.
 */
int shutdownFunc(char parameters[][MAX_LENGTH]);



/**
 * @brief takes in parameters and makes sure its valid then runs what you want to. 
 * @param Type anything in command line, valid inputs work.
 * \ingroup R5
 */
int pcbFunc(char parameters[][MAX_LENGTH]);

/**
 * @brief suspendPCB suspends the pcb passed in by the user
 * @param parameters takes in the name of the PCB to be suspended.
 * @return an integer, normally 0.
 */
int suspendPCB(char parameters[][MAX_LENGTH]);

/**
 * @brief resumePCB resumes the PCB passed in by the user
 * @param parameters - the rest of the input from the user, the name of the PCB to be resumed.
 * @return an integer, normally 0.
 */
int resumePCB(char parameters[][MAX_LENGTH]);

/**
 * @brief setPriority sets the priority of a particular process
 * @param procName is the process name to be modified
 * @param procPrio is the new priority of the PCB
 * @return an integer, normally 0
 * procPrio is the process
 * procName is the priority
 */
int setPriority(char * procName, char * procPrio);

/**
 * @brief showPCB shows the process information for the process requested by the user
 * @param parameters the name of the PCB to show the information of.
 */
int showPCB(char parameters[][MAX_LENGTH]);

/**
 * @brief showAllProcesses shows all processes in the system.
 */
int showAllProcesses(char parameters[][MAX_LENGTH]);

/**
 * @brief showReadyProcesses shows all processes that are ready, in the ready queue (linked list).
 */
int showReadyProcesses(char parameters[][MAX_LENGTH]);

/**
 * @brief showBlockedProcesses shows all processes that are blocked.
 * @return an integer, normally 0.
 */
int showBlockedProcesses(char parameters[][MAX_LENGTH]);

/**
 * @brief createPCB creates a new PCB and allocates memory for the PCB.
 * @param pcbName the name of the PCB to be created
 * @param pcbPriority the priority of the PCB to be created
 * @param pcbClass the class of the PCB to be created
 * @return an integer, normally 0.
 */
int createPCB(const char* pcbName, const char* pcbPriority, const char* pcbClass);

/**
 * @brief deletePCB deletes the PCB requested by the user.
 * @param parameters takes in the name of the PCB to be deleted.
 * @return an integer, normally 0.
 */
int deletePCB(char parameters[][MAX_LENGTH]);

/**
 * @brief blockPCB blocks the specified PCB
 * @param parameters takes in the name of the PCB to move to the blocked queue.
 * @return an integer, normally 0.
 */
int blockPCB(char parameters[][MAX_LENGTH]);

/**
 * @brief unblockPCB unblocks the specified PCB.
 * @param parameters takes in the name of the PCB to move from the blocked queue to the ready queue.
 */
int unblockPCB(char parameters[][MAX_LENGTH]);

/**
 * @brief stops the exection of commhand and executes each process in the ready queue
 * @param parameters takes no parameters so they are voided
 * \ingroup R3
 */
int yield();

/**
 * @brief loads all processes into memory in a suspended ready state at any priority of the users choosing
 * @param parameters tales no parameters so they are voided
 * \ingroup R3
 */
int loadr3(char parameters[][MAX_LENGTH]);


/* MCB FUNCTIONS */


/**
 * @brief takes in whatever you are looking for and checks to see if it can be done for mcb
 * @param type anthing into the command line prompt
 * \ingroup R5
 */
int mcbFunc(char parameters[][MAX_LENGTH]);

/* HELP FUNCS */

/**
 * @brief prints the help for the change prompt command
 * \ingroup R1
 */
void helpCP();

/**
 * @brief The command handler for mcb's checking for valid input
 * @param Valid commands for each function
 * \ingroup R5
 */
void helpMCB(char parameters[][MAX_LENGTH]);


/**
 * @brief Prints the help menu for all mcb functions
 * @param Type: help mcb
 * \ingroup R5
 */
void helpMcbPrint();


/**
 * @brief prints the all details about the initheap func 
 * @param Type: help --initHeap
 * \ingroup R5
 */
void helpMCBInitHeap();


/**
 * @brief Prints the details for Allocating an mcb 
 * @param Type: help --allocate
 * \ingroup R5
 */
void helpMCBAllocate();


/**
 * @brief Prints the details for freeing an mcb 
 * @param Type: help --freemem
 * \ingroup R5
 */
void helpMCBFreeMem();


/**
 * @brief Prints details for IsEmpty func
 * @param Type: help --isempty
 * \ingroup R5
 */
void helpMCBIsEmpty();


/**
 * @brief Prints details for showing all the free memory blocks in the heap 
 * @param Type: help --showfree
 * \ingroup R5
 */
void helpMCBShowFree();


/**
 * @brief Prints details for showing all the allocated memory blocks in the heap 
 * @param Type: help --showallocated
 * \ingroup R5
 */
void helpMCBShowAllocated();

/* END MCB FUNCTIONS */
char *getPrompt();

int changePrompt(char parameters[][MAX_LENGTH]);

















#endif // COMM_LIST_H
