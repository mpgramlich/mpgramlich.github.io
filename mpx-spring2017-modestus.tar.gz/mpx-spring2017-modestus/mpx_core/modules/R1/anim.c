#include <core/serial.h>


/**
 *	RE-WRITE THIS SO THAT IS IS MORE EFFICIENT
 * RUNNING 9999999 ASM CALLS TO WAIT IS DUMB
 * INTERRUPTS OR CHECK TIME WOULD BE BETTER
 */

void busy_wait() {
	int i = 0;
	for (; i < 9999999; i++) {
		asm volatile("nop");
	}
}

void clear_screen() {
    serial_println("\033[2J");
}

void start_up_anim() {
	serial_println("                 .------------.       								 ");
	serial_println("             .--'  o     . .   `--.      							 ");
	serial_println("          .-'   .    O   .       . `-.      						 ");
	serial_println("       .-'@   @@@@@@@   .  @@@@@      `-.   						 ");
	serial_println("      /@@@  @@@@@@@@@@@   @@@@@@@   .    \\ 						 ");
	serial_println("    ./    o @@@@@@@@@@@   @@@@@@@       . \\.  					 ");
	serial_println("   /@@  o   @@@@@@@@@@@.   @@@@@@@   O      \\ 					 ");
	serial_println("  /@@@@   .   @@@@@@@o    @@@@@@@@@@     @@@ \\   				 ");
	serial_println("  |@@@@@               . @@@@@@@@@@@@@ o @@@@| 					 ");
	serial_println(" /@@@@@  O  `.-./  .      @@@@@@@@@@@@    @@  \\  				 ");
	serial_println(" | @@@@    --`-'       o     @@@@@@@@ @@@@    |    			    ");
	serial_println(" |@ @@@        `    o      .  @@   . @@@@@@@  |    				 ");
	serial_println(" |       @@  @         .-.     @@@   @@@@@@@  |  				    ");
	serial_println(" \\  . @        @@@     `-'   . @@@@   @@@@  o /  				 ");
	serial_println("  |      @@   @@@@@ .           @@   .       | 					 ");
	serial_println("  \\     @@@@  @\\@@    /  .  O    .     o   . /  				 ");
	serial_println("   \\  o  @@     \\ \\  /         .    .       /  				 ");
	serial_println("    `\\     .    .\\.-.___   .      .   .-. /' 					 ");
	serial_println("      \\           `-'                `-' / 						 ");
	serial_println("       `-.   o   / |     o    O   .   .-'   						 ");
	serial_println("          `-.   /     .       .    .-'       						 ");
	serial_println("             `--.       .      .--'      							 ");
	serial_println("                 `------------'       								 ");
	
	busy_wait();
	clear_screen();

	serial_println("                  ------------.	 ");
	serial_println("              --'  o     . .   `--.	 ");
	serial_println("           -'   .    O   .       . `-.	 ");
	serial_println("         '@   @@@@@@@   .  @@@@@      `-.	 ");
	serial_println("        @@  @@@@@@@@@@@   @@@@@@@   .    \\	 ");
	serial_println("          o @@@@@@@@@@@   @@@@@@@       . \\.	 ");
	serial_println("        o   @@@@@@@@@@@.   @@@@@@@   O      \\	 ");
	serial_println("     @@   .   @@@@@@@o    @@@@@@@@@@     @@@ \\	 ");
	serial_println("    @@@@               . @@@@@@@@@@@@@ o @@@@|	 ");
	serial_println("    @@@  O  `.-./  .      @@@@@@@@@@@@    @@  \\ ");
	serial_println("    @@@    --`-'       o     @@@@@@@@ @@@@    |	 ");
	serial_println("    @@@        `    o      .  @@   . @@@@@@@  |	 ");
	serial_println("         @@  @         .-.     @@@   @@@@@@@  |	 ");
	serial_println("    . @        @@@     `-'   . @@@@   @@@@  o /	 ");
	serial_println("         @@   @@@@@ .           @@   .       |	 ");
	serial_println("        @@@@  @\\@@    /  .  O    .     o   . /	 ");
	serial_println("      o  @@     \\ \\  /         .    .       /	 ");
	serial_println("           .    .\\.-.___   .      .   .-. /'	 ");
	serial_println("                  `-'                `-' /	 ");
	serial_println("         .   o   / |     o    O   .   .-'	 ");
	serial_println("           -.   /     .       .    .-'	 ");
	serial_println("              --.       .      .--'	 ");
	serial_println("                  ------------'          ");

	busy_wait();
	clear_screen();

	serial_println("                    ----------.	 ");
	serial_println("                   o     . .   `--.	 ");
	serial_println("                .    O   .       . `-.	 ");
	serial_println("              @@@@@@@   .  @@@@@      `-.	 ");
	serial_println("             @@@@@@@@@@   @@@@@@@   .    \\	 ");
	serial_println("            @@@@@@@@@@@   @@@@@@@       . \\.	 ");
	serial_println("            @@@@@@@@@@@.   @@@@@@@   O      \\	 ");
	serial_println("              @@@@@@@o    @@@@@@@@@@     @@@ \\	 ");
	serial_println("                       . @@@@@@@@@@@@@ o @@@@|	 ");
	serial_println("            `.-./  .      @@@@@@@@@@@@    @@  \\ ");
	serial_println("           --`-'       o     @@@@@@@@ @@@@    |	 ");
	serial_println("               `    o      .  @@   . @@@@@@@  |	 ");
	serial_println("          @  @         .-.     @@@   @@@@@@@  |	 ");
	serial_println("               @@@     `-'   . @@@@   @@@@  o /	 ");
	serial_println("              @@@@@ .           @@   .       |	 ");
	serial_println("           @  @\\@@    /  .  O    .     o   . /	 ");
	serial_println("                \\ \\  /         .    .       /	 ");
	serial_println("                .\\.-.___   .      .   .-. /'	 ");
	serial_println("                  `-'                `-' /	 ");
	serial_println("                 / |     o    O   .   .-'	 ");
	serial_println("                /     .       .    .-'	 ");
	serial_println("                        .      .--'	 ");
	serial_println("                    ----------'          ");
	
	busy_wait();
	clear_screen();

	serial_println("                       -------.	 ");
	serial_println("                         . .   `--.	 ");
	serial_println("                         .       . `-.	 ");
	serial_println("                        .  @@@@@      `-.	 ");
	serial_println("                     @@   @@@@@@@   .    \\	 ");
	serial_println("                     @@   @@@@@@@       . \\.	 ");
	serial_println("                    @@@.   @@@@@@@   O      \\	 ");
	serial_println("                    @o    @@@@@@@@@@     @@@ \\	 ");
	serial_println("                       . @@@@@@@@@@@@@ o @@@@|	 ");
	serial_println("                          @@@@@@@@@@@@    @@  \\	 ");
	serial_println("                       o     @@@@@@@@ @@@@    |	 ");
	serial_println("                    o      .  @@   . @@@@@@@  |	     ");
	serial_println("                       .-.     @@@   @@@@@@@  |	 ");
	serial_println("                       `-'   . @@@@   @@@@  o /	 ");
	serial_println("                    .           @@   .       |	 ");
	serial_println("                      /  .  O    .     o   . /	 ");
	serial_println("                     /         .    .       /	 ");
	serial_println("                     ___   .      .   .-. /'	 ");
	serial_println("                                     `-' /	 ");
	serial_println("                         o    O   .   .-'	 ");
	serial_println("                      .       .    .-'	 ");
	serial_println("                        .      .--'	 ");
	serial_println("                       -------'          ");

	busy_wait();
	clear_screen();
	
	serial_println("                         -----.	 ");
	serial_println("                           .   `--.	 ");
	serial_println("                                 . `-.	 ");
	serial_println("                            @@@@      `-.	 ");
	serial_println("                            @@@@@   .    \\	 ");
	serial_println("                             @@@@       . \\.	 ");
	serial_println("                             @@@@@   O      \\	 ");
	serial_println("                             @@@@@@@     @@@ \\	 ");
	serial_println("                             @@@@@@@@@ o @@@@|	 ");
	serial_println("                             @@@@@@@@@    @@  \\ ");
	serial_println("                             @@@@@@@@ @@@@    |	 ");
	serial_println("                              @@   . @@@@@@@  |	 ");
	serial_println("                               @@@   @@@@@@@  |	 ");
	serial_println("                             . @@@@   @@@@  o /	 ");
	serial_println("                                @@   .       |	 ");
	serial_println("                                 .     o   . /	 ");
	serial_println("                               .    .       /	 ");
	serial_println("                                  .   .-. /'	 ");
	serial_println("                                     `-' /	 ");
	serial_println("                              O   .   .-'	 ");
	serial_println("                              .    .-'	 ");
	serial_println("                               .--'	 ");
	serial_println("                         -----'          ");

	busy_wait();
	clear_screen();

	serial_println("                           ---.	 ");
	serial_println("                               `--.	 ");
	serial_println("                                 . `-.	 ");
	serial_println("                                      `-.	 ");
	serial_println("                                    .    \\	 ");
	serial_println("                                        . \\.	 ");
	serial_println("                                     O      \\	 ");
	serial_println("                                         @@@ \\	 ");
	serial_println("                                       o @@@@|	    ");
	serial_println("                                          @@  \\	 ");
	serial_println("                                      @@@@    |	 ");
	serial_println("                                      @@@@@@  |	 ");
	serial_println("                                      @@@@@@  |	 ");
	serial_println("                                      @@@@  o /	 ");
	serial_println("                                             |	 ");
	serial_println("                                       o   . /	 ");
	serial_println("                                            /	 ");
	serial_println("                                      .-. /'	 ");
	serial_println("                                     `-' /	 ");
	serial_println("                                  .   .-'	 ");
	serial_println("                                   .-'	 ");
	serial_println("                               .--'	 ");
	serial_println("                           ---'          ");

	busy_wait();
	clear_screen();

	serial_println("                             -.	 ");
	serial_println("                                 -.	 ");
	serial_println("                                    -.	 ");
	serial_println("                                      `-.	 ");
	serial_println("                                         \\	 ");
	serial_println("                                          \\.	 ");
	serial_println("                                            \\	 ");
	serial_println("                                           @ \\	 ");
	serial_println("                                           @@|	 ");
	serial_println("                                              \\	      ");
	serial_println("                                              |	 ");
	serial_println("                                              |	 ");
	serial_println("                                              |	 ");
	serial_println("                                            o /	 ");
	serial_println("                                             |	 ");
	serial_println("                                           . /	 ");
	serial_println("                                            /	 ");
	serial_println("                                          /'	 ");
	serial_println("                                         /	 ");
	serial_println("                                      .-'	 ");
	serial_println("                                    -'	 ");
	serial_println("                                 -'	 ");
	serial_println("                             -'          ");

	busy_wait();
	clear_screen();

	serial_println("                  .	 ");
	serial_println("             .	 ");
	serial_println("          .	 ");
	serial_println("       .-	 ");
	serial_println("      /	 ");
	serial_println("    .	 ");
	serial_println("   /	 ");
	serial_println("  /	 ");
	serial_println("  |	 ");
	serial_println(" /	      ");
	serial_println(" |	 ");
	serial_println(" |	 ");
	serial_println(" |	 ");
	serial_println(" \\	 ");
	serial_println("  |	 ");
	serial_println("  \\	 ");
	serial_println("   \\	 ");
	serial_println("    `	 ");
	serial_println("      \\	 ");
	serial_println("       `-	 ");
	serial_println("          `	 ");
	serial_println("             `	 ");
	serial_println("                 ` ");

	busy_wait();
	clear_screen();

	serial_println("                 .-	 ");
	serial_println("             .-	 ");
	serial_println("          .-	 ");
	serial_println("       .-'@	 ");
	serial_println("      /@@	 ");
	serial_println("    ./  	 ");
	serial_println("   /@@ 	 ");
	serial_println("  /@@@	 ");
	serial_println("  |@@@	 ");
	serial_println(" /@@@	  ");
	serial_println(" | @@	 ");
	serial_println(" |@ @	      ");
	serial_println(" |   	 ");
	serial_println(" \\  .	 ");
	serial_println("  |   	 ");
	serial_println("  \\   	 ");
	serial_println("   \\  o	 ");
	serial_println("    `\\  	 ");
	serial_println("      \\  	 ");
	serial_println("       `-. 	 ");
	serial_println("          `-	 ");
	serial_println("             `-	 ");
	serial_println("                 `-	");

	busy_wait();
	clear_screen();

	serial_println("                 .---	 ");
	serial_println("             .--' 	 ");
	serial_println("          .-'   	 ");
	serial_println("       .-'@   @	 ");
	serial_println("      /@@@  @@	 ");
	serial_println("    ./    o @	 ");
	serial_println("   /@@  o   @	 ");
	serial_println("  /@@@@   . 	 ");
	serial_println("  |@@@@@    	 ");
	serial_println(" /@@@@@  O 	  ");
	serial_println(" | @@@@    	 ");
	serial_println(" |@ @@@    	      ");
	serial_println(" |       @@	 ");
	serial_println(" \\  . @    	 ");
	serial_println("  |      @@ 	 ");
	serial_println("  \\     @@@@	 ");
	serial_println("   \\  o  @@  	 ");
	serial_println("    `\\     . 	 ");
	serial_println("      \\       	 ");
	serial_println("       `-.   o 	 ");
	serial_println("          `-.   	 ");
	serial_println("             `--. 	 ");
	serial_println("                 `---	 ");

	busy_wait();
	clear_screen();

	serial_println("                 .-----	 ");
	serial_println("             .--'  o  	 ");
	serial_println("          .-'   .    O	 ");
	serial_println("       .-'@   @@@@@@@	 ");
	serial_println("      /@@@  @@@@@@@@@	 ");
	serial_println("    ./    o @@@@@@@@	 ");
	serial_println("   /@@  o   @@@@@@@@	 ");
	serial_println("  /@@@@   .   @@@@@@	 ");
	serial_println("  |@@@@@            	 ");
	serial_println(" /@@@@@  O  `.-./  .	  ");
	serial_println(" | @@@@    --`-'    	 ");
	serial_println(" |@ @@@        `    	      ");
	serial_println(" |       @@  @      	 ");
	serial_println(" \\  . @        @@@  	 ");
	serial_println("  |      @@   @@@@@ 	 ");
	serial_println("  \\     @@@@  @\\@@  	 ");
	serial_println("   \\  o  @@     \\ \\ 	 ");
	serial_println("    `\\     .    .\\.-	 ");
	serial_println("      \\           `-'	 ");
	serial_println("       `-.   o   / | 	 ");
	serial_println("          `-.   /     	 ");
	serial_println("             `--.     	 ");
	serial_println("                 `-----  ");

	busy_wait();
	clear_screen();

	serial_println("                 .---------	 ");
	serial_println("             .--'  o     . .  	 ");
	serial_println("          .-'   .    O   .     	 ");
	serial_println("       .-'@   @@@@@@@   .  @@@@@	 ");
	serial_println("      /@@@  @@@@@@@@@@@   @@@@@@@	 ");
	serial_println("    ./    o @@@@@@@@@@@   @@@@@@@ 	 ");
	serial_println("   /@@  o   @@@@@@@@@@@.   @@@@@@@	 ");
	serial_println("  /@@@@   .   @@@@@@@o    @@@@@@@@@	 ");
	serial_println("  |@@@@@               . @@@@@@@@@@	 ");
	serial_println(" /@@@@@  O  `.-./  .      @@@@@@@@@	     ");
	serial_println(" | @@@@    --`-'       o     @@@@@@	 ");
	serial_println(" |@ @@@        `    o      .  @@   	  ");
	serial_println(" |       @@  @         .-.     @@@ 	 ");
	serial_println(" \\  . @        @@@     `-'   . @@@@	 ");
	serial_println("  |      @@   @@@@@ .           @@ 	 ");
	serial_println("  \\     @@@@  @\\@@    /  .  O    . 	 ");
	serial_println("   \\  o  @@     \\ \\  /         .  	 ");
	serial_println("    `\\     .    .\\.-.___   .      	 ");
	serial_println("      \\           `-'            	 ");
	serial_println("       `-.   o   / |     o    O 	 ");
	serial_println("          `-.   /     .       .	 ");
	serial_println("             `--.       .     	 ");
	serial_println("                 `---------   ");
	
	busy_wait();
	clear_screen();

	serial_println("                 .-----------	 ");
	serial_println("             .--'  o     . .   `-	 ");
	serial_println("          .-'   .    O   .       . 	 ");
	serial_println("       .-'@   @@@@@@@   .  @@@@@     	 ");
	serial_println("      /@@@  @@@@@@@@@@@   @@@@@@@   . 	 ");
	serial_println("    ./    o @@@@@@@@@@@   @@@@@@@      	 ");
	serial_println("   /@@  o   @@@@@@@@@@@.   @@@@@@@   O  	 ");
	serial_println("  /@@@@   .   @@@@@@@o    @@@@@@@@@@     	 ");
	serial_println("  |@@@@@               . @@@@@@@@@@@@@ o 	 ");
	serial_println(" /@@@@@  O  `.-./  .      @@@@@@@@@@@@    	     ");
	serial_println(" | @@@@    --`-'       o     @@@@@@@@ @@@@	 ");
	serial_println(" |@ @@@        `    o      .  @@   . @@@@@	  ");
	serial_println(" |       @@  @         .-.     @@@   @@@@@	 ");
	serial_println(" \\  . @        @@@     `-'   . @@@@   @@@@	 ");
	serial_println("  |      @@   @@@@@ .           @@   .   	 ");
	serial_println("  \\     @@@@  @\\@@    /  .  O    .     o 	 ");
	serial_println("   \\  o  @@     \\ \\  /         .    .   	 ");
	serial_println("    `\\     .    .\\.-.___   .      .   .	 ");
	serial_println("      \\           `-'                `	 ");
	serial_println("       `-.   o   / |     o    O   .  	 ");
	serial_println("          `-.   /     .       .    	 ");
	serial_println("             `--.       .      .-	 ");
	serial_println("                 `-----------	         ");

	busy_wait();
	clear_screen();

	serial_println("                 .------------	 ");
	serial_println("             .--'  o     . .   `--.	 ");
	serial_println("          .-'   .    O   .       . `-.	 ");
	serial_println("       .-'@   @@@@@@@   .  @@@@@      `-	 ");
	serial_println("      /@@@  @@@@@@@@@@@   @@@@@@@   .    \\	 ");
	serial_println("    ./    o @@@@@@@@@@@   @@@@@@@       . \\	 ");
	serial_println("   /@@  o   @@@@@@@@@@@.   @@@@@@@   O      	 ");
	serial_println("  /@@@@   .   @@@@@@@o    @@@@@@@@@@     @@@ 	 ");
	serial_println("  |@@@@@               . @@@@@@@@@@@@@ o @@@@	 ");
	serial_println(" /@@@@@  O  `.-./  .      @@@@@@@@@@@@    @@  	 ");
	serial_println(" | @@@@    --`-'       o     @@@@@@@@ @@@@    	 ");
	serial_println(" |@ @@@        `    o      .  @@   . @@@@@@@  	 ");
	serial_println(" |       @@  @         .-.     @@@   @@@@@@@  	 ");
	serial_println(" \\  . @        @@@     `-'   . @@@@   @@@@  o 	 ");
	serial_println("  |      @@   @@@@@ .           @@   .       	 ");
	serial_println("  \\     @@@@  @\\@@    /  .  O    .     o   . 	 ");
	serial_println("   \\  o  @@     \\ \\  /         .    .       	 ");
	serial_println("    `\\     .    .\\.-.___   .      .   .-. /	 ");
	serial_println("      \\           `-'                `-' /	 ");
	serial_println("       `-.   o   / |     o    O   .   .-	 ");
	serial_println("          `-.   /     .       .    .-'	 ");
	serial_println("             `--.       .      .--'	 ");
	serial_println("                 `------------	         ");

	busy_wait();
	clear_screen();

	serial_println("                 .------------.       								 ");
	serial_println("             .--'  o     . .   `--.      							 ");
	serial_println("          .-'   .    O   .       . `-.      						 ");
	serial_println("       .-'@   @@@@@@@   .  @@@@@      `-.   						 ");
	serial_println("      /@@@  @@@@@@@@@@@   @@@@@@@   .    \\ 						 ");
	serial_println("    ./    o @@@@@@@@@@@   @@@@@@@       . \\.  					 ");
	serial_println("   /@@  o   @@@@@@@@@@@.   @@@@@@@   O      \\ 					 ");
	serial_println("  /@@@@   .   @@@@@@@o    @@@@@@@@@@     @@@ \\   				 ");
	serial_println("  |@@@@@               . @@@@@@@@@@@@@ o @@@@| 					 ");
	serial_println(" /@@@@@  O  `.-./  .      @@@@@@@@@@@@    @@  \\  				 ");
	serial_println(" | @@@@    --`-'       o     @@@@@@@@ @@@@    |    			    ");
    serial_println(" |@ @@@        `    o      .  @@   . @@@@@@@  |   \033[3m\033[4mFull Moon OS\033[0m");
    serial_println(" |       @@  @         .-.     @@@   @@@@@@@  |   Version: R5 Episode 2  ");
    serial_println(" \\  . @        @@@     `-'   . @@@@   @@@@  o /       	    Attack of the Clones	 ");
	serial_println("  |      @@   @@@@@ .           @@   .       | 					 ");
	serial_println("  \\     @@@@  @\\@@    /  .  O    .     o   . /  				 ");
	serial_println("   \\  o  @@     \\ \\  /         .    .       /  				 ");
	serial_println("    `\\     .    .\\.-.___   .      .   .-. /' 					 ");
	serial_println("      \\           `-'                `-' / 						 ");
	serial_println("       `-.   o   / |     o    O   .   .-'   						 ");
	serial_println("          `-.   /     .       .    .-'       						 ");
	serial_println("             `--.       .      .--'      							 ");
	serial_println("                 `------------'       								 ");
}
