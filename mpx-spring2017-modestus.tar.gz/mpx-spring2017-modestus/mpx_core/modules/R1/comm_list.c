#include <comm_vars.h>
#include <core/rtc.h>
#include <string.h>
#include <input.h>
#include "include/comm_list.h"
#include <core/pcb.h>
#include <linked_list.h>
#include <core/mcb.h>

#include "../procsr3.h"

/* __________________________________________________________________ */
/* Helper functions below this */

char *PROMPT = ">";

int getNumDaysInMonth(int month, int year) {
    int days = 0;
    switch (month) {
    case 01: case 3: case 5: case 7: case 8: case 10: case 12:
        days = 31;
        break;
    case 4: case 6: case 9: case 11:
        days = 30;
        break;
    case 2:
        if(year%4==0)
            days = 29;
        else
            days = 28;
    default:
        break;
    }
    return days;
}

int isEmpty(char parameters[][MAX_LENGTH]) {
    int empty = 0;
    if((!strcmp(parameters[0],"")) || (!strcmp(parameters[0],"\0"))) {
        empty = 1;
    }
    return empty;
}



/* END HELPER FUNCTIONS */
/* _______________________________________________________________________ */


int helpFunc(char parameters[][MAX_LENGTH]) {
    if(!strcmp(parameters[0],"") || !strcmp(parameters[0],"\0")) {
        help();
    } else if(strcmp(parameters[0],"shutdown")==0) {
        helpShutdown();
    } else if(strcmp(parameters[0],"version")==0) {
        helpGetVersion();
    } else if(strcmp(parameters[0],"time")==0) {
        helpTime(&parameters[1]);
    } else if(strcmp(parameters[0],"date")==0) {
        helpDate(&parameters[1]);
    } else if(strcmp(parameters[0], "pcb")==0) {
        helpPcb(&parameters[1]);
    } else if(strcmp(parameters[0], "loadr3")==0) {
        helpLoadR3();
    } else if(strcmp(parameters[0], "mcb")==0) {
        helpMCB(&parameters[1]);
    } else if(strcmp(parameters[0], "cp")==0) {
        helpCP(); 
    } else {
        serial_println(IMPROPER_COMMAND);
    }
    return 0;
}

void help() {

    printf("%s%sUNIX style commands%s\r\n",COLOR_BLACK, BG_WHITE, COLOR_STOP);
        printf("%s%sCommand   | what it does%s\r\n", COLOR_BLACK, BG_WHITE, COLOR_STOP);
        printf("%s%s-------   | -----------------------------------%s\r\n", COLOR_BLACK, BG_WHITE, COLOR_STOP);
        printf("%s%sdate      | Interact with the current system date%s\r\n",COLOR_BLACK, BG_RED, COLOR_STOP);
        printf("%s%shelp      | Shows the command options%s\r\n", COLOR_WHITE, BG_ORANGE, COLOR_STOP);
        printf("%s%spcb       | Work with the processes%s\r\n", COLOR_BLACK, BG_YELLOW, COLOR_STOP);
        printf("%s%sshutdown  | Shut down the system%s\r\n", COLOR_BLACK, BG_GREEN, COLOR_STOP);
        printf("%s%stime      | Interact with the current system time%s\r\n", COLOR_WHITE, BG_BLUE, COLOR_STOP);
        printf("%s%sversion   | Get the current version of the OS%s\r\n", COLOR_RED_DARK, BG_MAGENTA, COLOR_STOP);
        printf("%s%sloadr3    | Loads all of the processes from procsr3%s\r\n",COLOR_BLACK, BG_RED, COLOR_STOP);
    //serial_println("loadr3    | Loads all of the processes from procsr3");//,COLOR_BLACK, BG_RED, COLOR_STOP);
        printf("%s%smcb       | Work with MCB%s\r\n", COLOR_BLACK, BG_ORANGE, COLOR_STOP);
        printf("%s%scp        | Changes the prompt%s\r\n", COLOR_BLACK, BG_YELLOW, COLOR_STOP);


    serial_println(" ");


}

void helpCP() {
    serial_println("Changes the prompt that is printed on the entry line.");
    serial_println("Command: 'cp \e[3marg1\e[0m'");
    serial_println("Arguments: \e[3marg1\e[0m: String prompt");
    serial_println("\r\n");
}

void helpMCB(char parameters[][MAX_LENGTH]){

    if(isEmpty(&parameters[0])) {
        helpMcbPrint();
    } /*else if(!strcmp(parameters[0],"--initheap")) {
        helpMCBInitHeap();
    } else if(!strcmp(parameters[0],"--allocate")) {
        helpMCBAllocate();
    } else if(!strcmp(parameters[0], "--freemem")) {
        helpMCBFreeMem();
    } else if(!strcmp(parameters[0], "--isempty")) {
        helpMCBIsEmpty();
    }*/ else if(!strcmp(parameters[0], "--showfree")) {
        helpMCBShowFree();
    } else if(!strcmp(parameters[0], "--showallocated")) {
        helpMCBShowAllocated();
    } else {
        serial_println("Invalid parameter, run 'help mcb' to see the valid parameters.");
    }


}

void helpMcbPrint() {
    serial_println("MCB commands\r\n");
    serial_println("Use 'mcb [command]'");
    serial_println("   Command        | what it does");
    serial_println("______________    | _________________________________");
    serial_println("--showfree        | Shows all free memory in heap");
    serial_println("--showallocated   | Shows all allocated memory");

    serial_println("Type 'help [command]' to see what the command does and arguments it requires.");
    serial_println(" ");
}

void helpMCBInitHeap() {
    serial_println("Allocate memory for MPX.  Size of the heap in bytes.");
    serial_println("Command: 'mcb --initheap'");
    serial_println("Arguments:");
    serial_println("-s/--size 'size of the memory (integer value)'");
    serial_println("\r\n");
}

void helpMCBAllocate() {
    serial_println("Allocate memory from heap.  Amount of bytes to be allocated from the heap.");
    serial_println("Command: 'mcb --allocate'");
    serial_println("Arguments:");
    serial_println("-s/--size 'size of the memory (integer value)'");
    serial_println("\r\n");
}

void helpMCBFreeMem() {
    serial_println("Free a particular block of memory that was previously allocated.  Takes in the pointer to an address in memory");
    serial_println("Command: 'mcb --freemem'");
    serial_println("Arguments:");
    serial_println("-p/--pointer 'pointer to an address'");
    serial_println("\r\n");
}

void helpMCBIsEmpty() {
    serial_println("Returns true or false based on whether the heap is empty.");
    serial_println("Command: 'mcb --isempty'");
    serial_println("No arguments required.");
    serial_println("\r\n");
}

void helpMCBShowFree() {
    serial_println("Show the address and size of the blocks in the free list.");
    serial_println("Command: 'mcb --showfree'");
    serial_println("No arguments required.");
    serial_println("\r\n");
}

void helpMCBShowAllocated() {
    serial_println("Show the address and size of the blocks in the allocated list.");
    serial_println("Command: 'mcb --showallocated'");
    serial_println("No arguments required.");
    serial_println("\r\n");
}


void helpLoadR3() {
    serial_println("Loads all of the processes from procsr3.");
    serial_println("Command: 'loadr3'");
    serial_println("No arguments required.");
    serial_println("\r\n");
}

int helpGetVersion() {
    printf("%sGet the current version of the operating system%s\r\n",COLOR_RED, COLOR_STOP);
    printf("Command: '%sversion%s'\r\n",COLOR_YELLOW,COLOR_STOP);
    printf("%sThere are no arguments required.\r\n","");
    printf("%sThis will return R1, R2,... showing the current module.\r\n","");
    printf("%s\r\n","");
    return 0;
}

void helpGetDate() {
    serial_println("Get the current date.");
    serial_println("Command: 'get date'");
    serial_println("There are no arguments required.");
    serial_println(" ");
}

void helpSetDate() {
    serial_println("Set the current date");
    serial_println("Command: 'set date --set \"DD/MM/YYYY\" ");
    serial_println("Arguments:");
    serial_println("--set \"MM/DD/YYYY\"");
    serial_println("ex. 'set date --set \"03/12/2017\"'");
    serial_println(" ");
}

void helpGetTime() {
    serial_println("Get the current time in UTC.");
    serial_println("Command: 'get time'");
    serial_println("There are no arguments required.");
    serial_println(" ");
}

void helpSetTime(){
    serial_println("Set the current time in UTC");
    serial_println("Command: 'set time --set \"HH:MM.SS\"'");
    serial_println("Arguments: ");
    serial_println("--set \"HH:MM.SS\"   using 24 hour");
    serial_println("ex. 'set time --set[14:20.00]' to set the system time to 2:20.00 PM");
    serial_println(" ");
}

void helpShutdown() {

    serial_println("Shut down the system.");
    serial_println("Command: 'shutdown'");
    serial_println("No arguments required.");
    serial_println("You will be prompted to confirm that you want to shutdown.");
    serial_println(" ");
}

void helpVersion() {
    serial_println("Shows the version of the operating system.");
    serial_println("Command: 'version'");
    serial_println("No arguments required.");
    serial_println("\r\n");
}

void helpDate(char parameters[][MAX_LENGTH])
{
    if(!strlen(parameters[0]))
    {
        serial_println("Retireves or Sets the system date");
        serial_println("Command: 'date'");
        serial_println("\033[38;2;255;255;0mArguments available: \033[38;2;255;0;0m--set, --get\033[0m");
        serial_println("Enter the command 'help date --get' or 'help date --set'");
    }
    else if(!strcmp(parameters[0], "--set"))
    {
        serial_println("Sets the system date");
        serial_println("Command: 'date --set'");
        serial_println("Usage: \033[38;2;255;255;0m 'date --set' \"DD/MM/YYYY\" \033[0m");
    }
    else if(!strcmp(parameters[0], "--get"))
    {
        serial_println("Gets the system date");
        serial_println("Command: 'date --get'");
        serial_println("Usage: \033[38;2;255;255;0m 'date --get' \033[0m");
    }
}

void helpTime(char parameters[][MAX_LENGTH])
{
    if(!strlen(parameters[0]))
    {
        serial_println("Retrieves or Sets the system time");
        serial_println("Command: 'time'");
        serial_println("\033[38;2;255;255;0mArguments available: \033[38;2;255;0;0m--set, --get\033[0m");
        serial_println("Enter the command 'help time --get' or 'help time --set'");
    }
    else if(!strcmp(parameters[0], "--set"))
    {
        serial_println("Sets the system time");
        serial_println("Command: 'time --set'");
        serial_println("Usage: \033[38;2;255;255;0m 'time --set' \"HH:MM.SS\" \033[0m");
    }
    else if(!strcmp(parameters[0], "--get"))
    {
        serial_println("Gets the system date");
        serial_println("Command: 'time --get'");
        serial_println("Usage: \033[38;2;255;255;0m 'time --get' \033[0m");
    }
}

void helpPcb(char parameters[][MAX_LENGTH]) {
    if(isEmpty(&parameters[0])) {
        helpPcbPrint();
    } else if(!strcmp(parameters[0],"--block")) {
        helpBlockPCB();
    } else if(!strcmp(parameters[0],"--create")) {
        helpCreatePCB();
    } else if(!strcmp(parameters[0], "--delete")) {
        helpDeletePCB();
    } else if(!strcmp(parameters[0], "--resume")) {
        helpResumePCB();
    } else if(!strcmp(parameters[0], "--resumeall")) {
        helpResumeAll();
    } else if(!strcmp(parameters[0], "--setpriority")) {
        helpSetPriority();
    } else if(!strcmp(parameters[0], "--show")) {
        helpShowPCB();
    } else if(!strcmp(parameters[0],"--showall")) {
        helpShowAllProcesses();
    } else if(!strcmp(parameters[0], "--showblocked")) {
        helpShowBlockedProcesses();
    } else if(!strcmp(parameters[0], "--showready")) {
        helpShowReadyProcesses();
    } else if(!strcmp(parameters[0], "--suspend")) {
        helpSuspendPCB();
    } else if(!strcmp(parameters[0],"--unblock")) {
        helpUnblockPCB();
    } else {
        serial_println("Invalid parameter, run 'help pcb' to see the valid parameters.");
    }
}

void helpPcbPrint() {
    serial_println("PCB commands\r\n");
    serial_println("Use 'pcb [command]'");
    serial_println("   Command    | what it does");
    serial_println("____________  | _________________________________");
    serial_println("--block       | Sends the PCB to the blocked queue");
    serial_println("--create      | Creates a new PCB and allocates memory");
    serial_println("--delete      | Delete specified PCB and frees memory");
    serial_println("--resume      | Resume the specified PCB");
    serial_println("--resumeall   | Resume all PCBs in the suspended state");
    serial_println("--setpriority | Set/change the priority of the specified PCB");
    serial_println("--show        | Show the specified PCB");
    serial_println("--showall     | Show all of the PCBs");
    serial_println("--showblocked | Show the PCBs in the blocked queue");
    serial_println("--showready   | Show the PCBs in the ready queue");
    serial_println("--suspend     | Suspends the specified PCB");
    serial_println("--unblock     | Moves the specified PCB from the blocked state to ready queue");
    serial_println(" ");
    serial_println("Type 'help [command]' to see what the command does and arguments it requires.");
    serial_println(" ");
}

void helpSuspendPCB() {
    serial_println("Suspend a particular PCB.");
    serial_println("Command: pcb --suspend");
    serial_println("Arguments:");
    serial_println("-n/--name 'name of the pcb");
    serial_println(" ");
}

void helpResumePCB() {
    serial_println("Resume the specified PCB.  Removes PCB from suspended queue and places it into the appropriate queue.");
    serial_println("Command: pcb --resume");
    serial_println("Arguments:");
    serial_println("-n/--name 'name of the PCB'");
    serial_println(" ");
}

void helpResumeAll() {
    serial_println("Resume all PCBs that are currently in the suspended state.");
    serial_println("Command: pcb --resumeall");
    serial_println("Takes no arguments");
    serial_println(" ");
}

void helpSetPriority() {
    serial_println("Set/change the priority of a particular PCB.");
    serial_println("Command: pcb --setpriority");
    serial_println("Arguments:");
    serial_println("-n/--name 'name of PCB'\n-p/--priority 'priority from 0-9'");
    serial_println(" ");
}

void helpShowPCB() {
    serial_println("Show the information for a particular PCB.");
    serial_println("Command: pcb --show");
    serial_println("Arguments:");
    serial_println("-n/--name 'name of the PCB'");
    serial_println(" ");
}

void helpShowAllProcesses() {
    serial_println("Show all of the processes in the system.");
    serial_println("Command: pcb --showall");
    serial_println("Arguments:");
    serial_println("No arguments required.");
    serial_println(" ");
}

void helpShowReadyProcesses() {
    serial_println("Show all of the processes that are in the ready queue.");
    serial_println("Command: pcb --showready");
    serial_println("Arguments:");
    serial_println("No arguments required.");
    serial_println(" ");
}

void helpShowBlockedProcesses() {
    serial_println("Show all of the processes that are in the blocked queue.");
    serial_println("Command: pcb --showblocked");
    serial_println("Arguments:");
    serial_println("No arguments required.");
    serial_println(" ");
}

void helpCreatePCB() {
    serial_println("Creates a new PCB and allocates memory.");
    serial_println("Command: pcb --create");
    serial_println("Arguments:");
    serial_println("-n/--name 'the name of the PCB'\n-p/--priority 'priority from 0-9 of pcb'\n-c/--class 'System or User_app'");
    serial_println(" ");
}

void helpDeletePCB() {
    serial_println("Delete the specified PCB and frees memory.  Removes the PCB from any queues it is currently in.");
    serial_println("Command: pcb --delete");
    serial_println("Arguments:");
    serial_println("-n/--name 'the name of the PCB'");
    serial_println(" ");
}

void helpBlockPCB() {
    serial_println("Removes the PCB from current queue and places it into the blocked queue.");
    serial_println("Command: pcb --block");
    serial_println("Arguments:");
    serial_println("-n/--name 'name of the PCB'");
    serial_println(" ");
}

void helpUnblockPCB() {
    serial_println("Removes the PCB from the blocked queue and places it into the ready queue.");
    serial_println("Command: pcb --unblock");
    serial_println("Arguments:");
    serial_println("-n/--name 'name of the PCB'");
    serial_println(" ");
}

/* ____________________________________________________*/

int version(char parameters[][MAX_LENGTH]) {
    (void)parameters;
    serial_print("Version: ");
    serial_print(VERSION);
    serial_println(" ");
    return 0;
}

/* ___________________________________________ */
/* DATE FUNCTIONS BELOW */

int date(char parameters[][MAX_LENGTH]) {
    if(!strcmp(parameters[0],"--get")) {
        getDate();
    } else if(!strcmp(parameters[0],"--set")) {
        setDate(&parameters[1]);
    } else {
        serial_println("Check your input, there are only 12 months in a year.");
    }
    return 0;
}

void getDate() {
    int month=0, day=0, year=0;
    get_date(&day, &month, &year);
    printf("The current date is %d/%d/20%d UTC\r\n", day, month, year);
}

void setDate(char parameters[][MAX_LENGTH]) {
    //printf("day %d %s, month %d %s, year %d %s\r\n", atoi(parameters[0]), parameters[0], atoi(parameters[1]), parameters[1], atoi(parameters[2]), parameters[2]);
    if(!strlen(parameters[2]) || !atoi(parameters[0]) || !atoi(parameters[1]) || !atoi(parameters[2]))
    {
        serial_println(IMPROPER_COMMAND);
        serial_println("\r\nInvalid Parameters");
    }
    else
    {
        int daysInMonth = getNumDaysInMonth(atoi(parameters[1]), atoi(parameters[2]));
        if((atoi(parameters[0]) > 0) && (daysInMonth >= atoi(parameters[0]))){
            set_date(atoi(parameters[0]), atoi(parameters[1]), atoi(parameters[2]));
        } else {
            serial_println("Double check the input parameters");
            printf("\033[38;2;255;0;255mTotal days in your selected month are:  %d UTC\r\n\033[38;2;255;255;255m", daysInMonth);
            serial_println("\r\n");
        }
    }
    getDate();
}

/* END DATE FUNCTIONS */

/* _______________________________________*/
/* START TIME FUNCTIONS */

int time(char parameters[][MAX_LENGTH]) {
    if(!strcmp(parameters[0],"--get")) {
        getTime();
    } else if(!strcmp(parameters[0],"--set")) {
        setTime(&parameters[1]);
    } else {
        serial_println("ERROR HAS BEEN NOTICED");
    }
    return 0;
}

void getTime() {
    int hour=0, minutes=0, seconds=0;
    get_time(&hour, &minutes, &seconds);

    char buf[500]; \
    sprintf(buf, 500, "\033[38;2;255;0;255mThe current time is %d:%d.%d UTC\r\n\033[38;2;255;255;255m", hour, minutes, seconds); \
    serial_print(buf);
    //printf("\033[38;2;255;0;255mThe current time is %d:%d.%d UTC\r\n\033[38;2;255;255;255m", hour, minutes, seconds);
}

void setTime(char parameters[][MAX_LENGTH]) {
    if(!strlen(parameters[2]) || !atoi(parameters[0]) || !atoi(parameters[1]) || !atoi(parameters[2]))
    {
        serial_println(IMPROPER_COMMAND);
        serial_println("\r\nInvalid Parameters");
    }
    else
    {
        if(atoi(parameters[0]) < 0 || atoi(parameters[0]) > 24 || atoi(parameters[1]) < 0 || atoi(parameters[1]) > 59 || atoi(parameters[2]) < 0 || atoi(parameters[2]) > 59) {
            serial_println("Double check the input parameters");
            serial_println("Make sure 0 HH 24 and 0 MM 59 and 0 SS 59");
            serial_println("\r\n");
        } else {
            set_time(atoi(parameters[0]), atoi(parameters[1]), atoi(parameters[2]));
        }
    }
    getTime();
}

/* END TIME FUNCTIONS */

int shutdownFunc(char parameters[][MAX_LENGTH]) {
    int retVal = 0;


    char buf[500]; \
    sprintf(buf, 500, "\033[38;2;255;0;255mShutdown called\r\n\033[38;2;255;255;255m"); \

    serial_println("Shutdown was called.\r\n");

    if(strcmp(parameters[1],"")==0) {
        int confirm = 0;
        char in_string[MAX_LENGTH];
        serial_print("Confirm shutdown y/n?: ");

        if(confirm == 0) {
            serial_print("");
            serial_poll(in_string);
            if(strcmp(in_string, "y")==0)
            {
                confirm = 1;
                serial_println("");
                sys_req(EXIT);
            }
            else if (strcmp(in_string, "n")==0)
                confirm = 2;
        }
        serial_println(" ");
        if(confirm == 1)
            retVal = 9;
    } else {
        serial_println("UNKNOWN_COMMAND");
    }
    return retVal;
}

/* __________ PCB FUNCTIONS _____________ */

int pcbFunc(char parameters[][MAX_LENGTH]) {
    if(!strcmp(parameters[0],"--suspend")) {
        if(isEmpty(&parameters[1])) {
            serial_println("Missing name of PCB to suspend.");
        } else {
            if(!isEmpty(&parameters[2]) &&
                    (!strcmp(parameters[1],"-n") || !strcmp(parameters[1],"--name"))) {
                suspendPCB(&parameters[2]);
            } else {
                suspendPCB((&parameters[2]));
                serial_print(EXTRA_PARAMETERS);
                serial_print(parameters[3]);
                serial_print("\r\n");
            }
        }
    } else if(!strcmp(parameters[0],"--resume")) {
        if(isEmpty(&parameters[1])) {
            serial_println("Missing name of PCB to suspend.");
        } else {
            if(!isEmpty(&parameters[2]) &&
                    (!strcmp(parameters[1],"-n") || !strcmp(parameters[1],"--name"))) {
                resumePCB(&parameters[2]);
            } else {
                resumePCB((&parameters[2]));
                serial_print(EXTRA_PARAMETERS);
                serial_print(parameters[3]);
                serial_print("\r\n");            }
        }
    } else if(!strcmp(parameters[0], "--resumeall")){
        if(isEmpty(&parameters[1])) {
            resumeAll();
        } else {
            resumeAll();
            serial_print(EXTRA_PARAMETERS);
            serial_print(parameters[1]);
            serial_print("\r\n");
        }
    } else if(!strcmp(parameters[0],"--setpriority")) {
        if(isEmpty(&parameters[4])) {
            serial_println("Missing parameters.");
        } else {
            if((!strcmp(parameters[1],"--name") || !strcmp(parameters[1],"-n")) && (!strcmp(parameters[3],"--priority") || !strcmp(parameters[3],"-p"))) {
                setPriority(parameters[2], parameters[4]);
            } else if((!strcmp(parameters[3],"--name") || !strcmp(parameters[3],"-n")) && (!strcmp(parameters[1],"--priority") || !strcmp(parameters[1],"-p"))) {
                setPriority(parameters[4], parameters[2]);
            } else {
                printf("%sProper command: 'pcb --setpriority -n \"pcb name\" -p \"pcb priority\"","");
            }
        }
    } else if(!strcmp(parameters[0],"--show")) {
        if(isEmpty(&parameters[2])) {
            printf("Missing name of pcb to show%s.\n","");
        } else {
            if(!strcmp(parameters[1],"-n") || !strcmp(parameters[1],"--name")) {
                showPCB(&parameters[2]);
            } else {
                printf("Type 'help pcb --show' to see the arguments required.%s\n","");
            }
        }
    } else if(!strcmp(parameters[0],"--showall")) {
        if(isEmpty(&parameters[1])) {
            showAllProcesses(&parameters[0]);

        } else {
            printf("No arguments required%s\n","");
            showAllProcesses(&parameters[0]);
        }
    } else if(!strcmp(parameters[0],"--showready")) {
        if(isEmpty(&parameters[1])) {
            showReadyProcesses(&parameters[0]);

        } else {
            printf("No arguments required%s\n","");
            showReadyProcesses(&parameters[0]);
        }
    } else if(!strcmp(parameters[0],"--showblocked")) {
        if(isEmpty(&parameters[1])) {
            showBlockedProcesses(&parameters[0]);

        } else {
            printf("No arguments required%s\n","");
            showBlockedProcesses(&parameters[0]);
        }
    } else if(!strcmp(parameters[0],"--create")) {
        if(isEmpty(&parameters[6])) {
            printf("Missing parameters of pcb to create%s.\n","");
        } else {
            char * procName; char * procPrio; char * procClass;
            int i = 0;
            for(;!isEmpty(&parameters[i]); i++) {
                if(!strcmp(parameters[i], "--name") || !strcmp(parameters[i],"-n")) {
                    i++;
                    procName = parameters[i];
                } else if(!strcmp(parameters[i], "--priority") || !strcmp(parameters[i],"-p")) {
                    i++;
                    procPrio = parameters[i];
                } else if(!strcmp(parameters[i], "--class") || !strcmp(parameters[i],"-c")) {
                    i++;
                    procClass = parameters[i];
                }
            }

            createPCB(procName, procPrio, procClass);
        }
    } else if(!strcmp(parameters[0],"--delete")) {
        if(isEmpty(&parameters[2])) {
            printf("Missing name of pcb to create%s.\n","");
        } else {
            if(!strcmp(parameters[1],"-n") || !strcmp(parameters[1],"--name")) {
                deletePCB(&parameters[2]);
            } else {
                printf("Type 'help pcb --delete' to see the arguments required.%s\n","");
            }
        }
    } else if(!strcmp(parameters[0],"--block")) {
        if(isEmpty(&parameters[2])) {
            printf("Missing name of pcb to create%s.\n","");
        } else {
            if(!strcmp(parameters[1],"-n") || !strcmp(parameters[1],"--name")) {
                blockPCB(&parameters[2]);
            } else {
                printf("Type 'help pcb --block' to see the arguments required.%s\n","");
            }
        }
    } else if(!strcmp(parameters[0],"--unblock")) {
        if(isEmpty(&parameters[2])) {
            printf("Missing name of pcb to create%s.\n","");
        } else {
            if(!strcmp(parameters[1],"-n") || !strcmp(parameters[1],"--name")) {
                unblockPCB(&parameters[2]);
            } else {
                printf("Type 'help pcb --unblock' to see the arguments required.%s\n","");
            }
        }
    }
    return 0;
}

int suspendPCB(char parameters[][MAX_LENGTH]) {

    e_PCB_ERROR_CODE_t retVal = changeProcessSuspensionState((const char*)parameters[0], SUSPENDED);
    if(retVal == SUCCESS)
    {
        showPCB(parameters);
    }
    printf("Status: %s\r\n", errorToString(retVal));
    return retVal;

//    const char* name = (const char*)parameters[0];
//    pcb_t* process = findPCB(name);
//    e_PROCESS_STATE_t state = process->processState;
//    if (state == READY || state == RUNNING)
//    {
//        changeProcessState(name, BLOCKED);
//    }
//    else printf("%s", "\nThe process needs to either be in the ready or the running state to suspend.\n");
//    return 0;
}

int resumePCB(char parameters[][MAX_LENGTH]) {

    e_PCB_ERROR_CODE_t retVal = changeProcessSuspensionState((const char*)parameters[0], NOT_SUSPENDED);
    if(retVal == SUCCESS)
    {
        showPCB(parameters);
    }
    printf("Status: %s\r\n", errorToString(retVal));
    return retVal;

//    const char* name = (const char*)parameters[0];
//    pcb_t* process = findPCB(name);
//    e_PROCESS_STATE_t state = process->processState;
//    if (state == READY)
//    {
//        changeProcessState(name, RUNNING);
//    }
//    else printf("%s", "\nThe process must be in the ready state to resume.\n");
//    return 0;
}

int setPriority(char * procName, char * procPrio) {
    //serial_println("PRINTING OUT");
    printf("Status: %s\r\n", errorToString(changeProcessPriority(procName, atoi(procPrio))));
    printPCBFunc((void*)findPCB(procName));
    return 0;
}

int showPCB(char parameters[][MAX_LENGTH]) {
    pcb_t* process = findPCB((const char*)parameters[0]);
    if(!process) { printf("Status: %s\r\n", errorToString(prevPCBError)); return prevPCBError; }

    printPCBFunc((void*)process);

    return prevPCBError;
}

int showAllProcesses(char parameters[][MAX_LENGTH]) {
    (void)parameters;
    printf("\n\nReady Queue:%s","\r\n");
    printList(&readyQueue);
    printf("\n\nBlocked Queue:%s","\r\n");
    printList(&blockedQueue);
    printf("\n\nSuspended-Ready Queue:%s","\r\n");
    printList(&suspendedReadyQueue);
    printf("\n\nSuspended-Blocked Queue:%s","\r\n");
    printList(&suspendedBlockedQueue);
    return 0;
}

int showReadyProcesses(char parameters[][MAX_LENGTH]) {
    (void)parameters;
    printf("%s", "\n\nReady Queue:\n");
    printList(&readyQueue);
    return 0;
}

int showBlockedProcesses(char parameters[][MAX_LENGTH]) {
    (void)parameters;
    printf("%s", "\n\nBlocked Queue:\n");
    printList(&blockedQueue);
    return 0;
}

int createPCB(const char* pcbName, const char* pcbPriority, const char* pcbClass) {
    setupPCB(pcbName, stringToClass(pcbClass), atoi(pcbPriority));
    //printf("Clas String %s: num %d\r\n", pcbClass, (int) stringToClass(pcbClass));
    printf("Status: %s\r\n", errorToString(prevPCBError));

    return prevPCBError;

}

int deletePCB(char parameters[][MAX_LENGTH]) {
    pcb_t* foundPCB = findPCB((const char*)parameters[0]);
    if(!foundPCB)
    {
        printf("Status: %s\r\n", errorToString(prevPCBError));
        return prevPCBError;
    }
    e_PCB_ERROR_CODE_t retval = freePCB(foundPCB);
    printf("Status: %s\r\n", errorToString(retval));
    return retval;
}

int blockPCB(char parameters[][MAX_LENGTH]) {
    e_PCB_ERROR_CODE_t retVal = changeProcessState((const char*)parameters[0], BLOCKED);
    if(retVal == SUCCESS)
    {
        showPCB(parameters);
    }
    printf("Status: %s\r\n", errorToString(retVal));
    return retVal;
//    const char* name = (const char*)parameters[0];
//    changeProcessState(name, BLOCKED);
//    return 0;
}

int unblockPCB(char parameters[][MAX_LENGTH]) {
    e_PCB_ERROR_CODE_t retVal = changeProcessState((const char*)parameters[0], READY);
    if(retVal == SUCCESS)
    {
        showPCB(parameters);
    }
    printf("Status: %s\r\n", errorToString(retVal));
    return retVal;
//    const char* name = (const char*)parameters[0];
//    changeProcessState(name, READY);
//    return 0;
}

int yield() {
    asm volatile("int $60");
    return 0;
}

int loadr3(char parameters[][MAX_LENGTH]) {
    (void)parameters;
    serial_println("Loading processes.");

    pcb_t* newPCB = setupPCB("R3-Proc1", SYSTEM, 1);
    processContext_t * cp = ( processContext_t *)( newPCB->stackTop );
    memset ( cp , 0, sizeof ( processContext_t ));
    cp->fs = 0x10 ;
    cp->gs = 0x10 ;
    cp->ds = 0x10 ;
    cp->es = 0x10 ;
    cp->cs = 0x8 ;
    cp->ebp = ( u32int )( newPCB->stackBase );
    cp->esp = ( u32int )( newPCB->stackTop );
    cp->eip = ( u32int ) &proc1 ;// The function correlating to the process , ie. Proc1
    cp->eflags = 0x202 ;

    newPCB = setupPCB("R3-Proc2", SYSTEM, 1);
    cp = ( processContext_t *)( newPCB->stackTop );
    memset ( cp , 0, sizeof ( processContext_t ));
    cp->fs = 0x10 ;
    cp->gs = 0x10 ;
    cp->ds = 0x10 ;
    cp->es = 0x10 ;
    cp->cs = 0x8 ;
    cp->ebp = ( u32int )( newPCB->stackBase );
    cp->esp = ( u32int )( newPCB->stackTop );
    cp->eip = ( u32int ) &proc2 ;// The function correlating to the process , ie. Proc1
    cp->eflags = 0x202 ;


    newPCB = setupPCB("R3-Proc3", SYSTEM, 1);
    cp = ( processContext_t *)( newPCB->stackTop );
    memset ( cp , 0, sizeof ( processContext_t ));
    cp->fs = 0x10 ;
    cp->gs = 0x10 ;
    cp->ds = 0x10 ;
    cp->es = 0x10 ;
    cp->cs = 0x8 ;
    cp->ebp = ( u32int )( newPCB->stackBase );
    cp->esp = ( u32int )( newPCB->stackTop );
    cp->eip = ( u32int ) &proc3 ;// The function correlating to the process , ie. Proc1
    cp->eflags = 0x202 ;

    newPCB = setupPCB("R3-Proc4", SYSTEM, 1);
    cp = ( processContext_t *)( newPCB->stackTop );
    memset ( cp , 0, sizeof ( processContext_t ));
    cp->fs = 0x10 ;
    cp->gs = 0x10 ;
    cp->ds = 0x10 ;
    cp->es = 0x10 ;
    cp->cs = 0x8 ;
    cp->ebp = ( u32int )( newPCB->stackBase );
    cp->esp = ( u32int )( newPCB->stackTop );
    cp->eip = ( u32int ) &proc4 ;// The function correlating to the process , ie. Proc1
    cp->eflags = 0x202 ;

    newPCB = setupPCB("R3-Proc5", SYSTEM, 1);
    cp = ( processContext_t *)( newPCB->stackTop );
    memset ( cp , 0, sizeof ( processContext_t ));
    cp->fs = 0x10 ;
    cp->gs = 0x10 ;
    cp->ds = 0x10 ;
    cp->es = 0x10 ;
    cp->cs = 0x8 ;
    cp->ebp = ( u32int )( newPCB->stackBase );
    cp->esp = ( u32int )( newPCB->stackTop );
    cp->eip = ( u32int ) &proc5 ;// The function correlating to the process , ie. Proc1
    cp->eflags = 0x202 ;



    return 0;
}

/* ******************* END PCB FUNCTIONS ********************* */

/*___________________ START MCB FUNCTIONS ___________________ */

int mcbFunc(char parameters[][MAX_LENGTH]) {
    /*if(!strcmp(parameters[0],"--allocate")) {
        int returnError = (int)allocateMemFromHeap((size_t)atoi(parameters[2]));
        if(returnError == 0 ) {
            printf("%sNo blocks large enough%s\r\n",COLOR_RED,COLOR_STOP);
        }
        printf("%s", "Alloc list\r\n")
        printList(&mcbAllocList);
        printf("%s", "free list\r\n")
        printList(&mcbFreeList);
    }*/ /*else if(!strcmp(parameters[0],"--freemem")) {

        if(strcmp(parameters[2],"")) {
            freeHeapMem((void*)atoi(parameters[2]));
            printf("Result: %s\r\n",mcbResultToString(lastMCBError));
        } else {
            serial_println("Enter a valid address to free");
        }
    }*/ /*else if(!strcmp(parameters[0],"--initheap")) {
        initHeap((size_t)atoi(parameters[2]));
        serial_println("Heap initialized");
    } else *//*if(!strcmp(parameters[0],"--isempty")) {
        if(heapIsEmpty()) {
            printf("%sHeap is not empty%s\r\n",BG_ORANGE, COLOR_STOP);
        } else {
            printf("%s%sHeap is empty%s\r\n",COLOR_BLUE,BG_GREEN, COLOR_STOP);
        }
    } else*/ if(!strcmp(parameters[0],"--showfree")) {
        printf("%s", "free list\r\n")
        printList(&mcbFreeList);
    } else if(!strcmp(parameters[0],"--showallocated")) {
        printf("%s", "Alloc list\r\n")
        printList(&mcbAllocList);
    } else if(!strcmp(parameters[0],"--showall")) {
        printf("%s", "Free list\r\n")
        printList(&mcbFreeList);
        printf("%s", "Alloc list\r\n")
        printList(&mcbAllocList);
    } else if(!strcmp(parameters[0],"--testheap")) {
        heapTest();
    } else {
        printf("Here are some possible commands:  %s--showfree %s--showallocated%s\r\n", COLOR_RED, COLOR_YELLOW, COLOR_STOP);
    }

    return 0;
}

char *getPrompt() {
    return PROMPT;
}

int changePrompt(char parameters[][MAX_LENGTH]) {
    strcpy(PROMPT, parameters[0]);
    return 0;
}
