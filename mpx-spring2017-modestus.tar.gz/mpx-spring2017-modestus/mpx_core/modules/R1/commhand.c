#include <core/serial.h>
#include <input.h>
#include <string.h>
#include "include/comm_list.h"
#include <linked_list.h>



char parsed[MAX_IN][MAX_LENGTH]={{""}};
char in_string[MAX_LENGTH] = {""};
int shutdown = 0;


// Command array that matches comm_list.h
cmd_struct_t cmdArray[MAX_CMD_LIST_LENGTH];

/**
 * @brief parse_comm Parses the input recieved from the user input using ' ' as a delimeter
 * @param in_string The string input recieved from the user
 * @param parsed The pointer to each parsed string
 */

void parse_comm(char in_string[MAX_LENGTH], char parsed[MAX_IN][MAX_LENGTH]) {
    const char *tokens = " '\"/:.";
    char *token = strtok(in_string, tokens);
    int i = 0;
    while (token != NULL) {
        strcpy(parsed[i], token);
        token = strtok(NULL, tokens);
        i++;
    }
}

/**
 * @brief exec_comm Takes parsed input and calls the proper command
 * @param in_string The string input recieved from the user
 */
void exec_comm(char in_string[MAX_LENGTH]) {
    serial_println("");



    parse_comm(in_string, parsed);

    /*OLD WAY*/
//    if(strcmp(parsed[0],"help")==0) {
//        if(strcmp(parsed[1],"")==0) {
//            help();
//        } else if(strcmp(parsed[1],"version")==0) {
//            helpGetVersion();
//        }  else if(strcmp(parsed[1],"shutdown")==0) {
//            helpShutdown();
//        } else if(strcmp(parsed[1],"time")==0) {
//            helpTime(&parsed[2]);
//            //serial_println("Did you mean 'get time' or 'get date'?");
//        } else if(strcmp(parsed[1],"date")==0) {
//            helpDate(&parsed[2]);
//            //serial_println("Did you mean 'set time' or 'set date'?");
//        } else {
//            serial_println(IMPROPER_COMMAND);
//        }
//        //        else {
//        //	        serial_println(IMPROPER_COMMAND);
//        //	    }


//    } else if(strcmp(parsed[0],"version")==0) {
//        if(strcmp(parsed[2],"")==0) {
//            if(strcmp(parsed[1],"")==0) {
//                version();

//            } else {
//                serial_println(UNKNOWN_COMMAND);
//            }
//        }
//    } else if(strcmp(parsed[0],"date")==0) {
//        if(strcmp(parsed[1],"get")==0) {
//            getDate();
//        } else if(strcmp(parsed[1],"set")==0) {
//            setDate(&parsed[2]);
//        } else {
//            serial_println(IMPROPER_COMMAND);
//        }

//    } else if(strcmp(parsed[0],"time")==0) {
//        if(strcmp(parsed[1],"set")==0) {
//            setTime(&parsed[2]);
//        } else if(strcmp(parsed[1],"get")==0) {
//            getTime();
//        } else {
//            serial_println(IMPROPER_COMMAND);
//        }

//    } else if(strcmp(parsed[0],"shutdown")==0) {
//        if(strcmp(parsed[1],"")==0) {
//            int confirm = 0;

//            serial_print("Confirm shutdown y/n?: ");

//            if(confirm == 0) {
//                serial_print(PROMPT);
//                strcpy(in_string, serial_poll(in_string));
//                if(strcmp(in_string, "y")==0)
//                    confirm = 1;
//                else if (strcmp(in_string, "n")==0)
//                    confirm = 2;
//            }
//            serial_println(" ");
//            if(confirm == 1)
//                shutdown = 1;
//        } else {
//            serial_println(UNKNOWN_COMMAND);
//        }


//    } else {
//        serial_println(IMPROPER_COMMAND);
//    }

    /*END OLD WAY*/
    /*
    serial_println("0");
    serial_println((const char *)parsed[0]);
    serial_println("1");
        serial_println((const char *)parsed[1]);
    serial_println("2");
        serial_println((const char *)parsed[2]);
    serial_println("3");
        serial_println((const char *)parsed[3]);
    serial_println("4");
        serial_println((const char *)parsed[4]);
    serial_println("5");
        serial_println((const char *)parsed[5]);
    serial_println("6");
        serial_println((const char *)parsed[6]);
    serial_println("7");
        serial_println((const char *)parsed[7]);
*/

    /* Check for valid input */
    int j=0;
    int output = -99;
    for(;j<MAX_CMD_LIST_LENGTH;j++) {
        if(strcmp(cmdArray[j].cmdName, parsed[0])==0) {
            output = (*(cmdArray[j].cmdFunc))(&(parsed[1]));
            if(output == 9) {
                shutdown = 1;
                break;
            }
        }
    }




    /* Reset the array of parsed input */
    int i=0;//, j=0;
    for(;i<MAX_LENGTH;i++) {
        *parsed[i] = (char)'\0';
    }
    if(output == -99)
    {
        serial_println("Invalid Command! \r\n");
    }


}

void initCmdArray(cmd_struct_t* arr) {
    arr[0].cmdName = "help";
    arr[0].cmdFunc = &helpFunc;

    arr[1].cmdName = "version";
    arr[1].cmdFunc = &version;

    arr[2].cmdName = "date";
    arr[2].cmdFunc = &date;

    arr[3].cmdName = "time";
    arr[3].cmdFunc = &time;

    arr[4].cmdName = "shutdown";
    arr[4].cmdFunc = &shutdownFunc;

    arr[5].cmdName = "pcb";
    arr[5].cmdFunc = &pcbFunc;

    arr[6].cmdName = "loadr3";
    arr[6].cmdFunc = &loadr3;

    arr[7].cmdName = "mcb";
    arr[7].cmdFunc = &mcbFunc;

    arr[8].cmdName = "cp";
    arr[8].cmdFunc = &changePrompt;
}


/**
 * @brief init_commhand Starts input loop and waits for shutdown code
 */ 

void init_commhand(int argc, char ** argv) {
    printf("Commhand Argc test: %d\r\n", argc);
    (void)argv;
    initCmdArray(cmdArray);

    *parsed[0]=0;
    (*(cmdArray[0].cmdFunc))(&(parsed[0]));

    int i=0;//, j=0;
    for(;i<MAX_LENGTH;i++) {
        *parsed[i] = (char)'\0';
    }
    while(!shutdown) {
        serial_print(getPrompt());
        serial_print(" ");
        serial_poll(in_string);
        exec_comm(in_string);
        sys_req(IDLE);
    }

}

