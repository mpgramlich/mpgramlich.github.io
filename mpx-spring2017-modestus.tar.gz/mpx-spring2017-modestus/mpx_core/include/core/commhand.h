void init_commhand(void);
char *get_hist_up(void);
