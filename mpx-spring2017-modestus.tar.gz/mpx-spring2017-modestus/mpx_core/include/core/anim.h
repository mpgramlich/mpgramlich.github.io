void start_up_anim(void);
void busy_wait(void);
void clear_screen(void);
