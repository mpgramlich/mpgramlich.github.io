#ifndef MCB_H
#define MCB_H

#include <system.h>
#include <mem/heap.h>
#include <core/pcb.h>
#include <linked_list.h>


extern linkedList_t mcbFreeList;
extern linkedList_t mcbAllocList;

/**
  * @brief The e_mcb_result_t enum defines the return status of functions working with MCBs
  */
typedef enum { MCB_SUCCESS, ERROR_BLOCK_NOT_FOUND, ERROR_BLOCK_NOT_ALLOCATED, ERROR_GENERIC, ERROR_NOT_ENOUGH_MEMORY,
                MCB_ERROR_ACCESS_DENIED }
             e_mcb_result_t;

/**
  * @brief The e_mcb_type_t enum defines the state of the MCBs.
  */
typedef enum { MCB_FREE, MCB_ALLOCATED, MCB_NOT_FREE }
             e_mcb_type_t;

extern e_mcb_result_t lastMCBError;

typedef struct s_cmcb cmcb_t;

typedef struct s_lmcb lmcb_t;

typedef void*  mcbAddressPtr_t;

typedef size_t mcbSize_t;

typedef void*  heapLocationPtr_t;

/**
 * @brief The s_cmcb struct the struct type for cmcb's -> defines the properties
 */
struct s_cmcb
{
    node_t representingNode;

    e_mcb_type_t cmcbType;

    mcbSize_t mcbBlockSize;

    const char* procName;

    lmcb_t* associatedLMCB;

    mcbAddressPtr_t blockStartAddress;

}__attribute__((packed));

/**
 * @brief The s_lmcb struct defines the properties of lmcb's
 */
struct s_lmcb
{
    mcbAddressPtr_t blockStopAddress;

    mcbSize_t mcbBlockSize;

    e_mcb_type_t lmcbType;
}__attribute__((packed));

/**
 * @brief initHeap initializes the system heap by calling kmalloc with a valid byte size.  Creates a CMCB at the beginning
 * and an LMCB at the end.  Note the total size is the given size + sizeof(CMCB) + sizeof(LMCB).
 * @param initialHeapSize the size in bytes of the heap to be created
 */
void  initHeap(size_t initialHeapSize);

/**
 * @brief allocateMemFromHeap takes the requested size and finds the first block that fits. Implements first fit.
 * Size_t is unsigned.
 * @param requestedSize size in bytes to the allocated from the heap.
 * @return a pointer to the beginning of the block of memory requested.
 */
void* allocateMemFromHeap(size_t requestedSize);

/**
 * @brief freeHeapMem takes the block address and frees the memory from the CMCB start to the LMCB end location
 * and calls reclaimFreeMem() function.
 * @param blockAddress pointer to the memory address to be freed.
 * @return the error code if any exists.
 */
int  freeHeapMem(void* blockAddress);

mcbSize_t sizeOfHeapAllocated();
mcbSize_t sizeOfHeapFree();

/**
 * @brief printAlloc prints the allocated memory blocks.  Traverses through the allocated mcb list.
 */
void printAlloc();

/**
 * @brief printFree prints the free memory blocks. Traverses through the free mcb list.
 */
void printFree();

/**
 * @brief heapIsEmpty returns if the heap is empty.
 * @return an integer, if heap is empty -> returns 0, if heap is not empty -> returns 1.
 */
int heapIsEmpty();

const char* mcbResultToString(e_mcb_result_t result);
const char* mcbTypeToString(e_mcb_type_t type);

/**
 * @brief mcbCompareFunc compares the start addresses of two mcbs.
 * @param mcb pointer to mcb
 * @param mcbToCompare pointer to mcb to compare with.
 * @return
 */
int mcbCompareFunc(void* mcb,  void* mcbToCompare);

/**
 * @brief mcbSearchCompFunc searches for the mcb that you want to compare with.
 * @param mcb pointer to mcb.
 * @param blockStartAddress start address of memory.
 * @return
 */
int mcbSearchCompFunc(void* mcb,  void* blockStartAddress);

/**
 * @brief insertMCBIntoList inserts the mcb into the list specified.
 * @param blockToInsert the mcb block to insert into.
 */
void insertMCBIntoList(cmcb_t* blockToInsert);

/**
 * @brief heapTest test function to create sample mcbs.
 */
void heapTest();

/**
 * @brief printMCBFunc prints the type, block size, block pointer of the blocks in a given list.
 * @param cmcb CMCB to be printed out.
 */
void printMCBFunc(void* cmcb);

/**
 * @brief reclaimFreeMem groups free blocks together if they are adjacent.
 */
void reclaimFreeMem();

#endif // MCB_H
