#ifndef RTC_H
#define RTC_H

#include <core/io.h>
#include <system.h>

#define RTC_INDEX_REG 0x70
#define RTC_DATA_REG 0x71

#define SECONDS_INDEX           0x00
#define MINUTES_INDEX           0x02
#define HOURS_INDEX             0x04
#define DAY_OF_MONTH_INDEX      0x07
#define MONTHS_INDEX            0x08
#define YEAR_INDEX              0x09


/**
 * @brief get_time this function will retrieve the system time and place it in three pointers. Military time
 *
 * @param hours pointer to int where the current hours will be stored, in UTC timezone
 * @param minutes pointer to int where the current minutes will be stored, in UTC timezone
 * @param seconds pointer to int where the current seconds will be stored, in UTC timezone
 */
void get_time(int *hours, int *minutes, int *seconds);

/**
 * @brief set_time sets the RTC time. Military time
 *
 * @param hours the hours to set the clock to, must be less than 24. In UTC Time zone
 * @param minutes the minutes to set the clock to, must be less than 60. In UTC Time zone
 * @param seconds the seconds to set the clock to, must be less than 60. In UTC Time zone
 */
void set_time(int hours, int minutes, int seconds);



/**
 * @brief get_date this function will retrieve the system date and place in three pointers
 *
 * @param day pointer to int where the current day will be stored, UTC Time zone
 * @param months pointer to int where the current month will be stored, UTC Time zone
 * @param year pointer to int where the current year will be stored, UTC Time zone
 */
void get_date(int *day, int *month, int *year);

/**
 * @brief set_date sets the RTC Date
 *
 * @param day the day to set the clock to, must be valid for the month. UTC Time zone
 * @param month the month to set the clock to, must be between 1 and 12. UTC Time zone
 * @param year the year to set the clock to, must be less than 100. UTC Time zone
 */
void set_date(int day, int month, int year);

#endif // RTC_H
