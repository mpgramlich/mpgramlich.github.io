/**
  * \addtogroup R2
  *     This grouping provides a quick access to all development that occured during module R2. Each function or file that was added
  *         during this module can be found here.
  * @{
  * @file
  * @}
  * \addtogroup R3
  *     This grouping provides a quick access to all development that occured during module R2. Each function or file that was added
  *         during this module can be found here.
  * @{
  * @}
  */

#ifndef PCB_H
#define PCB_H

#include <system.h>
#include <linked_list.h>

#define PROCESS_CONTEXT_SIZE (32) //4*32
#define PROCESS_STACK_SIZE (6000) //bytes
#define PCB_QUEUE_MAX_SIZE (128)
#define PROCESS_MAX_NAME_LENGTH (20)

#define  PROCESS_LOWEST_PRIORITY 0
#define PROCESS_HIGHEST_PRIORITY 9

extern linkedList_t readyQueue;
extern linkedList_t blockedQueue;
extern linkedList_t suspendedReadyQueue;
extern linkedList_t suspendedBlockedQueue;


/**
 * @brief The e_PCB_ERROR_CODE_t enum defines the return status of functions working with PCBs
 */
typedef enum {SUCCESS = 0, ERROR, ERROR_PCB_NOT_FOUND, ERROR_NAME_INVALID, ERROR_PRIORITY_INVALID,
                            ERROR_FREEING_NODE, ERROR_FREEING_STACK, ERROR_FREEING_PCB, ERROR_REMOVING_PCB, ERROR_STATE_INVALID,
                            ERROR_CLASS_INVALID, ERROR_ALLOCATING_NODE, ERROR_NAME_COLLISION, ERROR_INSERTING_PCB}
             e_PCB_ERROR_CODE_t;
extern e_PCB_ERROR_CODE_t prevPCBError;

/**
 * @brief The PROCESS_STATE_t enum defines the possible operating states of a process
 */
typedef enum {INITIAL, READY, RUNNING, BLOCKED, TERMINAL, STATE_UNKNOWN} e_PROCESS_STATE_t;

typedef enum {SUSPENDED, NOT_SUSPENDED, SUSPENSION_UNKNOWN} e_PROCESS_SUSPENSION_STATE_t;

/**
 * @brief The PROCESS_CLASS_t enum defines the operating class of the process
 */
typedef enum {SYSTEM, USER_APP, CLASS_UNKNOWN} e_PROCESS_CLASS_t;

/**
 * @struct pcb_t pcb.h pcb
 * @brief typedef for pcb_t struct
 * @see pcb_struct_t
 */
typedef struct s_pcb_stuct pcb_t;




extern pcb_t* currentOperatingProcess;





/**
 * @struct pcbQueue_t pcb.h pcb
 * @brief typedef for pcbQueue_t struct
 * @see s_pcb_list
 */
typedef struct s_pcb_list pcbQueue_t;

/**
 * @brief PID_t a type that defines a process operating ID
 */
typedef size_t PID_t;

/**
 * @brief processPriority_t defines a process priority to the system
 */
typedef size_t processPriority_t;

/**
 * @brief programPtr_t a pointer to a process's code
 */
typedef uint8_t programPtr_t;

/**
 * @brief programDataPtr_t a pointer to a process's data
 */
typedef uint32_t programDataPtr_t;

/**
 * @brief processStack_t a pointer to someplace in a process's stack
 */
typedef uint8_t processStack_t;

/**
 * @brief defines the properties of a process control block
 */
struct s_pcb_stuct
{
    char name[PROCESS_MAX_NAME_LENGTH];
    PID_t PID;
    size_t priority;

    e_PROCESS_STATE_t processState;
    e_PROCESS_SUSPENSION_STATE_t processSuspensionState;

    e_PROCESS_CLASS_t processClass;

    processContext_t* context;
    processStack_t stack[PROCESS_STACK_SIZE];

    //pcb_queue_t children;

    programPtr_t* programStart;
    size_t programSize;

    programDataPtr_t* dataStart;
    size_t dataSize;

    processStack_t* stackBase;
    processStack_t* stackTop;

    node_t* representingNode;

};

/**
 * @brief allocatePCB allocate new memory for a pcb_t
 * @return null if error, else pointer to pcb_t
 */
pcb_t* allocatePCB(void);

/**
 * @brief freePCB free all associated memory with the PCB, including the stack and other pointers
 * @param pcbToFree pointer to PCB to free
 * @return PCB_ERROR_CODE_t describing result
 */
e_PCB_ERROR_CODE_t freePCB(pcb_t* pcbToFree);

/**
 * @brief setupPCB calls allocatePCB, initializes the PCB with the arguments and sets it state to ready
 * @param processName the name of the new process
 * @param processClass the class of the new process
 * @param processPriority the priority of the new process, must be between 0-9
 * @return null if error, pointer to new PCB otherwise
 */
pcb_t* setupPCB(const char* processName, e_PROCESS_CLASS_t processClass, processPriority_t processPriority);

/**
 * @brief findPCB will search all queues for the PCB with the input name
 * @param processName the name of the PCB searching for
 * @return null if PCB not found, otherwise returns pointer to pcb_t represented by name
 */
pcb_t* findPCB(const char* processName);

/**
 * @brief insertPCB insert the PCB into the queue represented by the process state, following each queue's rules
 * @param pcbToInsert pointer to pcb_t to insert
 */
void insertPCB(pcb_t* pcbToInsert);

/**
 * @brief removePCB remove the input PCB from its associated queue
 * @param pcbToRemove pointer to pcb_t
 * @return PCB_ERROR_CODE_t value that describes result
 */
e_PCB_ERROR_CODE_t removePCB(pcb_t* pcbToRemove);

/**
 * @brief getState gets the current state of the process
 * @param name the name of the process
 * @return e_PROCESS_STATE_t the state of the process
 * \ingroup R2
 */
e_PROCESS_STATE_t getState(const char* name);
/**
 * @brief pcbSearchFunc pcb search function for linked list. All pcb linkedLists use this function for searching
 *          See \ref setSearchComparisonFunction "Linked List documentation" for a description of a list search function
 * @param pcb void* to pcb structure
 * @param nameToFind void* to (const char*)
 * @return 0 if the name of the pcb matches nameToFind
 */
int pcbSearchFunc(void* pcb,  void* nameToFind);

/**
 * @brief priorityInsertFunc function that inserts pcbs into new pcb queues ordered by the pcbs' priority. See
 *         \ref setInsertComparisonFunction "Linked List documentation" for a better description of a list insert function.
 * @param pcb1 void* to a pcb to compare with
 * @param pcb2 void* to the pcb to insert
 * @return see \ref setInsertComparisonFunction "Linked List documentation" for a description on the returned value
 */
int priorityInsertFunc(void* pcb1, void* pcb2);

/**
 * @brief priorityInsertFunc function that inserts pcbs into new pcb queues ordered by the sequence of arrival. See
 *         \ref setInsertComparisonFunction "Linked List documentation" for a better description of a list insert function.
 * @param pcb1 void* to a pcb to compare with
 * @param pcb2 void* to the pcb to insert
 * @return see \ref setInsertComparisonFunction "Linked List documentation" for a description on the returned value
 */
int fifoInsertFunc(void* pcb1, void* pcb2);

/**
 * @brief initPCBQueues initlize the queues for each process queue. This function calls the list init function and
 *           sets the function pointers for each list
 */
void initPCBQueues(void);

/**
 * @brief pcbTest a simple test case function to show pcb queue functionality
 */
void pcbTest(void);

/**
 * @brief changeProcessState changes the state of the process being called
 * @param name the name of the process to change the state of
 * @param state the state to change the process to
 * @return e_PCB_ERROR_CODE_t value that describes the result
 * \ingroup R2
 */
e_PCB_ERROR_CODE_t changeProcessState(const char* processName, e_PROCESS_STATE_t state);

/**
 * @brief changeProcessSuspensionState
 * @param name
 * @param suspensionState
 * @return
 *
 * @todo comment this
 */
e_PCB_ERROR_CODE_t changeProcessSuspensionState(const char* processName, e_PROCESS_SUSPENSION_STATE_t suspensionState);

/**
 * @brief errorToString creates a string form of the error passed in
 * @param error the error to parse to a string
 * @return the const char* of the error
 * \ingroup R2
 */
const char* errorToString(e_PCB_ERROR_CODE_t error);

/**
 * @brief classToString creates a string form of the class passed in
 * @param class the class to parse to a string
 * @return the const char* of the class
 * \ingroup R2
 */
const char* classToString(e_PROCESS_CLASS_t processClass);

/**
 * @brief stateToString creates a string form of the state passed in
 * @param state the state to parse to a string
 * @return the const char* of the state
 * \ingroup R2
 */
const char* stateToString(e_PROCESS_STATE_t state);

/**
 * @brief stringToClass returns the enum representation of a string
 * @param stringifiedClass the string that represents a process class enum
 * @return string represenation of the \ref e_PROCESS_STATE_t "e_PROCESS_STATE_t" enum,
 *          returns value CLASS_UNKNOWN if error in processing occurs;
 * \ingroup R2
 */
e_PROCESS_CLASS_t stringToClass(const char * stringifiedClass);

/**
 * @brief changeProcessPriority
 * @param procName
 * @param newPriority
 * @return
 * @todo comment this
 */
e_PCB_ERROR_CODE_t changeProcessPriority(const char * procName, processPriority_t newPriority);

/**
 * @brief printPCBFunc prints the status of a process
 * @param pcb void pointer to a process
 * \ingroup R2
 */
void printPCBFunc(void* pcb);

/**
 * @brief resumeAll resumes all processes in the suspended ready state
 * \ingroup R3
 */
e_PCB_ERROR_CODE_t resumeAll();
#endif // PCB_H
