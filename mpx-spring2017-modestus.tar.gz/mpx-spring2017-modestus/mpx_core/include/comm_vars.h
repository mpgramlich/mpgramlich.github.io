#define VERSION "R5"
#define IMPROPER_COMMAND "That is not a proper command.  Type 'help' to see a list of commands."
#define UNKNOWN_COMMAND "UNKOWN COMMAND, type 'help' to see a list of commands and arguments."
#define EXTRA_PARAMETERS "Extra parameter found: "
