/**
  * @addtogroup R2
  * @{
  * @file
  * This module provides a generic linked list that can be array backed or
  *     use dynamic allocation
  * @}
  */
#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include "string.h"


//#define LL_IS_ARRAY_BACKED 1  //this defines if the linked list is back by an array of constant size or dynamically allocated

#ifndef LL_IS_ARRAY_BACKED
#include <core/mpx_supt.h>  //if the list is dynamically allocated, then we need the allocation functions from the core.
#endif

//maximum number of nodes if the list is array backed.
#define MAX_NUM_OF_LL_NODES 256

/**
 * @struct linkedList_t linked_list.h linked_list
 * @brief typedef of linked list (see \ref s_ll "s_ll").
 * @see s_ll
 * @see linked_list.h
 */
typedef struct s_ll linkedList_t;

/**
 * @struct node_t linked_list.h linked_list
 * @brief typedef of linked list node (see \ref s_ll_node "s_ll_node").
 * @see s_ll_node
 * @see linked_list.h
 */
typedef struct s_ll_node node_t;

/**
 * @struct s_ll_node linked_list.h linked_list
 * @brief struct for a node of the linked list
 * @see s_ll
 * @see linked_list.h
 */
struct s_ll_node
{
    void *data;
    node_t *next;
    node_t *prev;
#ifdef LL_IS_ARRAY_BACKED
    linkedList_t *parentList;
    unsigned char inUse;
#endif
};

/**
 * @struct s_ll linked_list.h linked_list
 * @brief struct definition for the linked list
 * @see linked_list.h
 */
struct s_ll
{
    node_t head;
    node_t tail;
    int (*searchCompFunc)(void*, void*); /** @see setSearchComparisonFunction */
    int (*insertCompFunc)(void*, void*); /** @see setInsertComparisonFunction */
    int (*freeNodeFunc)(node_t *nodeToFree); /** @see setFreeFunction */
    void (*printNodeFunc)(void*);       /** @see setPrintFunction */
    size_t length;
#ifdef LL_IS_ARRAY_BACKED
    unsigned int numNodesInUse;
    node_t backingArray[MAX_NUM_OF_LL_NODES];
#endif
};

/**
  * defines a macro that will generate a new type that has a different array backing size,
  *     new type has the name linkedList_<list_length>_t
  */
#define VARIABLE_LL_LENGTH(LIST_LENGTH) { \
    typedef struct s_ll_##LIST_LENGTH##_t linkedList_##LIST_LENGTH##_t \
    struct s_ll_##LIST_LENGTH##_t \
    { \
        node_t head; \
        node_t tail; \
        int (*searchCompFunc)(void*, void*); \
        int (*comparisonFunc)(void*, void*); \
        int (*freeNodeFunc)(node_t *nodeToFree); \
        void (*printList)(void*); \
        size_t length; \
        unsigned int numNodesInUse; \
        node_t backingArray[LIST_LENGTH]; \
    }; \
}


/**
 * @brief initilize list and the optional array that backs the list
 * @param list pointer to list
 */
void initLinkedList(linkedList_t *list);


/**
 * @brief insert a node into the parent list of the preceedingNode after preceedingNode
 * @param preceedingNode node to insert the new node afterwards
 * @param newNode the new node to insert. if the list is array backed, the newNode will be copied to the list's node pool if it currently does not reside there
 * @return pointer to node inserted in the parent list of preceedingNode, null if insertion failed
 */
node_t * insertAfterNode(node_t *preceedingNode, node_t *  newNode);

/**
 * @brief insert a node into the parent list of the nodeToFollow before nodeToFollow
 * @param nodeToFollow node to insert the newNode before
 * @param newNode the new node to insert. if the list is array backed, the newNode will be copied to the list's node pool if it currently does not reside there
 * @return pointer to node inserted in the parent list of nodeToFollow, null if insertion failed
 */
node_t * insertBeforeNode(node_t *  nodeToFollow, node_t *newNode);

/**
 * @brief Will insert the node into the list. This function will attempt to call the list's \ref setInsertComparisonFunction "insert comparison" function
 *          if defined. The function will insert the new node into the list after this function returns > 0. If the \ref setInsertComparisonFunction "insert comparison" function
 *          is not defined for this list, the inserting function will placed the new node at the end of the list before the tail.
 * @param list list to place the node
 * @param newNode the new node to insert. if the list is array backed, the newNode will be copied to the list's node pool if it currently does not reside there
 * @return pointer to the node in the new list, or null if inserting failed.
 */
node_t * insertNode(linkedList_t *list, node_t * newNode);


/**
 * @brief get new node, allocate a new node or find an unused node from the list's pool
 * @param list to find an unused node from. This argument is ignored if the list is dynamically allocated
 * @param data pointer to the data the new node should contain, the pointer must be valid obviously
 * @return pointer to new node, null if no new node could be found or created
 */
node_t *makeNewNode(linkedList_t *list, void *data);

/**
 * @brief If a node needs to move lists and lists are array backed, instead of just moving preceeding and suceeding pointers
 *                              of the node, the node actaully needs to move backing arrays so one list's nodes are not the only ones
 *                              being consumed. The equivalent process will be to execute the parent list's removeNode funcion, execute
 *                              the makeNewNode function on the newList, copy all structure members to the new node, and return the
 *                              new node. The list of nodeToMove freeNodeFunc will be called with nodeToMov as the argument.
 *                              If the lists are not array backed, the function simply removes the node from its containing list and calls
 *                              insertNode on the new list.
 * @param nodeToMove the node to move, this pointer is no longer guarenteed to be valid. Stop using this pointer,
 * @param newList the list to move the node to, this will be the node's new parent list
 * @return the pointer of param nodeToMove will no longer be valid, the pointer to the node in the new list will be returned on sucess.
 *              Null on failure and nodeToMove will remain valid
 */
node_t *  moveNodeToNewList(node_t *nodeToMove, linkedList_t *newList);


/**
 * @brief sets the function whose job it is to free the node's memory
 * @param list the list to set the function pointer for
 * @param newFreeFunc the job of this function should be to free the memory with the node once it the list no longer needs it. This can be literally through free() or by other means.
 */
void setFreeFunction(linkedList_t *list, int (*newFreeFunc)(node_t *));

/**
 * @brief takes in a function pointer and sets the library shared comparison pointer
 * @param list the list to set the function pointer for
 * @param newCompFunc pointer to function whose job is to define the comparison of the data stored in the node
 *          this function should return 0 if the comparison succeeds. The function should return < 0 if the data to compare
 *          comes after the data in the node. The function should return > 0 if the data to compare comes before the data
 *          in the node. The first void argument is guarenteed to be the data from the list to compare against. The second void
 *          argument is the data in the node passed to the \ref insertNode "insertNode" function
 */
void setInsertComparisonFunction(linkedList_t* list, int (*newCompFunc)(void*, void*));

/**
 * @brief sets the function whose job it is to print the list to the screen.
 * @param list to set the search funtion for
 * @param newPrintFunc pointer to function whose job is to print the data contained in the node. The argument of this
 *          function is the data conatined in the node. Traversal of the list starts one after the head and goes to the
 *          node before the tail.
 * \ingroup R2 
 */
void setPrintFunction(linkedList_t *list, void (*newPrintFunc)(void*));

/**
 * @brief sets the function whose job it is to compare the input data with the data in the list.
 *                              the first void parameter will always be the data contained in the list, the second
 *                              will be the data passed to the search function.
 * @param list to set the search function for
 * @param newSeachFunc pointer to function whose job is to define the comparison of the data stored in the node
 *          this function should return 0 if the comparison succeeds. The function should return < 0 if the data to compare
 *          comes after the data in the node. The function should return > 0 if the data to compare comes before the data
 *          in the node. The first void argument is guarenteed to be the data from the list to compare against. The second void
 *          argument is the data passed to the \ref searchList "searchList" function
 */
void setSearchComparisonFunction(linkedList_t *list, int (*newSearchFunc)(void*, void*));



/**
 * @brief will remove the node from the list. the list hierarchy will change to reflect the missing node.
 * @param nodeToRemove pointer to the node to remove
 * @return pointer to the removed node
 */
node_t * removeNode(node_t *nodeToRemove);

/**
 * @brief goes through the list using the list's comparison function to find the node which matches the data. if the search function
 *          is undefined for this list, the function returns null immedietly.
 * @param listToSearch the list to search
 * @param data valid pointer to data that can be dereferenced. this pointer will be the second argument to the list's
 *           \ref setSearchComparisonFunction "search comparison" function
 * @return null if not found, else pointer to the node that matches.
 */
node_t *searchList(linkedList_t *listToSearch, void *data);



/**
 * @brief test function to show list functionality. uses const char* as test data
 * @param list list to print the nodes of
 */
void printList(linkedList_t *list);

/**
 * @brief test the linked_list class with const char* data
 *          and output to screen the results of the test
 */
void listTest();

#endif // LINKEDLIST_H
