#ifndef ARG_LIST__
#define ARG_LIST__

//added matt-g 1/15/17

//because the i386 architecture only passes arguments by stack, we can leverage
    //the fact we have a pointer to the beginning of the function's stack in the form
    //of the preceeding required argument for the ellipses.
    
//this method only works if we know what should be on the stack, the only info
    //we have of the stack would be a format string passed into a function like printf
    
//arguments on i386 are pushed right to left in the call, meaning the left-most 
    //argument is at the bottom of the functions stack.
    
/**
 * arg_list maintatins a pointer to the current argument on the stack
 */
#define arg_list unsigned char*

/**
 * input args are an arg_list, and the last argument of a variadic function
 * @brief implemented in macro because there are no templates in C
 */
#define init_arg_list(argList, argBeforeEllipses) { \
        argList = (unsigned char*)&argBeforeEllipses; \
    } \

/**
 * @brief arg_size_on_stack decides how large the argument would be on the stack
 * @param formatType the format specifier from format strings for printf
 * @param isLong the length of arguments on the stack change if the format specifier is long (not implemented)
 * @return
 */
static inline unsigned int arg_size_on_stack(const char *formatType, int isLong)
{
    if(!isLong)
    {
        switch(*formatType)
        {
            case 'c': return sizeof(int); //minimum size of char on stack
            case 's': return sizeof(char*); //s is a pointer, pointer size is system size
            case 'd': case 'i': return sizeof(int); 
            case 'u': case 'o': case 'x': case 'X': return sizeof(unsigned int);
            case 'f': case 'F': case 'e': case 'E': case 'a': case'A': case 'g': case 'G':
                return sizeof(double); //float and double are pushed as double precision, 8 bytes
            case 'p': return sizeof(void*);
            default: return 0;
        }
    }
    return 0;
}

/**
 * @brief arg_size_on_stack_from_size simply returns a rounded size of an argument on the stack
 * @param size the return of sizeof for a type
 * @return the size of the argument on the stack
 */
static inline unsigned int arg_size_on_stack_from_size(const unsigned int size)
{
    return (size < 4) ? sizeof(int) : size;
}

/**
 * @brief next_arg_in_list finds the pointer to the next argument on the stack from an input arg_list
 * @param list the function's arg_list type
 * @param formatType the format specifier from printf, used to determine the type size on the stack
 * @param isLong is the argument on the stack long (not implemented)
 * @return a void pointer to the argument on the stack
 */
static inline void* next_arg_in_list(arg_list* list, const char *formatType, int isLong)
{
    *list+=arg_size_on_stack(formatType, isLong);
    return (void*)(*list);
}

#endif  //ARG_LIST__
