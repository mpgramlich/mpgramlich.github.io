#ifndef _STRING_H
#define _STRING_H

#include <system.h>
#include <arg_list.h>
#include <core/serial.h>

/**
 * @brief isspace Determines if a character is a whitespace.
 * @param c character to check.
 * @return 1 if it is a whitespace, 0 if it is not a whitespace.
 */
int isspace(const char *c);

/**
 * @brief memset Set a region of memory.
 * @param s destination.
 * @param c byte to write.
 * @param n count.
 * @return void.
 */
void* memset(void *s, int c, size_t n);

/**
 * @brief strcpy copies one string to another string
 * @param s1 destination string.  Character pointer to a string.
 * @param s2 source string.  Character pointer to a string.
 * @return return s1.
 */
char* strcpy(char *s1, const char *s2);

/**
 * @brief strcat concatenates the contents of one string onto another.
 * @param s1 destination string.
 * @param s2 source string.
 * @return The combined string s1 and s2.
 */
char* strcat(char *s1, const char *s2);

/**
 * @brief strlen returns the length of a string
 * @param s character pointer to a string
 * @return the length of the string
 */
int   strlen(const char *s);

/**
 * @brief strcmp compares two strings.
 * @param s1 string 1 to compare.
 * @param s2 string 2 to compare.
 * @return if the two strings are equal.  If they are equal it will return 0, otherwise will return a non-zero integer.
 */
int   strcmp(const char *s1, const char *s2);

/**
 * @brief strtok Split string into tokens.
 * @param s1 String to split
 * @param s2 Delimeter.
 * @return String split into delimeters.
 */
char* strtok(char *s1, const char *s2);

/**
 * @brief atoi converts and ASCII string to an integer
 * @param s const char *s, character pointer to a string.
 * @return the integer value of s.
 */
int atoi(const char *s);

/**
 * @brief intToS converts a signed integer to string
 * @param i integer to convert
 * @param buf buf to place the converted string
 * @param bufLength length of the buffer, string writing will not exceed this value
 * @return num of characters written to buffer
 */
int intToS(const int * const i, char *buf, int bufLength);

/**
 * @brief is_conversion_specifier checks to see if the character is one of the standard printf formats
 * @param c character to check
 * @return returns the character if the character is a format specifier, else returns 0
 */
char is_conversion_specifier(char c);

/**
 * @brief isnum inline helper function to check if a character is represents an ascii number
 * @param c character to check
 * @return returns 1 if the character is an ascii number, else returns 0
 */
int isnum(const char c);



/**
 * @brief sprintf print with format to specified string buffer
 * @param str a char *, place where the built string will be placed
 * @param bufLength the size of the buffer of the char *, string writing will not exceed this value
 * @param format a format string confirming to the std library format
 * @param ... any number of parameters that will be printed according to the format. if wrong type is specified, behavior is undefined
 * @return the number of characters placed in the output buffer
 */
int sprintf(char *str, int bufLength, const char *format, ...) __attribute__((format(printf,3,4),cdecl));

//int printf(const char *format, ...) __attribute__((format(printf,0,1)));

/**
  * @brief printf is simply a wrapper macro around sprintf with built in terminal print builtin
  *             needs to be a macro to pass on varidic function args. Uses the C Language BUILT-IT macro
  *             to use marco varidic functionability.
  */
#define printf(format, ...) \
{ \
    char buf[500]; \
    sprintf(buf, 500, format, __VA_ARGS__); \
    serial_print(buf); \
} \

#endif
