#ifndef INPUT_H__
#define INPUT_H__

/* System Variables */
#define MAX_BUFFER 32
#define MAX_LENGTH 32
#define MAX_IN 15
#define BACKSPACE '\177'
#define DELETE	'\176'
#define ESC '\033'
#define UP 'A'
#define DOWN 'B'
#define LEFT 'C'
#define RIGHT 'D'
#define RETURN '\r'
#define NEW_LINE '\n'


/**
  * \ingroup R3
  *
  */
#define BG_WHITE "\033[48;2;255;255;255m"
#define BG_DARK_RED "\033[48;2;128;0;0m"
#define BG_BLACK "\033[48;2;0;0;0m"
#define BG_RED "\033[48;2;255;0;0m"
#define BG_GREEN "\033[48;2;0;255;0m"
#define BG_BLUE "\033[48;2;0;0;255m"
#define BG_YELLOW "\033[48;2;255;255;0m"
#define BG_MAGENTA "\033[48;2;255;0;255m"
#define BG_CYAN "\033[48;2;85;255;255m"
#define BG_ORANGE "\033[48;2;251;122;51m"
#define BG_PINK "\033[48;2;231;84;152m"

#define COLOR_RED "\033[38;2;255;0;0m"
#define COLOR_GREEN "\033[38;2;0;255;0m"
#define COLOR_BLUE "\033[38;2;0;0;255m"
#define COLOR_YELLOW "\033[38;2;255;255;0m"
#define COLOR_WHITE "\033[38;2;255;255;255m"
#define COLOR_BLACK "\033[38;2;0;0;0m\033[48;2;255;255;255m"
#define COLOR_MAGENTA "\033[38;2;255;0;255m"
#define COLOR_CYAN "\033[38;2;85;255;255m"
#define COLOR_ORANGE "\033[38;2;251;122;51m"
#define COLOR_PINK "\033[38;2;231;84;152m"
#define COLOR_RED_DARK "\033[38;2;255;255;255m"

#define COLOR_STOP "\033[0m"


#endif
