#include <system.h>
#include <string.h>


/**
 * @brief strlen returns the length of a string
 * @param s character pointer to a string
 * @return the length of the string
 */
int strlen(const char *s) // created by nick 1/23/17
{
   int length = 0;
   while(s[length] != '\0') {
    length++;
   }
   //length++;
  return length; // return length of string
}

/**
 * @brief strcpy copies one string to another string
 * @param s1 destination string.  Character pointer to a string.
 * @param s2 source string.  Character pointer to a string.
 * @return return s1.
 */
char* strcpy(char *s1, const char *s2)
{
    char* s1Cpy = s1;
  while(*s2 != '\0') {
      *s1 = *s2;
      s1++;
      s2++;
   }
   if(*s2 == '\0') {
      
      *s1 = *s2;
   }
  return s1Cpy; // return pointer to destination string
}

/**
 * @brief atoi converts and ASCII string to an integer
 * @param s const char *s, character pointer to a string.
 * @return the integer value of s.
 */
int atoi(const char *s)
{
    int num = 0;

    if(!s)
    {
        return 0;
    }
    while(*s==' '){ s++; }

    int isNeg = ( *s == '-');
    if(isNeg || (*s == '+')){ s++; }
    while((*s >= '0') && (*s <= '9' ))
    {
        num = (num*10) + (*s - '0');
        s++;
    }
    if(isNeg)
    {
        num = num *(-1);
    }

    return num; // return integer
}

/**
 * @brief strcmp compares two strings.
 * @param s1 string 1 to compare.
 * @param s2 string 2 to compare.
 * @return if the two strings are equal.  If they are equal it will return 0, otherwise will return a non-zero integer.
 */
int strcmp(const char *s1, const char *s2)
{

  // Remarks:
  // 1) If we made it to the end of both strings (i. e. our pointer points to a
  //    '\0' character), the function will return 0
  // 2) If we didn't make it to the end of both strings, the function will
  //    return the difference of the characters at the first index of
  //    indifference.
  int i = 0;
  for(; (s1[i]) && (s2[i]) && (s1[i]==s2[i]); i++)
  {
  }
  
  return s1[i]-s2[i];
}


/**
 * @brief strcat concatenates the contents of one string onto another.
 * @param s1 destination string.
 * @param s2 source string.
 * @return The combined string s1 and s2.
 */
char* strcat(char *s1, const char *s2)
{
  char *rc = s1;
  if (*s1) while(*++s1);
  while( (*s1++ = *s2++) );
  return rc;
}

/**
 * @brief isspace Determines if a character is a whitespace.
 * @param c character to check.
 * @return 1 if it is a whitespace, 0 if it is not a whitespace.
 */
int isspace(const char *c)
{
  if (*c == ' '  ||
      *c == '\n' ||
      *c == '\r' ||
      *c == '\f' ||
      *c == '\t' ||
      *c == '\v'){
    return 1;
  }
  return 0;
}

/*
  Procedure..: memset
  Description..: Set a region of memory.
  Params..: s-destination, c-byte to write, n-count
*/
/**
 * @brief memset Set a region of memory.
 * @param s destination.
 * @param c byte to write.
 * @param n count.
 * @return void.
 */
void* memset(void *s, int c, size_t n)
{
  unsigned char *p = (unsigned char *) s;
  while(n--){
    *p++ = (unsigned char) c;
  }
  return s;
}

/**
 * @brief strtok Split string into tokens.
 * @param s1 String to split
 * @param s2 Delimeter.
 * @return String split into delimeters.
 */
char* strtok(char *s1, const char *s2)
{
  static char *tok_tmp = NULL;
  const char *p = s2;

  //new string
  if (s1!=NULL){
    tok_tmp = s1;
  }
  //old string cont'd
  else {
    if (tok_tmp==NULL){
      return NULL;
    }
    s1 = tok_tmp;
  }

  //skip leading s2 characters
  while ( *p && *s1 ){
    if (*s1==*p){
      ++s1;
      p = s2;
      continue;
    }
    ++p;
  }

  //no more to parse
  if (!*s1){
    return (tok_tmp = NULL);
  }

  //skip non-s2 characters
  tok_tmp = s1;
  while (*tok_tmp){
    p = s2;
    while (*p){
      if (*tok_tmp==*p++){
	*tok_tmp++ = '\0';
	return s1;
      }
    }
    ++tok_tmp;
  }

  //end of string
  tok_tmp = NULL;
  return s1;
}


/* And finally....
   For the brave ones! (Note: you'll need to add a prototype to string.h)
   sprintf must work properly for the following types to receive extra credit:
     1) characters
     2) strings
     3) signed integers
     4) hexadecimal numbers may be useful
     ...
     \infty) Or feel free to completely implement sprintf
             (Read the man Page: $ man sprintf)
   int sprintf(char *str, const char *format, ...); 
*/

// Created by nick 1/23/17, not finished yet
//modified by matt 1/25/17, finished

/**
 * @brief sprintf print with format to specified string buffer
 * @param str a char *, place where the built string will be placed
 * @param bufLength the size of the buffer of the char *, string writing will not exceed this value
 * @param format a format string confirming to the std library format
 * @param ... any number of parameters that will be printed according to the format. if wrong type is specified, behavior is undefined
 * @return the number of characters placed in the output buffer plus the null character
 */
int  sprintf(char *str, int bufLength, const char *format, ...)
{ 

    if(!str || bufLength <= 0) {
     return 0;
    }

    arg_list list;
    init_arg_list(list, format);

    int newStrIndex = 0;
    int index, formatLength = strlen(format);
    for(index = 0; format[index] != '\0' && index <= formatLength; index++)
    {
     
     //flag is -1 until fulfilled, flag is 0 if not requested
        if(format[index] == '%')
        {
            char leftJustified=0, alwaysAppendSign=0, subSignWithSpace=0, altForm=0, padWithZeros=0;
            int minFieldWidth=0, precision=0;
            (void)padWithZeros;
            for(; !is_conversion_specifier(format[index]); index++)
            {
                if(format[index]=='\0')
                {
                    return 0; //if we reach the end of the string, exit as the format is missing
                }
                if(!minFieldWidth && !precision)
                {
                    switch(format[index])
                    {           
                        case '-': leftJustified=1; break;
                        case '+': if(!leftJustified) {alwaysAppendSign=1;} break;
                        case ' ': if(!leftJustified && !alwaysAppendSign){subSignWithSpace=1;} break;
                        case '#': if(!leftJustified && !alwaysAppendSign && !subSignWithSpace) {altForm=1;} break;
                        case '0': if(!leftJustified && !alwaysAppendSign && !subSignWithSpace && !altForm){padWithZeros=1;} break;
                    }
                }
                if(format[index] == '.'){ precision = -1;}
                if(isnum(format[index])) //implement the * modifier here
                {
                    if(precision==-1)
                    { 
                        precision = atoi(&format[index]); 
                    }
                    else if(!minFieldWidth) 
                    { 
                        minFieldWidth = atoi(&format[index]); 
                    }
                }
            }//finished parsing one conversion   
            //need to implement all modifiers
            if(format[index]=='d')
            {
                newStrIndex += intToS((int*)next_arg_in_list(&list, &format[index], 0), &str[newStrIndex], bufLength-newStrIndex);
            }
            else if(format[index]=='c')
            {
                str[newStrIndex]= **((char**)next_arg_in_list(&list, &format[index], 0));
                newStrIndex++;
            }
            else if(format[index]=='s')
            {
                char *strToCopy = *((char**)next_arg_in_list(&list, &format[index], 0));
                int lengthOfCopy = strlen(strToCopy);
                strcpy(&str[newStrIndex], strToCopy);
                newStrIndex += lengthOfCopy;
            }
        }
        else
        {
            str[newStrIndex] = format[index];
            newStrIndex++;
        }
    }
    str[newStrIndex]=0;
    return newStrIndex;
}

//created by matt 1/25/17
//returns number of characters written
/**
 * @brief intToS converts a signed integer to string
 * @param i integer to convert
 * @param buf buf to place the converted string
 * @param bufLength length of the buffer, string writing will not exceed this value
 * @return num of characters written to buffer
 */
int intToS(const int * const i, char *buf, int bufLength)
{
    if(!buf)
    { 
        return 0; 
    }
    
    int cpy=*i;
    int length = 1;
    if(*i < 0)
    { 
        cpy*=-1;
        length++;
    }
    
    do{
        length++;
    }while((cpy/=10)); //find total length of string
    
    if(bufLength<length+1) //if the bufLength is less than the length+null term, return 0
    {
        return 0;
    }
            
    cpy=(*i<0)?(*i) * -1: *i;      //reset val copy
    length--;
    buf[length]='\0'; //insert null terminator at end of string
    length--;
    for(; length >= 0; length--) //convert int to char and copy into buffer backwards
    {
        buf[length] = cpy%10 + '0'; 
        cpy/=10;
    }
    if(*i<0)
    {
        buf[0]='-';
    }
    
    return strlen(buf);
}
    
/**
 * @brief is_conversion_specifier checks to see if the character is one of the standard printf formats
 * @param c character to check
 * @return returns the character if the character is a format specifier, else returns 0
 */
char is_conversion_specifier(char c)
{
    switch(c)
    {
        case 'c': 
        case 's': 
        case 'd': case 'i': 
        case 'u': case 'o': case 'x': case 'X': 
        case 'f': case 'F': case 'e': case 'E': case 'a': case'A': case 'g': case 'G':
        case 'p': 
            return c; 
        
        default: return 0;
    }
    return 0;
}
    
/**
 * @brief isnum inline helper function to check if a character is represents an ascii number
 * @param c character to check
 * @return returns 1 if the character is an ascii number, else returns 0
 */
inline int isnum(const char c)
{
   return ((c >= '0') && (c <= '9'));
}
    
    
    
