/*
  ----- serial.c -----

  Description..: Contains methods and variables used for
    serial input and output.
*/

#include <stdint.h>
#include <string.h>

#include <core/io.h>
#include <core/serial.h>
#include <core/commhand.h>
#include "modules/R1/include/comm_list.h"
#include <core/mpx_supt.h>
#include <input.h>

#define NO_ERROR 0

// Active devices used for serial I/O
int serial_port_out = 0;
int serial_port_in = 0;

int cmd_write_num = 0;
int current_recalled_cmd = 0;
int cmd_history_length = 0;
char* cmd_history=0;

/*
  Procedure..: init_serial
  Description..: Initializes devices for user interaction, logging, ...
*/
int init_serial(int device)
{
  outb(device + 1, 0x00); //disable interrupts
  outb(device + 3, 0x80); //set line control register
  outb(device + 0, 115200/9600); //set bsd least sig bit
  outb(device + 1, 0x00); //brd most significant bit
  outb(device + 3, 0x03); //lock divisor; 8bits, no parity, one stop
  outb(device + 2, 0xC7); //enable fifo, clear, 14byte threshold
  outb(device + 4, 0x0B); //enable interrupts, rts/dsr set
  (void)inb(device);      //read bit to reset port
  return NO_ERROR;
}

/*
  Procedure..: serial_println
  Description..: Writes a message to the active serial output device.
    Appends a newline character.
*/
int serial_println(const char *msg)
{
  int i;
  for(i=0; *(i+msg)!='\0'; i++){
    outb(serial_port_out,*(i+msg));
  }
  outb(serial_port_out,'\r');
  outb(serial_port_out,'\n');  
  return NO_ERROR;
}

/*
  Procedure..: serial_print
  Description..: Writes a message to the active serial output device.
*/
int serial_print(const char *msg)
{
  int i;
  for(i=0; *(i+msg)!='\0'; i++){
    outb(serial_port_out,*(i+msg));
  }
  if (*msg == '\r') outb(serial_port_out,'\n');
  return NO_ERROR;
}

/*
  Procedure..: set_serial_out
  Description..: Sets serial_port_out to the given device address.
    All serial output, such as that from serial_println, will be
    directed to this device.
*/
int set_serial_out(int device)
{
  serial_port_out = device;
  return NO_ERROR;
}

/*
  Procedure..: set_serial_in
  Description..: Sets serial_port_in to the given device address.
    All serial input, such as console input via a virtual machine,
    QEMU/Bochs/etc, will be directed to this device.
*/
int set_serial_in(int device)
{
  serial_port_in = device;
  return NO_ERROR;
}


void clear_buff() {
	serial_print("\033[2K");
	serial_print("\033[G");
	serial_print(getPrompt());
    serial_print(" ");
}

void return_cursor(int cursor_loc, int length) {
    int move = length - cursor_loc;
    int i = 0;
    for (; i < move; i++) {
        serial_print("\033[D");
    }
}

/*
 * @brief serial_poll Displays the user input and when a return signal is recieved, sends it to the command handler
 * @param in_string The array to hold the user input
 * @return The input string entered by the user
 */	

char *serial_poll(char in_string[MAX_LENGTH]) {
	//in_char is the character read from the register
	//out_char is that character with a null terminator appended on the end
	//length is the current size of the input
	//cursor_loc is the current location of the cursor in the input

    if(!cmd_history)
    {
        cmd_history=sys_alloc_mem(10*MAX_LENGTH);
        //cmd_history[0]='1';
        //printf("history ptr %d\r\n",(int) &((cmd_history)[0]));
        //printf("history ptr %d\r\n",(int) &((cmd_history)[32]));
        //printf("history ptr %d\r\n",(int) ((cmd_history)[1]));
    }

	char in_char;
	char out_char[2];
	out_char[1] = '\0';
	int length = 0;
	int cursor_loc = 0;

	//polling for user input
	while (1) {

		if (inb(COM1+5)&1) {
			//the character is read from the register
			in_char = inb(COM1);
			out_char[0] = in_char;

			if (in_char == BACKSPACE) {
				if (length != 0) {
                    if (cursor_loc == length)
                    {
                        cursor_loc--;
                        in_string[cursor_loc] = '\0';
                        clear_buff();
                        serial_print(in_string);
                        length--;
                        return_cursor(cursor_loc, length);

                    }
                    else
                    {
                        cursor_loc--;
                        strcpy(&in_string[cursor_loc], &in_string[cursor_loc + 1]);
                        in_string[length - 1] = '\0';
                        clear_buff();
                        serial_print(in_string);
                        length--;
                        return_cursor(cursor_loc, length);
                    }
				}
			} else if (in_char == DELETE) {
            } else if (in_char == RETURN || in_char == NEW_LINE) {
                cmd_history_length++;
                if(cmd_history_length>10)
                {
                    cmd_history_length=10;
                }
                //printf("length %d :: cur cmd %d\r\n", cmd_history_length, current_recalled_cmd);
                //printf("cmd write num %d\r\n",(cmd_write_num%10));
                strcpy(&(cmd_history[(cmd_write_num%10)*MAX_LENGTH]), &(in_string[0]));
                current_recalled_cmd=0;
                cmd_write_num++;
				return in_string;
			} else if (in_char == ESC) {
				//buffer through ansi escape keys ([)
				in_char = inb(COM1);
				in_char = inb(COM1);

                if (in_char == 'B') {			//Down
                    //printf("\r\nlength %d :: cur cmd %d\r\n", cmd_history_length, current_recalled_cmd);
                    //printf("cmd write num %d\r\n",(cmd_write_num%10));
                    current_recalled_cmd++;
                    if(current_recalled_cmd>cmd_history_length-1)
                    {
                        current_recalled_cmd=0;
                    }
                    clear_buff();
                    memset(&(in_string[0]),0, MAX_LENGTH);
                    strcpy(&(in_string[0]),&(cmd_history[(current_recalled_cmd)*MAX_LENGTH]));
                    serial_print(&(in_string[0]));
                    length=cursor_loc = strlen(&(in_string[0]));
					//go backwards in command history
                } else if (in_char == 'A') {	//Up
                    //printf("\r\nlength %d :: cur cmd %d\r\n", cmd_history_length, current_recalled_cmd);
                    //printf("cmd write num %d\r\n",(cmd_write_num%10));
                    current_recalled_cmd--;
                    if(current_recalled_cmd<0)
                    {
                        current_recalled_cmd=(cmd_history_length>0)?cmd_history_length-1:0;
                    }
                    clear_buff();
                    memset(&(in_string[0]),0, MAX_LENGTH);
                    strcpy(&(in_string[0]),&(cmd_history[(current_recalled_cmd)*MAX_LENGTH]));
                    serial_print(&(in_string[0]));
                    length=cursor_loc = strlen(&(in_string[0]));
					//go forward in command history
				} else if (in_char == 'C') {	//RIGHT
                    if (cursor_loc < length) {
                        serial_print("\033[C");	
                        cursor_loc++;
                    }
				} else if (in_char == 'D') {	//LEFT
                    if (cursor_loc > 0) {
                        serial_print("\033[D");
                        cursor_loc--;
                    }   
				} else if (in_char == '3') {  //DEL
                    strcpy(&in_string[cursor_loc], &in_string[cursor_loc + 1]);
                    in_string[length] = '\0';
                    clear_buff();
                    serial_print(in_string);
                    length--;
                    return_cursor(cursor_loc, length);
				}

			} else {
				if (length < MAX_LENGTH - 1) {
                    if (length == cursor_loc) {
                        in_string[length] = in_char;
                        in_string[length + 1] = '\0';
                        serial_print(out_char);
                        cursor_loc++;
                        length++;
                    }
                    else {
                        int i = length;
                        in_string[length+1] = '\0';
                        for (; i >= cursor_loc; i--) {
                            in_string[i + 1] = in_string[i]; 
                        }
                        in_string[cursor_loc] = in_char;
                        length++;
                        cursor_loc++;
                        clear_buff();
                        serial_print(in_string);
                        return_cursor(cursor_loc, length);
                    }
                }
			}
		}
	}
	return in_string;
}
