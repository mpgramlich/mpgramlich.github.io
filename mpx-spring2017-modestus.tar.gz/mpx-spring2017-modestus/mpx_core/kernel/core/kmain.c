/*
  ----- kmain.c -----

  Description..: Kernel main. The first function called after
      the bootloader. Initialization of hardware, system
      structures, devices, and initial processes happens here.
*/

#include <stdint.h>
#include <string.h>
#include <system.h>
#include <core/rtc.h>

#include <core/io.h>
#include <core/serial.h>
#include <core/tables.h>
#include <core/interrupts.h>
#include <core/anim.h>
#include <mem/heap.h>
#include <mem/paging.h>
#include <core/commhand.h>
#include <input.h>

#include <core/pcb.h>
#include <core/mcb.h>

#include "linked_list.h"

#include "core/mpx_supt.h"

void kmain(void)
{
   extern uint32_t magic;
   // Uncomment if you want to access the multiboot header
   // extern void *mbd;
   // char *boot_loader_name = (char*)((long*)mbd)[16];

   // 0) Initialize Serial I/O and call mpx_init
   klogv("Starting MPX boot sequence...");
   klogv("Initialized serial I/O on COM1 device...");

// nick was here 1/19/17 and added more text
//Gio was also here on 1/20/2017

   //Added: matt-g 1/17/17
   set_serial_out(COM1);
   set_serial_in(COM1);

    start_up_anim();

   //added matt-g 1/25/17
//    char buf[500];
//   char *testarr = (char*)buf;
/*
   const char* toCpy = "testetst";
   testarr=strcat(testarr,toCpy);
   printf("-%s-%s %s %d %s %c %s","testtest","matt","jesse",-938,"gio",'l',"nick");
   printf("atoi test: %d\r\n", atoi("12 4"));
   //klogv(testarr);

   int seconds = 30, minutes=49, hours=5;
   get_time(&hours,&minutes,&seconds);
   sprintf(&testarr[0], 500, "Hours %d, Minutes %d, Seconds %d", hours, minutes, seconds);
   klogv(testarr);

   int day=25, month=12, year=2016;
   get_date(&day, &month, &year);
   sprintf(&testarr[0], 500, "Day %d, Month %d, Year %d", day, month, year);
   klogv(testarr);
*/
   // 1) Check that the boot was successful and correct when using grub
   // Comment this when booting the kernel directly using QEMU, etc.
   if ( magic != 0x2BADB002 ){
     //kpanic("Boot was not error free. Halting.");
   }



   // 2) Descriptor Tables
   klogv("Initializing Global descriptor table...");
   init_gdt(); //Added: matt-g 17/1/18

   klogv("Initializing Interrupt Descriptor table..");
   init_idt();

   klogv("Initializing Programmable interrupt controller");
   init_pic();

   sys_set_free(&freeHeapMem);
   sys_set_malloc(&allocateMemFromHeap);
   initHeap(50000); //init heap
   //heapTest();

   klogv("Installing interrupts...");
   init_irq();

   klogv("Enabling interrupts.");
   cli();

   // 4) Virtual Memory
   klogv("Initializing virtual memory...");
   init_paging();

   klogv("Initializing PCB Memory");
   initPCBQueues();

   // 5) Call Commhand
   klogv("Transferring control to commhand...");
   //listTest();

   //printf("%s%s","\r\n","\r\n");

   //pcbTest();

   pcb_t* newPCB = setupPCB("Commhand", SYSTEM, 9);
   processContext_t * cp = ( newPCB->context );
   memset ( cp , 0, sizeof ( processContext_t ));
   cp->fs = 0x10 ;
   cp->gs = 0x10 ;
   cp->ds = 0x10 ;
   cp->es = 0x10 ;
   cp->cs = 0x8 ;
   cp->ebp = ( u32int )( newPCB->stackBase );
   cp->esp = ( u32int )( newPCB->stackTop );
   cp->eip = ( u32int ) &init_commhand;
   cp->eflags = 0x202 ;
   cp->argc = 5;
   cp->argv = (char**)0xDEADDEAD;

   changeProcessSuspensionState("Commhand", NOT_SUSPENDED);

   newPCB = setupPCB("IDLE", SYSTEM, 0);
   cp = ( newPCB->context );
   memset ( cp , 0, sizeof ( processContext_t ));
   cp->fs = 0x10 ;
   cp->gs = 0x10 ;
   cp->ds = 0x10 ;
   cp->es = 0x10 ;
   cp->cs = 0x8 ;
   cp->ebp = ( u32int )( newPCB->stackBase );
   cp->eip = ( u32int ) &idle;
   cp->eflags = 0x202 ;

   changeProcessSuspensionState("IDLE", NOT_SUSPENDED);

   sys_req(IDLE);

   // 11) System Shutdown
   klogv("Starting system shutdown procedure...");

   /* Shutdown Procedure */
   klogv("Shutdown complete. You may now turn off the machine. (QEMU: C-a x)");
   hlt();
}
