#include <core/pcb.h>


linkedList_t readyQueue;
linkedList_t blockedQueue;
linkedList_t suspendedReadyQueue;
linkedList_t suspendedBlockedQueue;


pcb_t* currentOperatingProcess = 0;



e_PCB_ERROR_CODE_t prevPCBError;

pcb_t* allocatePCB(void)
{
#ifndef LL_IS_ARRAY_BACKED
    prevPCBError=SUCCESS;

    pcb_t* temp = (pcb_t*)sys_alloc_mem(sizeof(pcb_t));
    temp->representingNode = makeNewNode(0, (void*)temp);

    if(!temp || !temp->representingNode) { prevPCBError = ERROR_ALLOCATING_NODE; return 0; }

    return temp;
#endif
}

/**
 * @todo line 45 needs to call linkedList_t node free functions
 */
e_PCB_ERROR_CODE_t freePCB(pcb_t* pcbToFree)
{
    prevPCBError=SUCCESS;
    if(pcbToFree)
    {
        prevPCBError = removePCB(pcbToFree);
        if(prevPCBError != SUCCESS)
        {
            return prevPCBError = ERROR_REMOVING_PCB;
        }
        if(pcbToFree->representingNode)
        {

            prevPCBError = sys_free_mem(pcbToFree->representingNode);
            if(prevPCBError != SUCCESS)
            {
                return prevPCBError = ERROR_FREEING_NODE;
            }
        }

        //due to the way the stack is allocated, this is no longer needed as the stack is allocated
            //as part of the pcb structure itself.
        //We only need to free the PCB after this.
//        if(pcbToFree->stackBase)
//        {
//            prevPCBError = sys_free_mem(pcbToFree->stack);
//            if(prevPCBError != SUCCESS)
//            {
//                return prevPCBError = ERROR_FREEING_STACK;
//            }
//        }

        prevPCBError = sys_free_mem(pcbToFree);
    }

    if(prevPCBError != SUCCESS)
    {
        return prevPCBError = ERROR_FREEING_PCB;
    }

    return prevPCBError = SUCCESS;
}

pcb_t* setupPCB(const char* processName, e_PROCESS_CLASS_t processClass, processPriority_t processPriority)
{
    prevPCBError=SUCCESS;
    int lengthOfName = strlen(processName);
    if(lengthOfName >= PROCESS_MAX_NAME_LENGTH || lengthOfName <= 0 ) { prevPCBError = ERROR_NAME_INVALID; return 0; }
    if(processPriority > 9) { prevPCBError = ERROR_PRIORITY_INVALID; return 0; }
    if((processClass != SYSTEM) && (processClass != USER_APP)) { prevPCBError = ERROR_CLASS_INVALID; return 0; }

    pcb_t* newPCB = findPCB(processName);
    if(newPCB){ prevPCBError = ERROR_NAME_COLLISION; return 0; }

    newPCB = allocatePCB();

    if(!newPCB) { prevPCBError = ERROR_ALLOCATING_NODE; return 0; }

    strcpy(newPCB->name, processName);
    newPCB->processClass = processClass;
    newPCB->priority = processPriority;
    newPCB->processState = READY;
    newPCB->processSuspensionState = SUSPENDED;
    newPCB->stackBase= &newPCB->stack[0];
    newPCB->stackTop = newPCB->stackBase+PROCESS_STACK_SIZE-sizeof(processContext_t);
    newPCB->context = (processContext_t*)newPCB->stackTop;

    insertPCB(newPCB);

    return newPCB;
}

pcb_t* findPCB(const char* processName)
{
    prevPCBError=SUCCESS;
    node_t* temp;
    temp = searchList(&readyQueue,(void*) processName);
    if(temp)
    {
        return (pcb_t*)(temp->data);
    }

    temp = searchList(&blockedQueue,(void*) processName);
    if(temp)
    {
        return (pcb_t*)(temp->data);
    }

    temp = searchList(&suspendedReadyQueue,(void*) processName);
    if(temp)
    {
        return (pcb_t*)(temp->data);
    }

    temp = searchList(&suspendedBlockedQueue,(void*) processName);
    if(temp)
    {
        return (pcb_t*)(temp->data);
    }

    prevPCBError=ERROR_PCB_NOT_FOUND;
    return 0;
}

void insertPCB(pcb_t* pcbToInsert)
{
    prevPCBError=SUCCESS;
    if((pcbToInsert->processState == READY) &&
            (pcbToInsert->processSuspensionState == NOT_SUSPENDED))
    {
        (void)insertNode(&readyQueue,pcbToInsert->representingNode);
        return;
    }
    if((pcbToInsert->processState == BLOCKED) &&
            (pcbToInsert->processSuspensionState == NOT_SUSPENDED))
    {
        (void)insertNode(&blockedQueue,pcbToInsert->representingNode);
        return;
    }
    if((pcbToInsert->processState == READY) &&
            (pcbToInsert->processSuspensionState == SUSPENDED))
    {
        (void)insertNode(&suspendedReadyQueue,pcbToInsert->representingNode);
        return;
    }
    if((pcbToInsert->processState == BLOCKED) &&
            (pcbToInsert->processSuspensionState == SUSPENDED))
    {
        (void)insertNode(&suspendedBlockedQueue,pcbToInsert->representingNode);
        return;
    }
    prevPCBError=ERROR_INSERTING_PCB;
}

e_PCB_ERROR_CODE_t removePCB(pcb_t* pcbToRemove)
{
    (void)removeNode(pcbToRemove->representingNode);
    return prevPCBError=SUCCESS;
}

e_PCB_ERROR_CODE_t changeProcessState(const char* processName, e_PROCESS_STATE_t newState)
{
    prevPCBError=SUCCESS;

    if (newState != INITIAL && newState != READY && newState != RUNNING &&
            newState != BLOCKED && newState != TERMINAL)
    {
        prevPCBError=ERROR_STATE_INVALID;
        return ERROR_STATE_INVALID;
    }

    pcb_t* process = findPCB(processName);
    if (!process) return ERROR_PCB_NOT_FOUND;

    process->processState = newState;

    removePCB(process);
    insertPCB(process);

    return prevPCBError;
}

e_PCB_ERROR_CODE_t changeProcessSuspensionState(const char* processName, e_PROCESS_SUSPENSION_STATE_t suspensionState)
{
    prevPCBError=SUCCESS;
    if((suspensionState != SUSPENDED) &&
            (suspensionState != NOT_SUSPENDED))
    {
        return prevPCBError=ERROR_STATE_INVALID;
    }

    pcb_t* process = findPCB(processName);
    if(!process){ return prevPCBError = ERROR_PCB_NOT_FOUND; }

    process->processSuspensionState = suspensionState;

    removePCB(process);
    insertPCB(process);

    return prevPCBError;
}

e_PROCESS_STATE_t getState(const char* name)
{
    prevPCBError=SUCCESS;
    pcb_t* process = findPCB(name);
    return process->processState;
}

int fifoInsertFunc(void* pcb1, void* pcb2)
{
    (void)pcb1; (void)pcb2;
    return -1;
}

int priorityInsertFunc(void* pcb1, void* pcb2)
{
    return ((pcb_t*)pcb2)->priority - ((pcb_t*)pcb1)->priority;
}

int pcbSearchFunc(void* pcb,  void* nameToFind)
{
    return strcmp(((pcb_t*)pcb)->name, (char*)nameToFind);
}

void initPCBQueues(void)
{
    initLinkedList(&readyQueue);
    initLinkedList(&blockedQueue);
    initLinkedList(&suspendedReadyQueue);
    initLinkedList(&suspendedBlockedQueue);

    setSearchComparisonFunction(&readyQueue, &pcbSearchFunc);
    setSearchComparisonFunction(&blockedQueue, &pcbSearchFunc);
    setSearchComparisonFunction(&suspendedReadyQueue, &pcbSearchFunc);
    setSearchComparisonFunction(&suspendedBlockedQueue, &pcbSearchFunc);

    setPrintFunction(&readyQueue, &printPCBFunc);
    setPrintFunction(&blockedQueue, &printPCBFunc);
    setPrintFunction(&suspendedReadyQueue, &printPCBFunc);
    setPrintFunction(&suspendedBlockedQueue, &printPCBFunc);

//    setInsertComparisonFunction(&readyQueue, &priorityInsertFunc);
}

void pcbTest(void)
{
    printf("%s","PCB Queue Test\r\n\r\n");
    int i;
    for( i = 0; i < 30; i++)
    {
        char name[20];
        sprintf(name, 20, "Proc %d", i);
        setupPCB(name, SYSTEM, i/3);
    }
    printf("Ready Queue Contents%s","\r\n");
    printList(&readyQueue);
}

const char* errorToString(e_PCB_ERROR_CODE_t error)
{
    switch(error)
    {
        case SUCCESS: return "Success";
        case ERROR: return "Error";
        case ERROR_PCB_NOT_FOUND: return "Error: PCB not found";
        case ERROR_NAME_INVALID: return "Error: name invalid";
        case ERROR_PRIORITY_INVALID: return "Error: priority invalid";
        case ERROR_FREEING_NODE: return "Error freeing node";
        case ERROR_FREEING_STACK: return "Error freeing stack";
        case ERROR_FREEING_PCB: return "Error freeing PCB";
        case ERROR_REMOVING_PCB: return "Error removing PCB";
        case ERROR_STATE_INVALID: return "Error: State Invalid";
        case ERROR_CLASS_INVALID: return "Error: Class Invalid";
        case ERROR_ALLOCATING_NODE: return "Error Allocating Node";
        case ERROR_NAME_COLLISION: return "Error: PCB Name Already in Use";
        case ERROR_INSERTING_PCB: return "Error: PCB States have resulted in invalid transition";
        default: return "Error parsing error code";
    }
}

const char* classToString(e_PROCESS_CLASS_t processClass)
{
    switch(processClass)
    {
        case SYSTEM: return "System";
        case USER_APP: return "User-App";
        case CLASS_UNKNOWN: return "Class Unknown";
        default: return "Error parsing class code";
    }
    return "Error parsing class code";
}

const char* stateToString(e_PROCESS_STATE_t state)
{
    switch(state)
    {
        case INITIAL: return "Initial";
        case READY: return "Ready";
        case RUNNING: return "Running";
        case BLOCKED: return "Blocked";
        //case SUSPENDED_READY: return "Suspended-ready";
        //case SUSPENDED_BLOCKED: return "Suspened-blocked";
        case TERMINAL: return "Terminal";
        case STATE_UNKNOWN: return "State unknown";
        default: return "Error parsing state code";
    }
}

const char* suspensionToString(e_PROCESS_SUSPENSION_STATE_t state)
{
    switch(state)
    {
        case SUSPENDED: return "Suspended";
        case NOT_SUSPENDED: return "Not-Suspended";
        default:
        case SUSPENSION_UNKNOWN: return "Suspension-State-Unknown";
    }
}

e_PROCESS_CLASS_t stringToClass(const char * stringifiedClass)
{
    if(!strcmp("System", stringifiedClass)){ return SYSTEM; }
    if(!strcmp("User-App", stringifiedClass)){ return USER_APP; }
    return CLASS_UNKNOWN;
}

void printPCBFunc(void* pcb)
{
    printf("PCB: %s | Priority: %d | Class: %s | State: %s | Suspension Status: %s\r\n",
              ((pcb_t*)pcb)->name, ((pcb_t*)pcb)->priority, classToString(((pcb_t*)pcb)->processClass),
              stateToString(((pcb_t*)pcb)->processState), suspensionToString(((pcb_t*)pcb)->processSuspensionState));
}

e_PCB_ERROR_CODE_t changeProcessPriority(const char * procName, processPriority_t newPriority)
{
    prevPCBError=SUCCESS;
    if(newPriority > PROCESS_HIGHEST_PRIORITY)
    {
        return ERROR_PRIORITY_INVALID;
    }
    pcb_t* foundProcess = findPCB(procName);
    if(!foundProcess)
    {
        return ERROR_PCB_NOT_FOUND;
    }

    foundProcess->priority = newPriority;
    return SUCCESS;
}

e_PCB_ERROR_CODE_t resumeAll()
{
    if(suspendedReadyQueue.head.next != &(suspendedReadyQueue.tail))
    {
        node_t* itNode = (suspendedReadyQueue.head.next);
        while(itNode != &(suspendedReadyQueue.tail))
        {
            changeProcessSuspensionState(((pcb_t *)itNode->data)->name, NOT_SUSPENDED);
            itNode = (suspendedReadyQueue.head.next);
        }
    }

    if(suspendedBlockedQueue.head.next != &(suspendedBlockedQueue.tail))
    {
        node_t* itNode = (suspendedBlockedQueue.head.next);
        while(itNode != &(suspendedBlockedQueue.tail))
        {
            changeProcessSuspensionState(((pcb_t *)itNode->data)->name, NOT_SUSPENDED);
            itNode = (suspendedBlockedQueue.head.next);
        }
    }

    return SUCCESS;
}
