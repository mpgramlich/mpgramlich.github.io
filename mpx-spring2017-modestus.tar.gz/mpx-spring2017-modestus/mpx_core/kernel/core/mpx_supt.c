#include <core/mpx_supt.h>
#include <mem/heap.h>

#include <core/pcb.h>

param params;
int current_module = MODULE_R5;
void* (*student_malloc)(size_t);
int (*student_free)(void *);

int sys_req( int  op_code )
{
  params.op_code = op_code;
  asm volatile ("int $60");
  return 0;
}

void mpx_init(int cur_mod)
{
  current_module = cur_mod;
}

void sys_set_malloc(void* (*func)(size_t))
{
  student_malloc = func;
}

void sys_set_free(int (*func)(void *))
{
  student_free = func;
}

void *sys_alloc_mem(u32int size)
{
  if (current_module < MODULE_R5)
    return (void *) kmalloc(size);
  else
    return (void *) (*student_malloc)(size);
}

int sys_free_mem(void *ptr)
{
  if (current_module >= MODULE_R5)
    return (*student_free)(ptr);
  // otherwise we don't free anything
  return -1;
}

void idle()
{
  serial_println("\r\n\033[38;2;255;0;255mIn Idle Process\033[38;2;255;255;255m\r\n");
  do {
    sys_req(IDLE);
    serial_println("\r\n\033[38;2;255;0;255mIn Idle Process\033[38;2;255;255;255m\r\n");
  }while(readyQueue.head.next != &(readyQueue.tail));
  serial_println("No More ready processes, IDLE is exiting");
  sys_req(EXIT);
}

processContext_t* callerContext;

uint32_t* sys_call(processContext_t* context)
{
    if(currentOperatingProcess)
    {
        if(params.op_code == IDLE)
        {
            currentOperatingProcess->stackTop = (processStack_t*)context;
            currentOperatingProcess->processState = READY;
            insertPCB(currentOperatingProcess);
        }
        else if(params.op_code == EXIT)
        {
            freePCB(currentOperatingProcess);
        }
    }
    else
    {
        callerContext = context;
    }
    if(readyQueue.head.next != &readyQueue.tail)
    {
        if(removePCB(currentOperatingProcess = (pcb_t*)readyQueue.head.next->data) == SUCCESS)
        {
            currentOperatingProcess->processState = RUNNING;
            return (uint32_t*)currentOperatingProcess->stackTop;
        }
        else
        {
            kpanic("Could Not remove COP from ready Queue!!!!!");
        }
    }

    return (uint32_t*)callerContext;

}

