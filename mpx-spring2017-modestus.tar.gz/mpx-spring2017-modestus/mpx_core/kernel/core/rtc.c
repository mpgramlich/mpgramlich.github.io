#include <core/rtc.h>
#include <string.h>
/**
 * @brief get_time this function will retrieve the system time and place it in three pointers
 *
 * @param hours pointer to int where the current hours will be stored, in UTC timezone
 * @param minutes pointer to int where the current minutes will be stored, in UTC timezone
 * @param seconds pointer to int where the current seconds will be stored, in UTC timezone
 */
void get_time(int *hours, int *minutes, int *seconds)
{
    char temp = 0;
    outb(RTC_INDEX_REG, SECONDS_INDEX);
    temp = inb(0x71);
    *seconds = ((temp & 0xf0) >>4 ) *10 + (temp & 0x0f);

    outb(RTC_INDEX_REG, MINUTES_INDEX);
    temp = inb(0x71);
    *minutes = ((temp & 0xf0) >>4 ) *10 + (temp & 0x0f);

    outb(RTC_INDEX_REG, HOURS_INDEX);
    temp = inb(0x71);
    *hours = ((temp & 0xf0) >>4 ) *10 + (temp & 0x0f);
}

/**
 * @brief set_time sets the RTC time
 *
 * @param hours the hours to set the clock to, must be less than 24. In UTC Time zone
 * @param minutes the minutes to set the clock to, must be less than 60. In UTC Time zone
 * @param seconds the seconds to set the clock to, must be less than 60. In UTC Time zone
 */
void set_time(int hours, int minutes, int seconds)
{
    sti();

    outb(RTC_INDEX_REG, HOURS_INDEX);
    outb(RTC_DATA_REG, ((hours/10)<<4)|(hours%10) );

    outb(RTC_INDEX_REG, MINUTES_INDEX);
    outb(RTC_DATA_REG, ((minutes/10)<<4)|(minutes%10) );

    outb(RTC_INDEX_REG, SECONDS_INDEX);
    outb(RTC_DATA_REG, ((seconds/10)<<4)|(seconds%10) );

    cli();
}

/**
 * @brief get_date this function will retrieve the system date and place in three pointers
 *
 * @param day pointer to int where the current day will be stored, UTC Time zone
 * @param months pointer to int where the current month will be stored, UTC Time zone
 * @param year pointer to int where the current year will be stored, UTC Time zone
 */
void get_date(int *day, int *month, int *year)
{
    char temp = 0;
    outb(RTC_INDEX_REG, DAY_OF_MONTH_INDEX);
    temp = inb(0x71);
    *day = ((temp & 0xf0) >>4 ) *10 + (temp & 0x0f);

    outb(RTC_INDEX_REG, MONTHS_INDEX);
    temp = inb(0x71);
    *month = ((temp & 0xf0) >>4 ) *10 + (temp & 0x0f);

    outb(RTC_INDEX_REG, YEAR_INDEX);
    temp = inb(0x71);
    *year = ((temp & 0xf0) >>4 ) *10 + (temp & 0x0f);
}

/**
 * @brief set_date sets the RTC Date
 *
 * @param day the day to set the clock to, must be valid for the month. UTC Time zone
 * @param month the month to set the clock to, must be between 1 and 12. UTC Time zone
 * @param year the year to set the clock to, must be less than 100. UTC Time zone
 */
void set_date(int day, int month, int year)
{
    sti();

    outb(RTC_INDEX_REG, DAY_OF_MONTH_INDEX);
    outb(RTC_DATA_REG, ((day/10)<<4)|(day%10));

    outb(RTC_INDEX_REG, MONTHS_INDEX);
    outb(RTC_DATA_REG, ((month/10)<<4)|(month%10));

    outb(RTC_INDEX_REG, YEAR_INDEX);
    outb(RTC_DATA_REG, (((year-(year/100)*100)/10)<<4)|(year%10) );

    cli();
}
