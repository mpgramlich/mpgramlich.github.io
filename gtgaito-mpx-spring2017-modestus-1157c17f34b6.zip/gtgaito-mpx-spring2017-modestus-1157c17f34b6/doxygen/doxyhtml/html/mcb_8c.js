var mcb_8c =
[
    [ "allocateMemFromHeap", "mcb_8c.html#a412b26c7cd2c5efa5719033127a6739c", null ],
    [ "freeHeapMem", "mcb_8c.html#aa8ff93b65e4b87079d5caf9a18fa44cf", null ],
    [ "heapIsEmpty", "mcb_8c.html#a4cbe2179547680c3ae8f25b9072a5767", null ],
    [ "heapTest", "mcb_8c.html#a8d44e2debd148ff03704bed92efc125e", null ],
    [ "initHeap", "mcb_8c.html#a6275bd66bccbbffefa8f6c91c24df9ea", null ],
    [ "insertMCBIntoList", "mcb_8c.html#a47ac2541ccbd4c86d798151db18e8650", null ],
    [ "mcbCompareFunc", "mcb_8c.html#a3787d9bf7e898293660a0262e893f6f6", null ],
    [ "mcbResultToString", "mcb_8c.html#ab1309252bf7e45ff96fb96bfaf65c422", null ],
    [ "mcbSearchCompFunc", "mcb_8c.html#a75301f49a2955a7ec8799b27969825fe", null ],
    [ "mcbTypeToString", "mcb_8c.html#a06e5bcedb3a84daf356222bffedb1b42", null ],
    [ "printAlloc", "mcb_8c.html#a12da637dd5dc965519912671e44128f2", null ],
    [ "printFree", "mcb_8c.html#ad0bd4172a6d8d4e63f231ac91ed15d6d", null ],
    [ "printMCBFunc", "mcb_8c.html#a5247fdfaa4c56cc0028167a495f36e20", null ],
    [ "reclaimFreeMem", "mcb_8c.html#ac69c3ad25fcff74b9230bf7391c5a1f1", null ],
    [ "heapLoc", "mcb_8c.html#aa5d00c7627e28a8de2f666cbb96a14e7", null ],
    [ "lastMCBError", "mcb_8c.html#ae567d529759c33fd482f6c50d1477540", null ],
    [ "mcbAllocList", "mcb_8c.html#a644924686a50359017d53fbf6786cc7f", null ],
    [ "mcbFreeList", "mcb_8c.html#ac7f1b247ae17641b38fbfb74c91bc161", null ]
];