var kernel_2core_2mpx__supt_8c =
[
    [ "idle", "kernel_2core_2mpx__supt_8c.html#a83abbeda22fc5e6c2b35523b64199c1c", null ],
    [ "mpx_init", "kernel_2core_2mpx__supt_8c.html#a53332c6a3107a4feed6e2e79690a6ffa", null ],
    [ "sys_alloc_mem", "kernel_2core_2mpx__supt_8c.html#a61adad2abba0a3a225c2290b3de1fe93", null ],
    [ "sys_free_mem", "kernel_2core_2mpx__supt_8c.html#a950663d39dbb073c9dff9cf3b5d3392c", null ],
    [ "sys_req", "kernel_2core_2mpx__supt_8c.html#afb6ff5e2e9bdde9d8971a497b6fe38ae", null ],
    [ "sys_set_free", "kernel_2core_2mpx__supt_8c.html#a2463d934fa39601c275a3ade8afd18bc", null ],
    [ "sys_set_malloc", "kernel_2core_2mpx__supt_8c.html#a4a28bb188c9fed51228c46980b20e605", null ],
    [ "current_module", "kernel_2core_2mpx__supt_8c.html#a3d19c725b7f9f45e9da97a79ca6a4737", null ],
    [ "params", "kernel_2core_2mpx__supt_8c.html#a3b4b77494d0fad58939896ddc5290c99", null ],
    [ "student_free", "kernel_2core_2mpx__supt_8c.html#a19c47c02b0338bc13716d98305bb8a34", null ],
    [ "student_malloc", "kernel_2core_2mpx__supt_8c.html#a421e2b48efb5facc71d16979252710e2", null ]
];