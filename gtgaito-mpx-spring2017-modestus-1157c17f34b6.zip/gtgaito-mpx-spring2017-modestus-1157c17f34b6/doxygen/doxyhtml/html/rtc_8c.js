var rtc_8c =
[
    [ "get_date", "rtc_8c.html#ab43f56447c49f42bb4baee3e59e2d1f9", null ],
    [ "get_time", "rtc_8c.html#a35fa24488cb7eb077e8dc995729202cf", null ],
    [ "set_date", "rtc_8c.html#a7903b907981d739e3d156a964255d45e", null ],
    [ "set_time", "rtc_8c.html#a9f75815e4f89e0ff7065999f43867e92", null ]
];