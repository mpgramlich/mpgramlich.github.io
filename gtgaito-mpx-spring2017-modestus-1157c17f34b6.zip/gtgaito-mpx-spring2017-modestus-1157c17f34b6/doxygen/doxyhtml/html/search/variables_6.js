var searchData=
[
  ['fat_5ftype',['fat_type',['../structs___f_a_t12_infos.html#a77f0c020c8462eea6229f311d8912156',1,'s_FAT12Infos::fat_type()'],['../read_img_8c.html#ac9438a2e250552068dd9fff4e20544ed',1,'fat_type():&#160;readImg.c']]],
  ['fatarr',['FATArr',['../read_img_8c.html#a7276c4cd115db437c1e695c92d9d66c6',1,'readImg.c']]],
  ['file_5fname',['file_name',['../structs___entry_info.html#a8953a44b4421cb06f524ff3fabc1d353',1,'s_EntryInfo::file_name()'],['../read_img_8c.html#a156eba93a165a5801670e8c0af37a6f6',1,'file_name():&#160;readImg.c']]],
  ['file_5fsize',['file_size',['../structs___entry_info.html#a8f6a493e1369411f3062a95431e59f7c',1,'s_EntryInfo::file_size()'],['../read_img_8c.html#acfc905fb689f590842c0152e3b8cd92e',1,'file_size():&#160;readImg.c']]],
  ['first_5flogical_5fcluster',['first_logical_cluster',['../structs___entry_info.html#aa0983a044be25786e994342b4074fb6a',1,'s_EntryInfo::first_logical_cluster()'],['../read_img_8c.html#aa5a18a5179d69e23b741050814881fa8',1,'first_logical_cluster():&#160;readImg.c']]],
  ['flags',['flags',['../structidt__entry__struct.html#a46c92bd8f07d5ff4e379a07b293c46af',1,'idt_entry_struct::flags()'],['../structgdt__entry__struct.html#afac75bdf53080168c8899c442862410a',1,'gdt_entry_struct::flags()'],['../tables_8h.html#a138dda98fcd4738346af61bcca8cf4b4',1,'flags():&#160;tables.h']]],
  ['frameaddr',['frameaddr',['../structpage__entry.html#a68a6dc54a7ab6f7fb1a068476190bf67',1,'page_entry']]],
  ['frames',['frames',['../paging_8c.html#a76492529572a1a20a06076ac40d66b29',1,'paging.c']]],
  ['freenodefunc',['freeNodeFunc',['../structs__ll.html#a6919b06690819c763c63053568542925',1,'s_ll']]],
  ['fs',['fs',['../structs__process_context.html#adb54401e624822659c9125b599257aa9',1,'s_processContext::fs()'],['../system_8h.html#a59556586c5fc48990f50150d95a0735d',1,'fs():&#160;system.h']]]
];
