var searchData=
[
  ['zero',['zero',['../structidt__entry__struct.html#a0d33c8509ae77d42e680d8d11b4c8035',1,'idt_entry_struct::zero()'],['../tables_8h.html#a94515e42687e7508877c09da81f86860',1,'zero():&#160;tables.h']]]
];
