var searchData=
[
  ['node_5ft',['node_t',['../linked__list_8h.html#a694e38fba2953567dfe172fae36ca04e',1,'linked_list.h']]]
];
