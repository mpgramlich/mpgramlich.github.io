var searchData=
[
  ['variable_5fll_5flength',['VARIABLE_LL_LENGTH',['../linked__list_8h.html#a33fa4884df656ed557638b8bd9585a7e',1,'linked_list.h']]],
  ['version',['version',['../comm__list_8c.html#ab21bb30658e69c3d4906e435384fa5fd',1,'version(char parameters[][MAX_LENGTH]):&#160;comm_list.c'],['../comm__list_8h.html#ab21bb30658e69c3d4906e435384fa5fd',1,'version(char parameters[][MAX_LENGTH]):&#160;comm_list.c'],['../comm__vars_8h.html#a1c6d5de492ac61ad29aec7aa9a436bbf',1,'VERSION():&#160;comm_vars.h']]],
  ['volatile',['volatile',['../system_8h.html#af55a5e48555be7d32ad73e76cf5d4db0',1,'system.h']]],
  ['volume_5fid',['volume_id',['../structs___f_a_t12_infos.html#aebd86e32089df7736b5e22625a6efdaa',1,'s_FAT12Infos::volume_id()'],['../read_img_8c.html#a77a2cd2807c348ae913c256e41533320',1,'volume_id():&#160;readImg.c']]],
  ['volume_5flabel',['volume_label',['../structs___f_a_t12_infos.html#a7f033f386d2141afa39d7a847728b834',1,'s_FAT12Infos::volume_label()'],['../read_img_8c.html#a92fb13163216985d3e94841aa629f8b1',1,'volume_label():&#160;readImg.c']]]
];
