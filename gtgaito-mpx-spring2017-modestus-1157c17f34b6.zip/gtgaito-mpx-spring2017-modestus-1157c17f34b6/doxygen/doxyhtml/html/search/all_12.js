var searchData=
[
  ['table',['table',['../structindex__table.html#ae69e0312bad59289ac303989d06c565d',1,'index_table']]],
  ['table_5fsize',['TABLE_SIZE',['../heap_8h.html#a032503e76d6f69bc67e99e909c8125da',1,'heap.h']]],
  ['tables',['tables',['../structpage__dir.html#ac89434e3fccabfe9481ea77fdda82faf',1,'page_dir']]],
  ['tables_2ec',['tables.c',['../tables_8c.html',1,'']]],
  ['tables_2eh',['tables.h',['../tables_8h.html',1,'']]],
  ['tables_5fphys',['tables_phys',['../structpage__dir.html#a7336b695acaf516613dda626129129d0',1,'page_dir']]],
  ['tail',['tail',['../structs__ll.html#aa67db65bfe5ef66c7dbf31f84f4b56f9',1,'s_ll']]],
  ['terminal',['TERMINAL',['../pcb_8h.html#a8461d6c03c00b03bad59b5a29d27b902a9b2989c4ac8a0f9a7f46528384eaa5c7',1,'pcb.h']]],
  ['testprintfunc',['testPrintFunc',['../linked__list_8c.html#abce3e0a671a927747db173dea67b2afc',1,'linked_list.c']]],
  ['time',['time',['../comm__list_8c.html#a5dac732108bdce081376535bd2d51221',1,'time(char parameters[][MAX_LENGTH]):&#160;comm_list.c'],['../comm__list_8h.html#a5dac732108bdce081376535bd2d51221',1,'time(char parameters[][MAX_LENGTH]):&#160;comm_list.c']]],
  ['todo_20list',['Todo List',['../todo.html',1,'']]],
  ['total_5fnum_5fof_5fsectors_5fin_5ffile_5fsystem',['total_num_of_sectors_in_file_system',['../structs___f_a_t12_infos.html#a275c49f5db74083992ea1111f9a8e1c1',1,'s_FAT12Infos::total_num_of_sectors_in_file_system()'],['../read_img_8c.html#a15dad604b0d2d5fec3865778443736e1',1,'total_num_of_sectors_in_file_system():&#160;readImg.c']]],
  ['total_5fsector_5fcount_5ffor_5ffat32',['total_sector_count_for_fat32',['../structs___f_a_t12_infos.html#a8e149b45d2a3c06aec3113ac228038d7',1,'s_FAT12Infos::total_sector_count_for_fat32()'],['../read_img_8c.html#abe3130c6897e32840785f1dfa74f6568',1,'total_sector_count_for_fat32():&#160;readImg.c']]],
  ['trim',['trim',['../read_img_8c.html#a06798d058792d39a2eb6f3b784ae1532',1,'readImg.c']]],
  ['type',['type',['../read_img_8c.html#ab05e6469a31c2a5e14c76657fe3516e5',1,'readImg.c']]]
];
