var searchData=
[
  ['ready',['READY',['../pcb_8h.html#a8461d6c03c00b03bad59b5a29d27b902a6564f2f3e15be06b670547bbcaaf0798',1,'pcb.h']]],
  ['running',['RUNNING',['../pcb_8h.html#a8461d6c03c00b03bad59b5a29d27b902a1061be6c3fb88d32829cba6f6b2be304',1,'pcb.h']]]
];
