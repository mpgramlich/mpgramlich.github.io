var searchData=
[
  ['readfat',['readFAT',['../read_img_8c.html#a913041091c7e8a662d096781f8a507e0',1,'readImg.c']]],
  ['reclaimfreemem',['reclaimFreeMem',['../mcb_8h.html#ac69c3ad25fcff74b9230bf7391c5a1f1',1,'reclaimFreeMem():&#160;mcb.c'],['../mcb_8c.html#ac69c3ad25fcff74b9230bf7391c5a1f1',1,'reclaimFreeMem():&#160;mcb.c']]],
  ['removenode',['removeNode',['../linked__list_8h.html#ad225d0f3d9e1b59a58117ba0bc491189',1,'removeNode(node_t *nodeToRemove):&#160;linked_list.c'],['../linked__list_8c.html#ad225d0f3d9e1b59a58117ba0bc491189',1,'removeNode(node_t *nodeToRemove):&#160;linked_list.c']]],
  ['removepcb',['removePCB',['../pcb_8h.html#aa7ccac95996427cc60aaee4eec35caf4',1,'removePCB(pcb_t *pcbToRemove):&#160;pcb.c'],['../pcb_8c.html#aa7ccac95996427cc60aaee4eec35caf4',1,'removePCB(pcb_t *pcbToRemove):&#160;pcb.c']]],
  ['reserved',['reserved',['../interrupts_8c.html#ad686e3fee8ec8346a6d8e98d970a02dd',1,'interrupts.c']]],
  ['resumeall',['resumeAll',['../group___r3.html#gaff1bed6c354202b411b96fd97fafd7a5',1,'resumeAll():&#160;pcb.c'],['../group___r3.html#gaff1bed6c354202b411b96fd97fafd7a5',1,'resumeAll():&#160;pcb.c']]],
  ['resumepcb',['resumePCB',['../comm__list_8c.html#a672eae99ab4e3da15306bc6df644bb50',1,'resumePCB(char parameters[][MAX_LENGTH]):&#160;comm_list.c'],['../comm__list_8h.html#a672eae99ab4e3da15306bc6df644bb50',1,'resumePCB(char parameters[][MAX_LENGTH]):&#160;comm_list.c']]],
  ['return_5fcursor',['return_cursor',['../serial_8c.html#a8f0293a95ba79d7dafe198c2cb75549f',1,'serial.c']]],
  ['rtc_5fisr',['rtc_isr',['../interrupts_8c.html#a52f2615cebbdeab188085a03c913fcf9',1,'interrupts.c']]]
];
