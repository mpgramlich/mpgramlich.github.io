var searchData=
[
  ['name',['name',['../structs__pcb__stuct.html#adcb08963ff03878f5dd24129c9f99be7',1,'s_pcb_stuct']]],
  ['next',['next',['../structs__ll__node.html#a72e73da68eb603b175eb9caae6622804',1,'s_ll_node']]],
  ['nframes',['nframes',['../paging_8c.html#abf36580d5618820f15388083c9313e60',1,'paging.c']]],
  ['num_5fof_5ffat_5fcopies',['num_of_fat_copies',['../structs___f_a_t12_infos.html#adab922bdfa62f89358e84e40033e592c',1,'s_FAT12Infos::num_of_fat_copies()'],['../read_img_8c.html#a877eeb5c923bb383c2a5d1bbdf21147a',1,'num_of_fat_copies():&#160;readImg.c']]],
  ['num_5fof_5fheads',['num_of_heads',['../structs___f_a_t12_infos.html#a95fa6574fc5936cffd3eeb2259adaf20',1,'s_FAT12Infos::num_of_heads()'],['../read_img_8c.html#a7408dc33f60c51a685dc9ebc432651e2',1,'num_of_heads():&#160;readImg.c']]],
  ['num_5fof_5freserved_5fsectors',['num_of_reserved_sectors',['../structs___f_a_t12_infos.html#a1d79801bfbd4576c08d4440f0ecfd7fa',1,'s_FAT12Infos::num_of_reserved_sectors()'],['../read_img_8c.html#a2f9dd94595c99f3daf836005931a36c0',1,'num_of_reserved_sectors():&#160;readImg.c']]],
  ['num_5fof_5fsectors_5fper_5ffat',['num_of_sectors_per_fat',['../structs___f_a_t12_infos.html#ac0b7767d3e11a9f12c0cfe76085baa6c',1,'s_FAT12Infos::num_of_sectors_per_fat()'],['../read_img_8c.html#a58ab936e5b8eea1c4c99f444003b910d',1,'num_of_sectors_per_fat():&#160;readImg.c']]]
];
