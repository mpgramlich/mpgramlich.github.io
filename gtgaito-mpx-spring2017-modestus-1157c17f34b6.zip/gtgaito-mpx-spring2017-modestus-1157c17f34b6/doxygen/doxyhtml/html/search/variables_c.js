var searchData=
[
  ['max_5fnum_5fof_5froot_5fdir_5fentries',['max_num_of_root_dir_entries',['../structs___f_a_t12_infos.html#a14eaf7f28d8feb00337dc551e9dae47b',1,'s_FAT12Infos::max_num_of_root_dir_entries()'],['../read_img_8c.html#a509c6c27a08ce289e7cd283160f4b57d',1,'max_num_of_root_dir_entries():&#160;readImg.c']]],
  ['max_5fsize',['max_size',['../structheap.html#ad2e0262828735d6e437facbfce37d6b0',1,'heap']]],
  ['mcballoclist',['mcbAllocList',['../mcb_8h.html#a644924686a50359017d53fbf6786cc7f',1,'mcbAllocList():&#160;mcb.c'],['../mcb_8c.html#a644924686a50359017d53fbf6786cc7f',1,'mcbAllocList():&#160;mcb.c']]],
  ['mcbblocksize',['mcbBlockSize',['../structs__cmcb.html#a424e91c2b9462b662ff6813cb5b44730',1,'s_cmcb::mcbBlockSize()'],['../structs__lmcb.html#ac3f6b7138b69587a818861fae951363e',1,'s_lmcb::mcbBlockSize()'],['../mcb_8h.html#a087253a00063bd542eafb83bdba7b151',1,'mcbBlockSize():&#160;mcb.h']]],
  ['mcbfreelist',['mcbFreeList',['../mcb_8h.html#ac7f1b247ae17641b38fbfb74c91bc161',1,'mcbFreeList():&#160;mcb.c'],['../mcb_8c.html#ac7f1b247ae17641b38fbfb74c91bc161',1,'mcbFreeList():&#160;mcb.c']]],
  ['mem_5fsize',['mem_size',['../paging_8c.html#abf8475f59bfb67fac4b6b5a254dfe56d',1,'paging.c']]],
  ['min',['min',['../structdate__time.html#af93fdd2e01117a0171a2583718166d2a',1,'date_time']]],
  ['min_5fsize',['min_size',['../structheap.html#a7b4422774c5ca7ac8ed5ddfe95f5c8ec',1,'heap']]],
  ['mon',['mon',['../structdate__time.html#a6e8a5baa74a619330ba9925cf0baf250',1,'date_time']]]
];
