var searchData=
[
  ['fifoinsertfunc',['fifoInsertFunc',['../pcb_8h.html#a30717aca6066b99d5d73c6fda5b438e6',1,'fifoInsertFunc(void *pcb1, void *pcb2):&#160;pcb.c'],['../pcb_8c.html#a30717aca6066b99d5d73c6fda5b438e6',1,'fifoInsertFunc(void *pcb1, void *pcb2):&#160;pcb.c']]],
  ['filerename',['filerename',['../read_img_8c.html#a4fb223608c313ed38280e34345b75a27',1,'readImg.c']]],
  ['fillbootsectorstruct',['fillBootSectorStruct',['../read_img_8c.html#a57965babbf69972073a97f62b7c3dc62',1,'readImg.c']]],
  ['fillrootdirarr',['fillRootDirArr',['../read_img_8c.html#ace5428f7429d0a6c2f76c6a104d0d3d8',1,'readImg.c']]],
  ['find_5ffree',['find_free',['../paging_8c.html#abe201f9294ab23125146fff36fe95187',1,'paging.c']]],
  ['findpcb',['findPCB',['../pcb_8h.html#a3ddbd6b7d5425cfb586dabc05862e9b1',1,'findPCB(const char *processName):&#160;pcb.c'],['../pcb_8c.html#a3ddbd6b7d5425cfb586dabc05862e9b1',1,'findPCB(const char *processName):&#160;pcb.c']]],
  ['first_5ffree',['first_free',['../paging_8h.html#acb3c25257061521382c7ba900c1c1ab4',1,'paging.h']]],
  ['freeheapmem',['freeHeapMem',['../mcb_8h.html#aa8ff93b65e4b87079d5caf9a18fa44cf',1,'freeHeapMem(void *blockAddress):&#160;mcb.c'],['../mcb_8c.html#aa8ff93b65e4b87079d5caf9a18fa44cf',1,'freeHeapMem(void *blockAddress):&#160;mcb.c']]],
  ['freepcb',['freePCB',['../pcb_8h.html#aa2fdf62a032353fbef2792502860709b',1,'freePCB(pcb_t *pcbToFree):&#160;pcb.c'],['../pcb_8c.html#aa2fdf62a032353fbef2792502860709b',1,'freePCB(pcb_t *pcbToFree):&#160;pcb.c']]]
];
