var searchData=
[
  ['new_5fframe',['new_frame',['../paging_8h.html#a04bce9da2c1d7c59f6efd8e4d9b54db7',1,'new_frame(page_entry *page):&#160;paging.c'],['../paging_8c.html#a04bce9da2c1d7c59f6efd8e4d9b54db7',1,'new_frame(page_entry *page):&#160;paging.c']]],
  ['nmi',['nmi',['../interrupts_8c.html#aa42d18df06cf68f8c05fded5344c4c7e',1,'interrupts.c']]]
];
