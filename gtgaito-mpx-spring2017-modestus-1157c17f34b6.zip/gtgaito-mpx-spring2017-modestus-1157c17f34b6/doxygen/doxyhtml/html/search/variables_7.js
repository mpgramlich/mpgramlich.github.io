var searchData=
[
  ['gdt_5fentries',['gdt_entries',['../tables_8c.html#ac64ff6d00454e0b88d43b55536418288',1,'tables.c']]],
  ['gdt_5fptr',['gdt_ptr',['../tables_8c.html#aedb4641b02b4a269294e53be7c9b280e',1,'tables.c']]],
  ['gs',['gs',['../structs__process_context.html#af3f45f9f5befaeb1ced50a6d7bf91935',1,'s_processContext::gs()'],['../system_8h.html#abcc56997e8024ea8d5d3cf7e1ef6ae3a',1,'gs():&#160;system.h']]]
];
