var searchData=
[
  ['mcb_5fallocated',['MCB_ALLOCATED',['../mcb_8h.html#a9395ab72678d086105b7259423e32283ab7b1f3d8ac5db72420a67dfa5a7078f4',1,'mcb.h']]],
  ['mcb_5ferror_5faccess_5fdenied',['MCB_ERROR_ACCESS_DENIED',['../mcb_8h.html#ab8d6a331256a0e59bc8d9d705ec8e651aa8ed6fdf3e4559144dfdc25dea0d41ea',1,'mcb.h']]],
  ['mcb_5ffree',['MCB_FREE',['../mcb_8h.html#a9395ab72678d086105b7259423e32283ae1f51a24664d05c34fef0c55968467f6',1,'mcb.h']]],
  ['mcb_5fnot_5ffree',['MCB_NOT_FREE',['../mcb_8h.html#a9395ab72678d086105b7259423e32283a934e613cb33465037e61c57ae3269b38',1,'mcb.h']]],
  ['mcb_5fsuccess',['MCB_SUCCESS',['../mcb_8h.html#ab8d6a331256a0e59bc8d9d705ec8e651a9aaee8b3234427f2faadb39130982ac9',1,'mcb.h']]]
];
