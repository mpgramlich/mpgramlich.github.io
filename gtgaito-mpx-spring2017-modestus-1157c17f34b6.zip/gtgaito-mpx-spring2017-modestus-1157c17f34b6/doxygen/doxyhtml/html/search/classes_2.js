var searchData=
[
  ['footer',['footer',['../structfooter.html',1,'']]]
];
