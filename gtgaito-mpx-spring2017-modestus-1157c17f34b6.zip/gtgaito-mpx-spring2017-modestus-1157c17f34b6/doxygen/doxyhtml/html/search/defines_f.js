var searchData=
[
  ['seconds_5findex',['SECONDS_INDEX',['../rtc_8h.html#ad5172920660b0cc3a01124769f769da8',1,'rtc.h']]],
  ['sti',['sti',['../system_8h.html#ac5d15f274bc9b1e96230f3d3c60fd1f8',1,'system.h']]]
];
