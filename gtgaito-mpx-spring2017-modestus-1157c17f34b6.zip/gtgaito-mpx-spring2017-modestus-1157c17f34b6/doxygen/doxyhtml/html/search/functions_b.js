var searchData=
[
  ['list',['list',['../read_img_8c.html#a887e05a691190a3ee4dc626f226b5b00',1,'readImg.c']]],
  ['listtest',['listTest',['../linked__list_8h.html#a0a60ac1fe6e5055de61277ac9703b13e',1,'listTest():&#160;linked_list.c'],['../linked__list_8c.html#a0a60ac1fe6e5055de61277ac9703b13e',1,'listTest():&#160;linked_list.c']]],
  ['load_5fpage_5fdir',['load_page_dir',['../paging_8h.html#a3affceba4cd194e1c516404c14abbe7c',1,'load_page_dir(page_dir *new_page_dir):&#160;paging.c'],['../paging_8c.html#a31e6c585cbda542534f1b0fc83e40689',1,'load_page_dir(page_dir *new_dir):&#160;paging.c']]],
  ['loadr3',['loadr3',['../group___r3.html#ga70f2cab9ebef7e5f74ea607c4f25dd5c',1,'loadr3(char parameters[][MAX_LENGTH]):&#160;comm_list.c'],['../group___r3.html#ga70f2cab9ebef7e5f74ea607c4f25dd5c',1,'loadr3(char parameters[][MAX_LENGTH]):&#160;comm_list.c']]]
];
