var searchData=
[
  ['u16int',['u16int',['../system_8h.html#a863d9497073aad2b991aeab2211d87af',1,'system.h']]],
  ['u32int',['u32int',['../system_8h.html#a757de76cafbcddaac0d1632902fe4cb8',1,'system.h']]],
  ['u8int',['u8int',['../system_8h.html#a1026e682ffdadc1701c42cd44ce9efcf',1,'system.h']]],
  ['uint16_5ft',['uint16_t',['../system_8h.html#a273cf69d639a59973b6019625df33e30',1,'system.h']]],
  ['uint32_5ft',['uint32_t',['../system_8h.html#a06896e8c53f721507066c079052171f8',1,'system.h']]],
  ['uint8_5ft',['uint8_t',['../system_8h.html#aba7bc1797add20fe3efdf37ced1182c5',1,'system.h']]],
  ['unblockpcb',['unblockPCB',['../comm__list_8c.html#ac26704b8c23bbe0e0fdf8e838915e29d',1,'unblockPCB(char parameters[][MAX_LENGTH]):&#160;comm_list.c'],['../comm__list_8h.html#ac26704b8c23bbe0e0fdf8e838915e29d',1,'unblockPCB(char parameters[][MAX_LENGTH]):&#160;comm_list.c']]],
  ['unknown_5fcommand',['UNKNOWN_COMMAND',['../comm__vars_8h.html#ac5f4cf1c989af592617184f7a7e5c372',1,'comm_vars.h']]],
  ['up',['UP',['../input_8h.html#a1965eaca47dbf3f87acdafc2208f04eb',1,'input.h']]],
  ['user_5fapp',['USER_APP',['../pcb_8h.html#ab3268ce0bdfc94e5757917d42c73d9f1a0c6b23d6f956b23100dec45357ff8dc0',1,'pcb.h']]],
  ['usermode',['usermode',['../structpage__entry.html#a2beafd3900a1f36f09af9c35a9a14f18',1,'page_entry']]]
];
