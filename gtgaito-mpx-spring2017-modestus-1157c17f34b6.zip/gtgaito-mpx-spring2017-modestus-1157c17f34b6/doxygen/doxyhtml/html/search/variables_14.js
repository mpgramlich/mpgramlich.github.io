var searchData=
[
  ['volume_5fid',['volume_id',['../structs___f_a_t12_infos.html#aebd86e32089df7736b5e22625a6efdaa',1,'s_FAT12Infos::volume_id()'],['../read_img_8c.html#a77a2cd2807c348ae913c256e41533320',1,'volume_id():&#160;readImg.c']]],
  ['volume_5flabel',['volume_label',['../structs___f_a_t12_infos.html#a7f033f386d2141afa39d7a847728b834',1,'s_FAT12Infos::volume_label()'],['../read_img_8c.html#a92fb13163216985d3e94841aa629f8b1',1,'volume_label():&#160;readImg.c']]]
];
