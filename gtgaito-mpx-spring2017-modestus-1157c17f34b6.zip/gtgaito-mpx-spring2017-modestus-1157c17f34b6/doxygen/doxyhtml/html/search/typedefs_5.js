var searchData=
[
  ['mcbaddressptr_5ft',['mcbAddressPtr_t',['../mcb_8h.html#a90a62c2a7f56f2a59b679b8c0db3c485',1,'mcb.h']]],
  ['mcbsize_5ft',['mcbSize_t',['../mcb_8h.html#a07c5bc491df38272c7a674801ad9a423',1,'mcb.h']]]
];
