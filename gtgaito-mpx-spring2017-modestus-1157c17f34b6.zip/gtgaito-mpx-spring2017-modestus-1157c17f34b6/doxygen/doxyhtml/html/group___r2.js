var group___r2 =
[
    [ "pcb.h", "pcb_8h.html", null ],
    [ "linked_list.h", "linked__list_8h.html", null ],
    [ "changeProcessState", "group___r2.html#ga69ffbf50820bccd94857e1d25b68b2c3", null ],
    [ "classToString", "group___r2.html#gac38459f8731293f12b7fb0170c923471", null ],
    [ "errorToString", "group___r2.html#ga834927e89e94c123a0ec5322b11b0161", null ],
    [ "getState", "group___r2.html#gae34a580c5336a0d5f2a0589f41f25fa2", null ],
    [ "printPCBFunc", "group___r2.html#ga819c31d0b376ca33ed371253585f9f80", null ],
    [ "setPrintFunction", "group___r2.html#gafc8969d7969f61c928a01f4c302e669b", null ],
    [ "stateToString", "group___r2.html#ga8667e4228a987f7d43e598f9855e9a52", null ],
    [ "stringToClass", "group___r2.html#gae81b3dd13059be0733193c53681ca440", null ]
];