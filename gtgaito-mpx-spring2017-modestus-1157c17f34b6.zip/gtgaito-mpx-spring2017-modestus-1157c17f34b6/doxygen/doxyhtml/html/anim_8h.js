var anim_8h =
[
    [ "busy_wait", "anim_8h.html#accd23e11967f6634e7885688e395b964", null ],
    [ "clear_screen", "anim_8h.html#abc40cd622f423abf44084c8f8595f57f", null ],
    [ "start_up_anim", "anim_8h.html#a5bf31d96ce4c2c86dfab5440a835c457", null ]
];