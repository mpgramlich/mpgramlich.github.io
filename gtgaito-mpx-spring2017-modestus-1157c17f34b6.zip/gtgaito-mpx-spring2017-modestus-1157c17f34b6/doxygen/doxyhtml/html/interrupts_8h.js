var interrupts_8h =
[
    [ "init_irq", "interrupts_8h.html#ad17d9a8aa78440af8fc40d3fd55dbad8", null ],
    [ "init_pic", "interrupts_8h.html#afbc0dbef6f15e2df21b38724ea38c483", null ]
];