var paging_8h =
[
    [ "page_entry", "structpage__entry.html", "structpage__entry" ],
    [ "page_table", "structpage__table.html", "structpage__table" ],
    [ "page_dir", "structpage__dir.html", "structpage__dir" ],
    [ "PAGE_SIZE", "paging_8h.html#a7d467c1d283fdfa1f2081ba1e0d01b6e", null ],
    [ "clear_bit", "paging_8h.html#adcef508c82c20a032508f871e79e1b92", null ],
    [ "first_free", "paging_8h.html#acb3c25257061521382c7ba900c1c1ab4", null ],
    [ "get_bit", "paging_8h.html#a317b4797bc81f65bd01cfa190800ecdd", null ],
    [ "get_page", "paging_8h.html#a69b165b3d1adf3aeaae126ca7a5aac3e", null ],
    [ "init_paging", "paging_8h.html#a919b727f386797a8b9d8eceb5c4e7313", null ],
    [ "load_page_dir", "paging_8h.html#a3affceba4cd194e1c516404c14abbe7c", null ],
    [ "new_frame", "paging_8h.html#a04bce9da2c1d7c59f6efd8e4d9b54db7", null ],
    [ "set_bit", "paging_8h.html#a70101fc152ff58caafbe36ab391a9a68", null ]
];