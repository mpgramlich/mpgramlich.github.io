var rtc_8h =
[
    [ "DAY_OF_MONTH_INDEX", "rtc_8h.html#a3524da1819943d5a94067c1c9e8aa5cc", null ],
    [ "HOURS_INDEX", "rtc_8h.html#a58095ff2a9d2a6b458d6ef46fa9d4f68", null ],
    [ "MINUTES_INDEX", "rtc_8h.html#afb7672d6cea1669acd4f76d74ca28459", null ],
    [ "MONTHS_INDEX", "rtc_8h.html#a69a2fa993700fb8058ec48611ebbf5c8", null ],
    [ "RTC_DATA_REG", "rtc_8h.html#a2f258a00c59c3f347c8d2d4a75471ce0", null ],
    [ "RTC_INDEX_REG", "rtc_8h.html#a52aed4f0dce6c69eec85228a1fc15e2c", null ],
    [ "SECONDS_INDEX", "rtc_8h.html#ad5172920660b0cc3a01124769f769da8", null ],
    [ "YEAR_INDEX", "rtc_8h.html#a940c790a06a199a1e2136bea0058799e", null ],
    [ "get_date", "rtc_8h.html#ab43f56447c49f42bb4baee3e59e2d1f9", null ],
    [ "get_time", "rtc_8h.html#a35fa24488cb7eb077e8dc995729202cf", null ],
    [ "set_date", "rtc_8h.html#a7903b907981d739e3d156a964255d45e", null ],
    [ "set_time", "rtc_8h.html#a9f75815e4f89e0ff7065999f43867e92", null ]
];