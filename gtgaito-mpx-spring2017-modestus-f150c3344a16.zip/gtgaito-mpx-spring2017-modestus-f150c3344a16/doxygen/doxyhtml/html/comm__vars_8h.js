var comm__vars_8h =
[
    [ "EXTRA_PARAMETERS", "comm__vars_8h.html#a3d75ee5ce40f6fc7b3182661c2e11fde", null ],
    [ "IMPROPER_COMMAND", "comm__vars_8h.html#adc0c870b429ed41ab22e23dbba9e6af1", null ],
    [ "UNKNOWN_COMMAND", "comm__vars_8h.html#ac5f4cf1c989af592617184f7a7e5c372", null ],
    [ "VERSION", "comm__vars_8h.html#a1c6d5de492ac61ad29aec7aa9a436bbf", null ]
];