var io_8h =
[
    [ "inb", "io_8h.html#ad6488a48837d179b1833e2f48dac9665", null ],
    [ "outb", "io_8h.html#a0e661d36f40638a36550a534076f155b", null ]
];