var dir_c05810f7c5bba5b5172f5ac15b87dda3 =
[
    [ "heap.c", "heap_8c.html", "heap_8c" ],
    [ "paging.c", "paging_8c.html", "paging_8c" ]
];