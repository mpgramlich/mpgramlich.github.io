var structdate__time =
[
    [ "day_m", "structdate__time.html#a72ee4f3a6a9970e58861c868bc676ba2", null ],
    [ "day_w", "structdate__time.html#aa021771ff83fe860afaaf158932fcb15", null ],
    [ "day_y", "structdate__time.html#ad89b6054376708a35bc1c0a186c808ca", null ],
    [ "hour", "structdate__time.html#a4331b46df7b89763a85ea97a246c4ee2", null ],
    [ "min", "structdate__time.html#af93fdd2e01117a0171a2583718166d2a", null ],
    [ "mon", "structdate__time.html#a6e8a5baa74a619330ba9925cf0baf250", null ],
    [ "sec", "structdate__time.html#ac43a109ccc7f3c46840afa8a30dc51f1", null ],
    [ "year", "structdate__time.html#ae96e2e4cc09780eaac04038e12bbe06b", null ]
];