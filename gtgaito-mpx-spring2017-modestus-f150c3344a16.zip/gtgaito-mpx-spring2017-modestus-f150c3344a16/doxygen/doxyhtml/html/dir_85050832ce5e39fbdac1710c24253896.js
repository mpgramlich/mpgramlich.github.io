var dir_85050832ce5e39fbdac1710c24253896 =
[
    [ "linked_list.c", "linked__list_8c.html", "linked__list_8c" ],
    [ "string.c", "string_8c.html", "string_8c" ]
];