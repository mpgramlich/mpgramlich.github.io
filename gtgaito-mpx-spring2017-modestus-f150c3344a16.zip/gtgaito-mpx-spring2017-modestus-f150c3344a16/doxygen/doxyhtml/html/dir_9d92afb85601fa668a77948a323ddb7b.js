var dir_9d92afb85601fa668a77948a323ddb7b =
[
    [ "interrupts.c", "interrupts_8c.html", "interrupts_8c" ],
    [ "kmain.c", "kmain_8c.html", "kmain_8c" ],
    [ "mpx_supt.c", "mpx__supt_8c.html", "mpx__supt_8c" ],
    [ "pcb.c", "pcb_8c.html", "pcb_8c" ],
    [ "rtc.c", "rtc_8c.html", "rtc_8c" ],
    [ "serial.c", "serial_8c.html", "serial_8c" ],
    [ "system.c", "system_8c.html", "system_8c" ],
    [ "tables.c", "tables_8c.html", "tables_8c" ]
];