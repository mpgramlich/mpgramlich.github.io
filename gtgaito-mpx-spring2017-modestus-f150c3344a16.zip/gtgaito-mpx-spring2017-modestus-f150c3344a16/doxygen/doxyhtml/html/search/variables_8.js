var searchData=
[
  ['head',['head',['../structs__ll.html#a4ceb08c280f2494dd51a6edebf99fbfa',1,'s_ll::head()'],['../structfooter.html#acae33dac61c9505ff5b850f88d32dd0b',1,'footer::head()']]],
  ['hist_5fi',['hist_i',['../commhand_8c.html#addd367ad6cf3ffe96855b76b451d02d5',1,'commhand.c']]],
  ['hour',['hour',['../structdate__time.html#a4331b46df7b89763a85ea97a246c4ee2',1,'date_time']]]
];
