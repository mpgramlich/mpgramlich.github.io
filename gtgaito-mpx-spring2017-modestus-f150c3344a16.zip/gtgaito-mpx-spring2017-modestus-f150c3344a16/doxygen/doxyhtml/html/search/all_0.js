var searchData=
[
  ['_5f_5fattribute_5f_5f',['__attribute__',['../linked__list_8h.html#aaa4b117a86b9205e66f2cde318c1f01e',1,'__attribute__():&#160;linked_list.h'],['../comm__list_8h.html#a7ec0161c488281f85601e9f92d9226bd',1,'__attribute__():&#160;comm_list.h'],['../tables_8h.html#ad1929ba5e546bde910d88a7c08dc507b',1,'__attribute__((packed)) idt_entry:&#160;tables.h'],['../system_8h.html#a44e10bbf52e8e7e9cdf9c2c5ff22f0b0',1,'__attribute__((packed)):&#160;system.h']]],
  ['_5f_5fend',['__end',['../heap_8c.html#a51f2442fadb8ffd3019f4aeb1b04c4d6',1,'heap.c']]],
  ['_5fend',['_end',['../heap_8c.html#a850b19392dca6170001ce200467ab610',1,'heap.c']]],
  ['_5fkmalloc',['_kmalloc',['../heap_8h.html#a9bfb8053c2382598ef5b2175f475d49a',1,'_kmalloc(u32int size, int align, u32int *phys_addr):&#160;heap.c'],['../heap_8c.html#a014b54e36b61f133f53dd509c461f35e',1,'_kmalloc(u32int size, int page_align, u32int *phys_addr):&#160;heap.c']]]
];
