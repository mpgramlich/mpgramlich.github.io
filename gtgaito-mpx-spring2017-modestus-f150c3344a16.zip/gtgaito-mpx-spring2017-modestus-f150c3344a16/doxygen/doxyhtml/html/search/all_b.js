var searchData=
[
  ['left',['LEFT',['../input_8h.html#a437ef08681e7210d6678427030446a54',1,'input.h']]],
  ['length',['length',['../structs__ll.html#ac8dd12a2074d1f022cdbb0ccb1f08566',1,'s_ll']]],
  ['limit',['limit',['../structidt__struct.html#aa75e2805e21db1a33816af778263d712',1,'idt_struct::limit()'],['../structgdt__descriptor__struct.html#a3c8ae013805dd982b25f0d62e3cdee0e',1,'gdt_descriptor_struct::limit()'],['../tables_8h.html#a68fd3b4f6c14a331ca9b226cbf122e13',1,'limit():&#160;tables.h']]],
  ['limit_5flow',['limit_low',['../structgdt__entry__struct.html#ada721fbdc3e8d3feae3b07d4b82a37bd',1,'gdt_entry_struct::limit_low()'],['../tables_8h.html#af9013229edfb91d4820f66b8df890ce3',1,'limit_low():&#160;tables.h']]],
  ['linked_5flist_2ec',['linked_list.c',['../linked__list_8c.html',1,'']]],
  ['linked_5flist_2eh',['linked_list.h',['../linked__list_8h.html',1,'']]],
  ['linkedlist_5ft',['linkedList_t',['../structlinked_list__t.html',1,'linkedList_t'],['../linked__list_8h.html#a82d0a4fbb83fdef7235674426e7a9b26',1,'linkedList_t():&#160;linked_list.h']]],
  ['listtest',['listTest',['../linked__list_8h.html#a0a60ac1fe6e5055de61277ac9703b13e',1,'listTest():&#160;linked_list.c'],['../linked__list_8c.html#a0a60ac1fe6e5055de61277ac9703b13e',1,'listTest():&#160;linked_list.c']]],
  ['load_5fpage_5fdir',['load_page_dir',['../paging_8h.html#a3affceba4cd194e1c516404c14abbe7c',1,'load_page_dir(page_dir *new_page_dir):&#160;paging.c'],['../paging_8c.html#a31e6c585cbda542534f1b0fc83e40689',1,'load_page_dir(page_dir *new_dir):&#160;paging.c']]],
  ['loadr3',['loadr3',['../group___r3.html#ga70f2cab9ebef7e5f74ea607c4f25dd5c',1,'loadr3(char parameters[][MAX_LENGTH]):&#160;comm_list.c'],['../group___r3.html#ga70f2cab9ebef7e5f74ea607c4f25dd5c',1,'loadr3(char parameters[][MAX_LENGTH]):&#160;comm_list.c']]]
];
