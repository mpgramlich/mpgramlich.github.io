var searchData=
[
  ['base',['base',['../structidt__struct.html#a1a91fe2ab44ad8dfbad0f6d07ec789ea',1,'idt_struct::base()'],['../structgdt__descriptor__struct.html#aa47407e7b435c214d0cdd22cb66f0e71',1,'gdt_descriptor_struct::base()'],['../structheap.html#a744634662f1ffdb4d85632e68c063e51',1,'heap::base()'],['../tables_8h.html#ab5763c2b18c825c8b8fba44b2e60ddc1',1,'base():&#160;tables.h']]],
  ['base_5fhigh',['base_high',['../structidt__entry__struct.html#a1c6a29cae5ea9a832cf4261aaa5b43d0',1,'idt_entry_struct::base_high()'],['../structgdt__entry__struct.html#aa03c14867c293012449a3b18a07f45f2',1,'gdt_entry_struct::base_high()'],['../tables_8h.html#a706c81b840522a69ab6e6e941630d5e4',1,'base_high():&#160;tables.h']]],
  ['base_5flow',['base_low',['../structidt__entry__struct.html#aefa75d6bfe07f1f544393b4dbccb3e76',1,'idt_entry_struct::base_low()'],['../structgdt__entry__struct.html#a90f05cd7f227a34e977a639843a23275',1,'gdt_entry_struct::base_low()'],['../tables_8h.html#a0a776dced2c26f16298425cde39f8364',1,'base_low():&#160;tables.h']]],
  ['base_5fmid',['base_mid',['../structgdt__entry__struct.html#a0369f1e190c433425c5b0f40c2070715',1,'gdt_entry_struct::base_mid()'],['../tables_8h.html#a35c709a004babd09046db9f667ba0646',1,'base_mid():&#160;tables.h']]],
  ['block',['block',['../structindex__entry.html#a0a8d4dc0595b5f2ef42e7080c5221c1f',1,'index_entry']]],
  ['blockedqueue',['blockedQueue',['../pcb_8h.html#aa3eb63b40a5cf1eb03b494f7ddd1af2a',1,'blockedQueue():&#160;pcb.c'],['../pcb_8c.html#aa3eb63b40a5cf1eb03b494f7ddd1af2a',1,'blockedQueue():&#160;pcb.c']]]
];
