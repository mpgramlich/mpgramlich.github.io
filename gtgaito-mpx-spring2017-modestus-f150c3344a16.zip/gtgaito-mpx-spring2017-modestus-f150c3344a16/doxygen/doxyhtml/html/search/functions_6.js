var searchData=
[
  ['fifoinsertfunc',['fifoInsertFunc',['../pcb_8h.html#a30717aca6066b99d5d73c6fda5b438e6',1,'fifoInsertFunc(void *pcb1, void *pcb2):&#160;pcb.c'],['../pcb_8c.html#a30717aca6066b99d5d73c6fda5b438e6',1,'fifoInsertFunc(void *pcb1, void *pcb2):&#160;pcb.c']]],
  ['find_5ffree',['find_free',['../paging_8c.html#abe201f9294ab23125146fff36fe95187',1,'paging.c']]],
  ['findpcb',['findPCB',['../pcb_8h.html#a3ddbd6b7d5425cfb586dabc05862e9b1',1,'findPCB(const char *processName):&#160;pcb.c'],['../pcb_8c.html#a3ddbd6b7d5425cfb586dabc05862e9b1',1,'findPCB(const char *processName):&#160;pcb.c']]],
  ['first_5ffree',['first_free',['../paging_8h.html#acb3c25257061521382c7ba900c1c1ab4',1,'paging.h']]],
  ['freepcb',['freePCB',['../pcb_8h.html#aa2fdf62a032353fbef2792502860709b',1,'freePCB(pcb_t *pcbToFree):&#160;pcb.c'],['../pcb_8c.html#aa2fdf62a032353fbef2792502860709b',1,'freePCB(pcb_t *pcbToFree):&#160;pcb.c']]]
];
