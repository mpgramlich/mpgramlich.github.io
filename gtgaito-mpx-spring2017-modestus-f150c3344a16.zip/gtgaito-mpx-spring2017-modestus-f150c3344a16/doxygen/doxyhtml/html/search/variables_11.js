var searchData=
[
  ['searchcompfunc',['searchCompFunc',['../structs__ll.html#adba6e6a1b395433564b38b58712fba2a',1,'s_ll']]],
  ['sec',['sec',['../structdate__time.html#ac43a109ccc7f3c46840afa8a30dc51f1',1,'date_time']]],
  ['serial_5fport_5fin',['serial_port_in',['../serial_8c.html#a1a756238531fc5bf1096f89dc18e835e',1,'serial.c']]],
  ['serial_5fport_5fout',['serial_port_out',['../serial_8c.html#adbb2c18b0aaab5c1927a6f674768a710',1,'serial.c']]],
  ['shutdown',['shutdown',['../commhand_8c.html#a5161d377a61befc3f8103e794d5cb582',1,'commhand.c']]],
  ['size',['size',['../structheader.html#af8cc659f702446226bc2ebabba437d5d',1,'header::size()'],['../structindex__entry.html#a2b0247aae5c7f9884f8eef1ee121adb0',1,'index_entry::size()']]],
  ['sselect',['sselect',['../structidt__entry__struct.html#a85254c7df6a612f4a4b3bb470ff3370c',1,'idt_entry_struct::sselect()'],['../tables_8h.html#ab3f34507900160b4a9b309b4ed039e07',1,'sselect():&#160;tables.h']]],
  ['stack',['stack',['../structs__pcb__stuct.html#a3de14f25a2689f6b760f7fc36c09ff45',1,'s_pcb_stuct']]],
  ['stackbase',['stackBase',['../structs__pcb__stuct.html#ae0f0e7da704e3de9b8bde295b04c522b',1,'s_pcb_stuct']]],
  ['stacktop',['stackTop',['../structs__pcb__stuct.html#ab19f23bae6d9f5103a1856aeec1575e7',1,'s_pcb_stuct']]],
  ['student_5ffree',['student_free',['../mpx__supt_8c.html#a19c47c02b0338bc13716d98305bb8a34',1,'mpx_supt.c']]],
  ['student_5fmalloc',['student_malloc',['../mpx__supt_8c.html#a421e2b48efb5facc71d16979252710e2',1,'mpx_supt.c']]],
  ['suspendedblockedqueue',['suspendedBlockedQueue',['../pcb_8h.html#ae83c9a71ab217215db8dfe3eb9c94e8e',1,'suspendedBlockedQueue():&#160;pcb.c'],['../pcb_8c.html#ae83c9a71ab217215db8dfe3eb9c94e8e',1,'suspendedBlockedQueue():&#160;pcb.c']]],
  ['suspendedreadyqueue',['suspendedReadyQueue',['../pcb_8h.html#a95c66b02e576aabe04df3fdc9e981fc3',1,'suspendedReadyQueue():&#160;pcb.c'],['../pcb_8c.html#a95c66b02e576aabe04df3fdc9e981fc3',1,'suspendedReadyQueue():&#160;pcb.c']]]
];
