var searchData=
[
  ['data',['data',['../structs__ll__node.html#a79ffbe9722e36b171fefc1bada4f2721',1,'s_ll_node']]],
  ['datasize',['dataSize',['../structs__pcb__stuct.html#abaaa46716f0f2187620b0042c04e6958',1,'s_pcb_stuct']]],
  ['datastart',['dataStart',['../structs__pcb__stuct.html#a8df76551e88a09dd66b98deb0f9ecbc4',1,'s_pcb_stuct']]],
  ['day_5fm',['day_m',['../structdate__time.html#a72ee4f3a6a9970e58861c868bc676ba2',1,'date_time']]],
  ['day_5fw',['day_w',['../structdate__time.html#aa021771ff83fe860afaaf158932fcb15',1,'date_time']]],
  ['day_5fy',['day_y',['../structdate__time.html#ad89b6054376708a35bc1c0a186c808ca',1,'date_time']]],
  ['device_5fid',['device_id',['../structparam.html#a44a7285b02749114186a9f9971941bcb',1,'param']]],
  ['dirty',['dirty',['../structpage__entry.html#ab3b5e22c6146f227a26bdec64e63f4b0',1,'page_entry']]],
  ['ds',['ds',['../structs__process_context.html#a8d90dc3b66ee9de90b9c602987422d9c',1,'s_processContext::ds()'],['../system_8h.html#a27b615cc9d414c57f335c1744908fbd1',1,'ds():&#160;system.h']]]
];
