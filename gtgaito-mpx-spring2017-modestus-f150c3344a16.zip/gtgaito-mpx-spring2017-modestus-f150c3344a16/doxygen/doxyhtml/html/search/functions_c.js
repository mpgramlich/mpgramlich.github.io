var searchData=
[
  ['make_5fheap',['make_heap',['../heap_8h.html#a686135c02695aef4208f93d4549a15d0',1,'make_heap(u32int base, u32int max, u32int min):&#160;heap.c'],['../heap_8c.html#a686135c02695aef4208f93d4549a15d0',1,'make_heap(u32int base, u32int max, u32int min):&#160;heap.c']]],
  ['makenewnode',['makeNewNode',['../linked__list_8h.html#a042e8aa38eb81453dd7e81ade7d38b5b',1,'makeNewNode(linkedList_t *list, void *data):&#160;linked_list.c'],['../linked__list_8c.html#a042e8aa38eb81453dd7e81ade7d38b5b',1,'makeNewNode(linkedList_t *list, void *data):&#160;linked_list.c']]],
  ['memset',['memset',['../string_8h.html#ace6ee45c30e71865e6eb635200379db9',1,'memset(void *s, int c, size_t n):&#160;string.c'],['../string_8c.html#ace6ee45c30e71865e6eb635200379db9',1,'memset(void *s, int c, size_t n):&#160;string.c']]],
  ['movenodetonewlist',['moveNodeToNewList',['../linked__list_8h.html#a1573ed6fa569b80577b596e78cd90b4a',1,'moveNodeToNewList(node_t *nodeToMove, linkedList_t *newList):&#160;linked_list.c'],['../linked__list_8c.html#a1573ed6fa569b80577b596e78cd90b4a',1,'moveNodeToNewList(node_t *nodeToMove, linkedList_t *newList):&#160;linked_list.c']]],
  ['mpx_5finit',['mpx_init',['../mpx__supt_8h.html#a53332c6a3107a4feed6e2e79690a6ffa',1,'mpx_init(int cur_mod):&#160;mpx_supt.c'],['../mpx__supt_8c.html#a53332c6a3107a4feed6e2e79690a6ffa',1,'mpx_init(int cur_mod):&#160;mpx_supt.c']]]
];
