var searchData=
[
  ['kdir',['kdir',['../heap_8c.html#a61ce943ba80d9dfab89a826cae9ddc4a',1,'kdir():&#160;paging.c'],['../paging_8c.html#a61ce943ba80d9dfab89a826cae9ddc4a',1,'kdir():&#160;paging.c']]],
  ['kheap',['kheap',['../heap_8c.html#a61825456a33b09780a5493c95adcae8a',1,'kheap():&#160;heap.c'],['../paging_8c.html#a61825456a33b09780a5493c95adcae8a',1,'kheap():&#160;heap.c']]]
];
