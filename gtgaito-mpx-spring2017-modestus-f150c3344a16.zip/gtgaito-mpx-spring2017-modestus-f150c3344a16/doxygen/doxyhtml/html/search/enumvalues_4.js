var searchData=
[
  ['not_5fsuspended',['NOT_SUSPENDED',['../pcb_8h.html#a62786f54ed7251d1b1de61f23b707fc1a13635c2ef4530cf1d8ccbb10a80be35d',1,'pcb.h']]]
];
