var searchData=
[
  ['name',['name',['../structs__pcb__stuct.html#adcb08963ff03878f5dd24129c9f99be7',1,'s_pcb_stuct']]],
  ['new_5fframe',['new_frame',['../paging_8h.html#a04bce9da2c1d7c59f6efd8e4d9b54db7',1,'new_frame(page_entry *page):&#160;paging.c'],['../paging_8c.html#a04bce9da2c1d7c59f6efd8e4d9b54db7',1,'new_frame(page_entry *page):&#160;paging.c']]],
  ['new_5fline',['NEW_LINE',['../input_8h.html#a7b99dc1e1c86b4897498c2d436ead1b5',1,'input.h']]],
  ['next',['next',['../structs__ll__node.html#a72e73da68eb603b175eb9caae6622804',1,'s_ll_node']]],
  ['nframes',['nframes',['../paging_8c.html#abf36580d5618820f15388083c9313e60',1,'paging.c']]],
  ['nmi',['nmi',['../interrupts_8c.html#aa42d18df06cf68f8c05fded5344c4c7e',1,'interrupts.c']]],
  ['no_5ferror',['NO_ERROR',['../serial_8c.html#a258bb72419ef143530a2f8f55e7d57af',1,'serial.c']]],
  ['no_5fwarn',['no_warn',['../system_8h.html#ab3bb695e7817363c7bdb781f214e83a2',1,'system.h']]],
  ['node_5ft',['node_t',['../structnode__t.html',1,'node_t'],['../linked__list_8h.html#a694e38fba2953567dfe172fae36ca04e',1,'node_t():&#160;linked_list.h']]],
  ['nop',['nop',['../system_8h.html#a6c92c29fa8e83ab85e05543010e10d7c',1,'system.h']]],
  ['not_5fsuspended',['NOT_SUSPENDED',['../pcb_8h.html#a62786f54ed7251d1b1de61f23b707fc1a13635c2ef4530cf1d8ccbb10a80be35d',1,'pcb.h']]],
  ['null',['NULL',['../system_8h.html#a070d2ce7b6bb7e5c05602aa8c308d0c4',1,'system.h']]]
];
