var searchData=
[
  ['callercontext',['callerContext',['../mpx__supt_8c.html#a94f0e6e22485c53a612632d529d03748',1,'mpx_supt.c']]],
  ['cdecl',['cdecl',['../string_8h.html#a9e78af0dd6b6d82ec72efd4be2fe34f7',1,'string.h']]],
  ['cdir',['cdir',['../paging_8c.html#af7da380833e92d5c7d3c3db41484713b',1,'paging.c']]],
  ['cmdarray',['cmdArray',['../commhand_8c.html#a5582c68677f88e6cacb6b1a2086f34c1',1,'cmdArray():&#160;commhand.c'],['../comm__list_8h.html#a5582c68677f88e6cacb6b1a2086f34c1',1,'cmdArray():&#160;commhand.c']]],
  ['cmdfunc',['cmdFunc',['../structs__cmd__struct.html#a12f0e24fc635611fb6dea941a5415014',1,'s_cmd_struct']]],
  ['cmdname',['cmdName',['../structs__cmd__struct.html#a05785ef37725660426f6881972e22de0',1,'s_cmd_struct']]],
  ['comm_5fhist',['comm_hist',['../commhand_8c.html#a3d3b206df340b640d0fca3a5c7436dfe',1,'commhand.c']]],
  ['context',['context',['../structs__pcb__stuct.html#a37919a4fb1d70889bbe8ddcfe6ba6b17',1,'s_pcb_stuct']]],
  ['cs',['cs',['../structs__process_context.html#ab42059eb53c837f3ee13a84559ef3f21',1,'s_processContext::cs()'],['../system_8h.html#aff16eb39266599b77ad4025e1cf36c4e',1,'cs():&#160;system.h']]],
  ['curr_5fheap',['curr_heap',['../heap_8c.html#afaac4d3fb801ecbd3c6fe3c995d5cf82',1,'heap.c']]],
  ['current_5fmodule',['current_module',['../mpx__supt_8c.html#a3d19c725b7f9f45e9da97a79ca6a4737',1,'mpx_supt.c']]],
  ['currentoperatingprocess',['currentOperatingProcess',['../pcb_8h.html#a6c7da7448bad9cd094f1deed035efada',1,'currentOperatingProcess():&#160;pcb.c'],['../pcb_8c.html#a6c7da7448bad9cd094f1deed035efada',1,'currentOperatingProcess():&#160;pcb.c']]]
];
