var searchData=
[
  ['page_5fsize',['PAGE_SIZE',['../paging_8h.html#a7d467c1d283fdfa1f2081ba1e0d01b6e',1,'paging.h']]],
  ['pcb_5fqueue_5fmax_5fsize',['PCB_QUEUE_MAX_SIZE',['../pcb_8h.html#afeaa4736820787d9a22e121d670b9243',1,'pcb.h']]],
  ['pic1',['PIC1',['../interrupts_8c.html#a6b115109e4a0d3c5fb6252d091e86bfe',1,'interrupts.c']]],
  ['pic2',['PIC2',['../interrupts_8c.html#ac90003f52c8d736193efc954ece08e58',1,'interrupts.c']]],
  ['printf',['printf',['../string_8h.html#a0f459d16901ef591acaafa4b67fd4be5',1,'string.h']]],
  ['process_5fcontext_5fsize',['PROCESS_CONTEXT_SIZE',['../pcb_8h.html#abb5f1eb47c3ac477582ecc49dc8990ee',1,'pcb.h']]],
  ['process_5fhighest_5fpriority',['PROCESS_HIGHEST_PRIORITY',['../pcb_8h.html#a12d557bfd2b8463834fd1542647de0f1',1,'pcb.h']]],
  ['process_5flowest_5fpriority',['PROCESS_LOWEST_PRIORITY',['../pcb_8h.html#a9ae4b3bfaf4a94bf2280be6fa09519be',1,'pcb.h']]],
  ['process_5fmax_5fname_5flength',['PROCESS_MAX_NAME_LENGTH',['../pcb_8h.html#acd2dea966e4e5b760451b4fcc66f6cce',1,'pcb.h']]],
  ['process_5fstack_5fsize',['PROCESS_STACK_SIZE',['../pcb_8h.html#a2dbc13416ed2817701a94e30698cdee3',1,'pcb.h']]],
  ['prompt',['PROMPT',['../input_8h.html#accdbea14ea06c15e271784368bd993e8',1,'input.h']]]
];
