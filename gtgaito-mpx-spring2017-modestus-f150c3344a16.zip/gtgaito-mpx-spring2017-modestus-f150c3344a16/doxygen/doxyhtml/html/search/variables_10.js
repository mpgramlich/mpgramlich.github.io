var searchData=
[
  ['readyqueue',['readyQueue',['../pcb_8h.html#a7b1bca867586a0a58222b805dbe3be28',1,'readyQueue():&#160;pcb.c'],['../pcb_8c.html#a7b1bca867586a0a58222b805dbe3be28',1,'readyQueue():&#160;pcb.c']]],
  ['representingnode',['representingNode',['../structs__pcb__stuct.html#abf7c3f3b733400d1c48509497e34a18f',1,'s_pcb_stuct']]],
  ['reserved',['reserved',['../structpage__entry.html#af6d963f09b01571b107e6f505050c0e5',1,'page_entry']]]
];
