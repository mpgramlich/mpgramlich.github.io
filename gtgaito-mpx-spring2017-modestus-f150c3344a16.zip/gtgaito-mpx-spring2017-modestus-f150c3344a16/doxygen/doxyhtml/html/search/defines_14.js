var searchData=
[
  ['year_5findex',['YEAR_INDEX',['../rtc_8h.html#a940c790a06a199a1e2136bea0058799e',1,'rtc.h']]]
];
