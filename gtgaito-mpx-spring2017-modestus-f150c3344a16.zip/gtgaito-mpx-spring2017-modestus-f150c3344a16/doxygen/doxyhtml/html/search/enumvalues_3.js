var searchData=
[
  ['initial',['INITIAL',['../pcb_8h.html#a8461d6c03c00b03bad59b5a29d27b902a7116db6906963fd0720c4a85be250cf4',1,'pcb.h']]]
];
