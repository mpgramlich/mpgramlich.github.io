var searchData=
[
  ['page_5fsize',['page_size',['../paging_8c.html#a1cc472551ec40b65eef931fde01054e7',1,'paging.c']]],
  ['pages',['pages',['../structpage__table.html#aa066e0fa847ce2fafb6a2feddfa340ff',1,'page_table']]],
  ['params',['params',['../mpx__supt_8c.html#a3b4b77494d0fad58939896ddc5290c99',1,'mpx_supt.c']]],
  ['phys_5falloc_5faddr',['phys_alloc_addr',['../heap_8c.html#a6dfa4ef84e115e891b3679e4932b5c49',1,'phys_alloc_addr():&#160;heap.c'],['../paging_8c.html#a6dfa4ef84e115e891b3679e4932b5c49',1,'phys_alloc_addr():&#160;heap.c']]],
  ['pid',['PID',['../structs__pcb__stuct.html#abb43cfbd0e96ecf02dad2ba433f56886',1,'s_pcb_stuct']]],
  ['present',['present',['../structpage__entry.html#a34148a94af9bfabbb8c4f00f9865dfee',1,'page_entry']]],
  ['prev',['prev',['../structs__ll__node.html#a8a534a6c6749a5cdc02b3ab769626bda',1,'s_ll_node']]],
  ['prevpcberror',['prevPCBError',['../pcb_8h.html#a8e319ed5099e8558e03c1bdd25c9559a',1,'prevPCBError():&#160;pcb.c'],['../pcb_8c.html#a8e319ed5099e8558e03c1bdd25c9559a',1,'prevPCBError():&#160;pcb.c']]],
  ['printnodefunc',['printNodeFunc',['../structs__ll.html#ada363cfffd6df4acfcb05a5d175923eb',1,'s_ll']]],
  ['priority',['priority',['../structs__pcb__stuct.html#a612f885834f0ac6dd2f928136212d84e',1,'s_pcb_stuct']]],
  ['processclass',['processClass',['../structs__pcb__stuct.html#ad0d111d2998d9b0c21b8c87df874cbf9',1,'s_pcb_stuct']]],
  ['processstate',['processState',['../structs__pcb__stuct.html#a3414d9e8c0846cb7bc40c1d8b150838d',1,'s_pcb_stuct']]],
  ['processsuspensionstate',['processSuspensionState',['../structs__pcb__stuct.html#aa00e5f40a5a58c30a8f05930a0e6be48',1,'s_pcb_stuct']]],
  ['programsize',['programSize',['../structs__pcb__stuct.html#a54cc79a0ba481257faae94273acd2c3c',1,'s_pcb_stuct']]],
  ['programstart',['programStart',['../structs__pcb__stuct.html#ad1efbb40c3e4e209c82f2e983743ab39',1,'s_pcb_stuct']]]
];
