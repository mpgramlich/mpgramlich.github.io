var searchData=
[
  ['fifoinsertfunc',['fifoInsertFunc',['../pcb_8h.html#a30717aca6066b99d5d73c6fda5b438e6',1,'fifoInsertFunc(void *pcb1, void *pcb2):&#160;pcb.c'],['../pcb_8c.html#a30717aca6066b99d5d73c6fda5b438e6',1,'fifoInsertFunc(void *pcb1, void *pcb2):&#160;pcb.c']]],
  ['find_5ffree',['find_free',['../paging_8c.html#abe201f9294ab23125146fff36fe95187',1,'paging.c']]],
  ['findpcb',['findPCB',['../pcb_8h.html#a3ddbd6b7d5425cfb586dabc05862e9b1',1,'findPCB(const char *processName):&#160;pcb.c'],['../pcb_8c.html#a3ddbd6b7d5425cfb586dabc05862e9b1',1,'findPCB(const char *processName):&#160;pcb.c']]],
  ['first_5ffree',['first_free',['../paging_8h.html#acb3c25257061521382c7ba900c1c1ab4',1,'paging.h']]],
  ['flags',['flags',['../structidt__entry__struct.html#a46c92bd8f07d5ff4e379a07b293c46af',1,'idt_entry_struct::flags()'],['../structgdt__entry__struct.html#afac75bdf53080168c8899c442862410a',1,'gdt_entry_struct::flags()'],['../tables_8h.html#a138dda98fcd4738346af61bcca8cf4b4',1,'flags():&#160;tables.h']]],
  ['footer',['footer',['../structfooter.html',1,'']]],
  ['frameaddr',['frameaddr',['../structpage__entry.html#a68a6dc54a7ab6f7fb1a068476190bf67',1,'page_entry']]],
  ['frames',['frames',['../paging_8c.html#a76492529572a1a20a06076ac40d66b29',1,'paging.c']]],
  ['freenodefunc',['freeNodeFunc',['../structs__ll.html#a6919b06690819c763c63053568542925',1,'s_ll']]],
  ['freepcb',['freePCB',['../pcb_8h.html#aa2fdf62a032353fbef2792502860709b',1,'freePCB(pcb_t *pcbToFree):&#160;pcb.c'],['../pcb_8c.html#aa2fdf62a032353fbef2792502860709b',1,'freePCB(pcb_t *pcbToFree):&#160;pcb.c']]],
  ['fs',['fs',['../structs__process_context.html#adb54401e624822659c9125b599257aa9',1,'s_processContext::fs()'],['../system_8h.html#a59556586c5fc48990f50150d95a0735d',1,'fs():&#160;system.h']]]
];
