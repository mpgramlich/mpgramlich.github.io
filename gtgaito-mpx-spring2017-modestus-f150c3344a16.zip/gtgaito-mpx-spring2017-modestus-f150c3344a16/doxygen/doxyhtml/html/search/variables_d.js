var searchData=
[
  ['name',['name',['../structs__pcb__stuct.html#adcb08963ff03878f5dd24129c9f99be7',1,'s_pcb_stuct']]],
  ['next',['next',['../structs__ll__node.html#a72e73da68eb603b175eb9caae6622804',1,'s_ll_node']]],
  ['nframes',['nframes',['../paging_8c.html#abf36580d5618820f15388083c9313e60',1,'paging.c']]]
];
