var searchData=
[
  ['gdt_5fdescriptor_5fstruct',['gdt_descriptor_struct',['../structgdt__descriptor__struct.html',1,'']]],
  ['gdt_5fentry_5fstruct',['gdt_entry_struct',['../structgdt__entry__struct.html',1,'']]]
];
