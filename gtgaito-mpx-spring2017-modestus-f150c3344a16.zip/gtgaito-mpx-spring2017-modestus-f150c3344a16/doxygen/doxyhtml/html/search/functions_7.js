var searchData=
[
  ['gdt_5finit_5fentry',['gdt_init_entry',['../tables_8h.html#a0b5aee548c88c40ecb07741be1be2e27',1,'gdt_init_entry(int idx, u32int base, u32int limit, u8int access, u8int flags):&#160;tables.c'],['../tables_8c.html#a0b5aee548c88c40ecb07741be1be2e27',1,'gdt_init_entry(int idx, u32int base, u32int limit, u8int access, u8int flags):&#160;tables.c']]],
  ['general_5fprotection',['general_protection',['../interrupts_8c.html#a10777dd6c3a040471676741bbb8dda46',1,'interrupts.c']]],
  ['get_5fbit',['get_bit',['../paging_8h.html#a317b4797bc81f65bd01cfa190800ecdd',1,'get_bit(u32int addr):&#160;paging.c'],['../paging_8c.html#a317b4797bc81f65bd01cfa190800ecdd',1,'get_bit(u32int addr):&#160;paging.c']]],
  ['get_5fdate',['get_date',['../rtc_8h.html#ab43f56447c49f42bb4baee3e59e2d1f9',1,'get_date(int *day, int *month, int *year):&#160;rtc.c'],['../rtc_8c.html#ab43f56447c49f42bb4baee3e59e2d1f9',1,'get_date(int *day, int *month, int *year):&#160;rtc.c']]],
  ['get_5fhist_5fup',['get_hist_up',['../commhand_8h.html#a5788474718b834e6c093a1223044c610',1,'get_hist_up(void):&#160;commhand.c'],['../commhand_8c.html#aeee2b9b089e25eeb449905835d6f3d5d',1,'get_hist_up():&#160;commhand.c']]],
  ['get_5fpage',['get_page',['../paging_8h.html#a69b165b3d1adf3aeaae126ca7a5aac3e',1,'get_page(u32int addr, page_dir *dir, int make_table):&#160;paging.c'],['../paging_8c.html#a69b165b3d1adf3aeaae126ca7a5aac3e',1,'get_page(u32int addr, page_dir *dir, int make_table):&#160;paging.c']]],
  ['get_5ftime',['get_time',['../rtc_8h.html#a35fa24488cb7eb077e8dc995729202cf',1,'get_time(int *hours, int *minutes, int *seconds):&#160;rtc.c'],['../rtc_8c.html#a35fa24488cb7eb077e8dc995729202cf',1,'get_time(int *hours, int *minutes, int *seconds):&#160;rtc.c']]],
  ['getdate',['getDate',['../comm__list_8c.html#affb6f9c7b2c1d585677a5bba1da35c06',1,'getDate():&#160;comm_list.c'],['../comm__list_8h.html#affb6f9c7b2c1d585677a5bba1da35c06',1,'getDate():&#160;comm_list.c']]],
  ['getnumdaysinmonth',['getNumDaysInMonth',['../comm__list_8c.html#a63e5b5d633e0beec232fe5765124ad7e',1,'getNumDaysInMonth(int month, int year):&#160;comm_list.c'],['../comm__list_8h.html#a63e5b5d633e0beec232fe5765124ad7e',1,'getNumDaysInMonth(int month, int year):&#160;comm_list.c']]],
  ['getstate',['getState',['../group___r2.html#gae34a580c5336a0d5f2a0589f41f25fa2',1,'getState(const char *name):&#160;pcb.c'],['../group___r2.html#gae34a580c5336a0d5f2a0589f41f25fa2',1,'getState(const char *name):&#160;pcb.c']]],
  ['gettime',['getTime',['../comm__list_8c.html#a1c7c164fd3c7dea7004ece3c6251fc94',1,'getTime():&#160;comm_list.c'],['../comm__list_8h.html#a1c7c164fd3c7dea7004ece3c6251fc94',1,'getTime():&#160;comm_list.c']]]
];
