var searchData=
[
  ['blocked',['BLOCKED',['../pcb_8h.html#a8461d6c03c00b03bad59b5a29d27b902a376c1b6a3f75d283a2efacf737438d61',1,'pcb.h']]]
];
