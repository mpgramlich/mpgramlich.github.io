var searchData=
[
  ['backspace',['BACKSPACE',['../input_8h.html#a629568514359445d2fbda71d70eeb1ce',1,'input.h']]],
  ['bg_5fblack',['BG_BLACK',['../input_8h.html#a0e5ebbe291d95cf1b8f1661252722fe0',1,'input.h']]],
  ['bg_5fdark_5fred',['BG_DARK_RED',['../input_8h.html#adad2b39a3d0903aa525ac599f90334aa',1,'input.h']]]
];
