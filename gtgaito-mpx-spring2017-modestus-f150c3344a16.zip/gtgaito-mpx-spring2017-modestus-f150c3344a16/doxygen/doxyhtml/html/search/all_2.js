var searchData=
[
  ['backspace',['BACKSPACE',['../input_8h.html#a629568514359445d2fbda71d70eeb1ce',1,'input.h']]],
  ['base',['base',['../structidt__struct.html#a1a91fe2ab44ad8dfbad0f6d07ec789ea',1,'idt_struct::base()'],['../structgdt__descriptor__struct.html#aa47407e7b435c214d0cdd22cb66f0e71',1,'gdt_descriptor_struct::base()'],['../structheap.html#a744634662f1ffdb4d85632e68c063e51',1,'heap::base()'],['../tables_8h.html#ab5763c2b18c825c8b8fba44b2e60ddc1',1,'base():&#160;tables.h']]],
  ['base_5fhigh',['base_high',['../structidt__entry__struct.html#a1c6a29cae5ea9a832cf4261aaa5b43d0',1,'idt_entry_struct::base_high()'],['../structgdt__entry__struct.html#aa03c14867c293012449a3b18a07f45f2',1,'gdt_entry_struct::base_high()'],['../tables_8h.html#a706c81b840522a69ab6e6e941630d5e4',1,'base_high():&#160;tables.h']]],
  ['base_5flow',['base_low',['../structidt__entry__struct.html#aefa75d6bfe07f1f544393b4dbccb3e76',1,'idt_entry_struct::base_low()'],['../structgdt__entry__struct.html#a90f05cd7f227a34e977a639843a23275',1,'gdt_entry_struct::base_low()'],['../tables_8h.html#a0a776dced2c26f16298425cde39f8364',1,'base_low():&#160;tables.h']]],
  ['base_5fmid',['base_mid',['../structgdt__entry__struct.html#a0369f1e190c433425c5b0f40c2070715',1,'gdt_entry_struct::base_mid()'],['../tables_8h.html#a35c709a004babd09046db9f667ba0646',1,'base_mid():&#160;tables.h']]],
  ['bg_5fblack',['BG_BLACK',['../input_8h.html#a0e5ebbe291d95cf1b8f1661252722fe0',1,'input.h']]],
  ['bg_5fdark_5fred',['BG_DARK_RED',['../input_8h.html#adad2b39a3d0903aa525ac599f90334aa',1,'input.h']]],
  ['bg_5fwhite',['BG_WHITE',['../group___r3.html#ga6beded3f171517df3902c52f79f6fea2',1,'input.h']]],
  ['block',['block',['../structindex__entry.html#a0a8d4dc0595b5f2ef42e7080c5221c1f',1,'index_entry']]],
  ['blocked',['BLOCKED',['../pcb_8h.html#a8461d6c03c00b03bad59b5a29d27b902a376c1b6a3f75d283a2efacf737438d61',1,'pcb.h']]],
  ['blockedqueue',['blockedQueue',['../pcb_8h.html#aa3eb63b40a5cf1eb03b494f7ddd1af2a',1,'blockedQueue():&#160;pcb.c'],['../pcb_8c.html#aa3eb63b40a5cf1eb03b494f7ddd1af2a',1,'blockedQueue():&#160;pcb.c']]],
  ['blockpcb',['blockPCB',['../comm__list_8c.html#af8c8690ef4431e1629f9ab7c5539eeae',1,'blockPCB(char parameters[][MAX_LENGTH]):&#160;comm_list.c'],['../comm__list_8h.html#af8c8690ef4431e1629f9ab7c5539eeae',1,'blockPCB(char parameters[][MAX_LENGTH]):&#160;comm_list.c']]],
  ['bounds',['bounds',['../interrupts_8c.html#a96724d36ad85f9a02231d8e6fe0434df',1,'interrupts.c']]],
  ['breakpoint',['breakpoint',['../interrupts_8c.html#a874043e2396dd8ce20ec7af3ea1e2a86',1,'interrupts.c']]],
  ['busy_5fwait',['busy_wait',['../anim_8h.html#accd23e11967f6634e7885688e395b964',1,'busy_wait(void):&#160;anim.c'],['../anim_8c.html#a251b758efbc88876a3f556ccc47fe40f',1,'busy_wait():&#160;anim.c']]]
];
