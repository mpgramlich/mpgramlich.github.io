var searchData=
[
  ['testprintfunc',['testPrintFunc',['../linked__list_8c.html#abce3e0a671a927747db173dea67b2afc',1,'linked_list.c']]],
  ['time',['time',['../comm__list_8c.html#a5dac732108bdce081376535bd2d51221',1,'time(char parameters[][MAX_LENGTH]):&#160;comm_list.c'],['../comm__list_8h.html#a5dac732108bdce081376535bd2d51221',1,'time(char parameters[][MAX_LENGTH]):&#160;comm_list.c']]]
];
