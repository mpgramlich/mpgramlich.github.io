var structgdt__descriptor__struct =
[
    [ "base", "structgdt__descriptor__struct.html#aa47407e7b435c214d0cdd22cb66f0e71", null ],
    [ "limit", "structgdt__descriptor__struct.html#a3c8ae013805dd982b25f0d62e3cdee0e", null ]
];