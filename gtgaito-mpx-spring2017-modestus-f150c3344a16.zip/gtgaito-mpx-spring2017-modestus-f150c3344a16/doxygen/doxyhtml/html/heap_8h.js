var heap_8h =
[
    [ "header", "structheader.html", "structheader" ],
    [ "footer", "structfooter.html", "structfooter" ],
    [ "index_entry", "structindex__entry.html", "structindex__entry" ],
    [ "index_table", "structindex__table.html", "structindex__table" ],
    [ "heap", "structheap.html", "structheap" ],
    [ "KHEAP_BASE", "heap_8h.html#a15073b9742f7e29d8174509197eb4ab9", null ],
    [ "KHEAP_MIN", "heap_8h.html#aee52619f74498ad224eb8e4354b89e40", null ],
    [ "KHEAP_SIZE", "heap_8h.html#a0f2696767a10e6efffc64e9b459c4ea6", null ],
    [ "TABLE_SIZE", "heap_8h.html#a032503e76d6f69bc67e99e909c8125da", null ],
    [ "_kmalloc", "heap_8h.html#a9bfb8053c2382598ef5b2175f475d49a", null ],
    [ "alloc", "heap_8h.html#a2b1d5a9ba11695605f74fc10cd719af5", null ],
    [ "init_kheap", "heap_8h.html#a755a69ff831b6e23a808dcf4b9944854", null ],
    [ "kfree", "heap_8h.html#aa2a6fb2aa05727dc1e7d72cbc108e63c", null ],
    [ "kmalloc", "heap_8h.html#a15d6a52c5c080c8c7ffc73e336d8e574", null ],
    [ "make_heap", "heap_8h.html#a686135c02695aef4208f93d4549a15d0", null ]
];