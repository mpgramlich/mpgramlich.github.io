var paging_8c =
[
    [ "clear_bit", "paging_8c.html#adcef508c82c20a032508f871e79e1b92", null ],
    [ "find_free", "paging_8c.html#abe201f9294ab23125146fff36fe95187", null ],
    [ "get_bit", "paging_8c.html#a317b4797bc81f65bd01cfa190800ecdd", null ],
    [ "get_page", "paging_8c.html#a69b165b3d1adf3aeaae126ca7a5aac3e", null ],
    [ "init_paging", "paging_8c.html#a919b727f386797a8b9d8eceb5c4e7313", null ],
    [ "load_page_dir", "paging_8c.html#a31e6c585cbda542534f1b0fc83e40689", null ],
    [ "new_frame", "paging_8c.html#a04bce9da2c1d7c59f6efd8e4d9b54db7", null ],
    [ "set_bit", "paging_8c.html#a70101fc152ff58caafbe36ab391a9a68", null ],
    [ "cdir", "paging_8c.html#af7da380833e92d5c7d3c3db41484713b", null ],
    [ "frames", "paging_8c.html#a76492529572a1a20a06076ac40d66b29", null ],
    [ "kdir", "paging_8c.html#a61ce943ba80d9dfab89a826cae9ddc4a", null ],
    [ "kheap", "paging_8c.html#a61825456a33b09780a5493c95adcae8a", null ],
    [ "mem_size", "paging_8c.html#abf8475f59bfb67fac4b6b5a254dfe56d", null ],
    [ "nframes", "paging_8c.html#abf36580d5618820f15388083c9313e60", null ],
    [ "page_size", "paging_8c.html#a1cc472551ec40b65eef931fde01054e7", null ],
    [ "phys_alloc_addr", "paging_8c.html#a6dfa4ef84e115e891b3679e4932b5c49", null ]
];