var structheap =
[
    [ "base", "structheap.html#a744634662f1ffdb4d85632e68c063e51", null ],
    [ "index", "structheap.html#a8fe6ce2a8b45088990071e9b1d35add2", null ],
    [ "max_size", "structheap.html#ad2e0262828735d6e437facbfce37d6b0", null ],
    [ "min_size", "structheap.html#a7b4422774c5ca7ac8ed5ddfe95f5c8ec", null ]
];