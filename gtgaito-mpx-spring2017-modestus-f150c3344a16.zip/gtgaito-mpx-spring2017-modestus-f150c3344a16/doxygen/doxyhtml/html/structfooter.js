var structfooter =
[
    [ "head", "structfooter.html#acae33dac61c9505ff5b850f88d32dd0b", null ]
];